# HyperMachine — Feasibility & Architecture

Host reference machine: **M1 Pro, 10 cores (8 performance + 2 efficiency), 32 GB
RAM, macOS 27.2**. This document is grounded in that machine's actual
capabilities.

---

## 0. The headline

Of the five requirements, **three are straightforward, one is partly
impossible, and one is a research project.**

The two hard parts both come from the same root cause: Apple's high-level
`Virtualization.framework` — the only framework that gives you macOS guests,
GPU acceleration, and one-click installs — deliberately hides the low-level
control that requirement #1 asks for.

---

## 1. Requirement-by-requirement reality check

### 1.1 RAM and vCPU count — ✅ easy

`VZVirtualMachineConfiguration` exposes `cpuCount` and `memorySize`, and the
framework itself publishes the legal range via `maximumAllowedCPUCount`,
`minimumAllowedCPUCount`, `maximumAllowedMemorySize` and
`minimumAllowedMemorySize`. The UI should read those at runtime rather than
hard-code limits, because they vary by host and by guest type.

For **macOS guests** the restore image imposes its own floor on top of that.
`VZMacOSConfigurationRequirements` exposes only `minimumSupportedCPUCount`,
`minimumSupportedMemorySize` and `hardwareModel` — there is **no** maximum, so
Apple does not cap how many vCPUs you give a macOS guest.

Measured on the M1 Pro reference machine, the framework reports
`maximumAllowedCPUCount == 64` and `maximumAllowedMemorySize == 32 GiB`, i.e.
the full installed RAM. HyperMachine deliberately runs *stricter* than the
framework here: `HostCapabilities` reserves memory for the host and defaults the
vCPU ceiling to the performance-core count, because a framework that permits
something is not a framework that schedules it well.

### 1.2 "What SPECIFIC CPU cores" — ⚠️ not possible as written

This is the one requirement that cannot be delivered literally, and it is worth
being blunt about why.

- **No CPU pinning on Apple Silicon.** `THREAD_AFFINITY_POLICY` is explicitly
  documented as *experimental* in XNU, and it describes a cache-affinity
  *relationship*, not "run on core N". On arm64 macOS it commonly returns
  `KERN_NOT_SUPPORTED` outright. An Apple DTS engineer confirmed in a 2026 forum
  thread that there is no reliable way to make a thread stay on a particular
  core. ([XNU `thread_policy.h`](https://github.com/apple-oss-distributions/xnu/blob/main/osfmk/mach/thread_policy.h),
  [Apple Developer Forums](https://developer.apple.com/forums/thread/849599))
- **QoS is a bias, not a selector.** `pthread_set_qos_class_self_np` is Apple's
  supported lever for P-core vs E-core placement influence. Apple is explicit
  that the OS decides placement and *can* migrate, and can put high-QoS work on
  E-cores under thermal pressure.
  ([Apple: Optimize for Apple Silicon](https://developer.apple.com/news/?id=vk3m204o))
- **`Virtualization.framework` does not expose its vCPU threads.** The public
  `VZVirtualMachine` surface has no handle to the threads that run vCPUs, so you
  cannot set their QoS or priority from outside.
  ([`VZVirtualMachine`](https://developer.apple.com/documentation/virtualization/vzvirtualmachine))
- **`Hypervisor.framework` does give you the threads.** `hv_vcpu_create` binds a
  vCPU to the *current thread*, so a VMM that spawns one thread per vCPU can set
  QoS on each one before running it.
  ([`hv_vcpu_create`](https://developer.apple.com/documentation/hypervisor/hv_vcpu_create(_:_:_:)))

**What we can actually ship for requirement #1:**

| Feature | Deliverable? |
|---|---|
| Choose total vCPU count | ✅ |
| Choose total RAM | ✅ |
| Show host topology (8 P + 2 E in your case) | ✅ |
| Reserve E-cores for the host so the VM doesn't steal them | ✅ (by capping vCPUs at P-core count) |
| **Per-vCPU core-type bias** (vCPU 0–5 → P, 6–7 → E) | ⚠️ **only with a custom Hypervisor.framework VMM** — and even then it's a QoS *hint*, not a guarantee |
| Pin vCPU N to physical core N | ❌ impossible on Apple Silicon |

The honest UX is a **placement policy** selector — `Performance-preferred`,
`Balanced`, `Efficiency-preferred` — with a footnote that says what it actually
does. Anything that claims literal core pinning would be lying to the user.

### 1.3 GPU hardware acceleration — ⚠️ yes for macOS, effectively no for Linux

This splits hard by guest OS:

| Guest | Apple's frameworks | Third-party stacks |
|---|---|---|
| **macOS** | ✅ **Metal-backed paravirtualized GPU.** `VZMacGraphicsDeviceConfiguration` + `VZMacGraphicsDisplayConfiguration` exposes GPU capabilities so the guest can run Metal. This is real acceleration. | — |
| **Linux** | ❌ **2D surface only.** `VZVirtioGraphicsDeviceConfiguration` gives you a display, not 3D. UTM measured this directly: a Linux VM under AVF reports `llvmpipe` (software rasterizer). | ⚠️ **Experimental.** QEMU via UTM 5.x can do Vulkan through **Venus → MoltenVK**, or older **VirGL + ANGLE Metal**. UTM's own release notes still list breakage (missing indirect geometry-shader draws; "use VirGL instead"). |

Sources: [WWDC22 "Create macOS or Linux virtual machines"](https://developer.apple.com/videos/play/wwdc2022/10002/),
[`VZMacGraphicsDeviceConfiguration`](https://developer.apple.com/documentation/virtualization/vzmacgraphicsdeviceconfiguration),
[`VZVirtioGraphicsDeviceConfiguration`](https://developer.apple.com/documentation/virtualization/vzvirtiographicsdeviceconfiguration),
[UTM's `llvmpipe` measurement](https://github.com/utmapp/UTM/discussions/5482),
[UTM 5.0.3 notes](https://github.com/utmapp/UTM/discussions/7700).

**Key correction to the plan:** "GPU hardware acceleration" is only achievable
through `Virtualization.framework`, and only for **macOS guests**. Any engine
built directly on `Hypervisor.framework` gets *no* GPU acceleration at all —
that combination does not exist in Apple's stack.

### 1.4 One-click setup — ✅ doable, with honest boundaries

- **macOS:** genuinely one-click for the install. `VZMacOSRestoreImage.latestSupported`
  → download → `VZMacOSConfigurationRequirements.mostFeaturefulSupportedConfiguration`
  → `VZMacAuxiliaryStorage(creatingStorageAt:hardwareModel:)` + a fresh
  `VZMacMachineIdentifier` → `VZMacOSInstaller`. **Caveat:** the installer
  installs the OS; it does not skip Setup Assistant, so the first boot still
  asks the user for a name/account.
  ([Installing macOS on a Virtual Machine](https://developer.apple.com/documentation/virtualization/installing-macos-on-a-virtual-machine))
- **Linux:** two tiers.
  - *Good:* `VZEFIBootLoader` + a distro installer ISO in a virtual USB drive,
    then the user clicks through the installer.
  - *Better:* ship a **cloud-init seed** (NoCloud: a `VZUSBMassStorageDeviceConfiguration`
    or secondary disk with `user-data`/`meta-data`) on top of a cloud image, so
    the install is genuinely unattended. This is guest software, not an Apple API,
    so each distro needs its own seed verified.
  - `VZLinuxBootLoader` (direct kernel + initrd + cmdline) is the fastest boot
    path but only applies when we ship our own kernel — good for a
    "fast appliance" preset, not for general distros.
  ([`VZEFIBootLoader`](https://developer.apple.com/documentation/virtualization/vzefibootloader))
- **Windows 11 Arm** rides the same EFI path and is worth adding to the catalog;
  it's one of the strongest use cases for this class of app.

### 1.5 Secure virtualization — ✅ doable, and should be a design axis

Not a single feature — a set of defaults:

| Control | How |
|---|---|
| Guest memory isolation | Provided by the framework; must be built with the restricted **`com.apple.security.virtualization`** entitlement |
| Minimal attack surface | Hardened runtime, no privileged helper, no kernel extension |
| Network isolation by default | `VZNATNetworkDeviceAttachment` — guest is *not* on the LAN. `VZBridgedNetworkDeviceAttachment` requires the separately-approved **`com.apple.vm.networking`** entitlement, so make it opt-in and expect a provisioning profile |
| Shared folders | `readOnly: true` by default; per-share opt-in for write |
| Data at rest | Encrypted sparse image for the disk, or in-guest LUKS / FileVault |
| No implicit clipboard / USB sharing | Off by default, explicit enable |
| Auditable | VMs stored in plain, inspectable directories |

**Honest limitations:** you cannot reproduce Touch ID / Secure Enclave binding
inside a guest, and a VM is not a security boundary against a determined
attacker with host access.

### 1.6 Shared network folder — ✅ works, and works for both guest types

`VZSharedDirectory(url:readOnly:)` → `VZSingleDirectoryShare` (or
`VZMultipleDirectoryShare` for several) → `VZVirtioFileSystemDeviceConfiguration`
with a `tag`.

- **Linux guest:** `mount -t virtiofs <tag> /mnt/share`
- **macOS guest:** set the device tag to
  `VZVirtioFileSystemDeviceConfiguration.macOSGuestAutomountTag` and Ventura+ mounts
  it automatically.

Sources: [Shared directories](https://developer.apple.com/documentation/virtualization/shared-directories),
[`macOSGuestAutomountTag`](https://developer.apple.com/documentation/virtualization/vzvirtiofilesystemdeviceconfiguration/macosguestautomounttag).

Note this is **virtio-fs, not SMB/NFS** — so it is a shared *filesystem*, which
is what the requirement asks for. Adding an SMB/NFS fallback is only useful if
we also want to expose shares to a bridged network.

---

## 2. The core tension

```
                        macOS guest    GPU accel    virtio-fs    one-click    vCPU thread control
Virtualization.framework     ✅            ✅(macOS)      ✅           ✅                 ❌
Hypervisor.framework         ❌            ❌             ✋ DIY        ❌ DIY             ✅
```

Nothing on the right column exists without giving up most of the others.
That is the whole architecture decision.

---

## 3. Engine options

### Path A — Virtualization.framework (**chosen**)

> **Decision (made):** this is the engine HyperMachine is built on. The direct
> Hypervisor.framework route was rejected because it costs macOS guests, GPU
> acceleration and one-click installs in exchange for CPU-placement hints.
> Ad-hoc signing turned out to be sufficient for the Virtualization
> entitlement, so no Apple Developer account is required either.

Swift app linking `Virtualization.framework` directly. This is what
UTM, VirtualBuddy, and Tart all do. Fastest route to a genuinely useful product.

- **Gets:** macOS guests w/ Metal GPU, Linux + Windows Arm via EFI,
  virtio-fs shares, one-click macOS install, native SwiftUI UI, NAT networking.
- **Gives up:** per-vCPU QoS/core-type bias, Linux 3D, exotic hardware.
- **Effort:** weeks, not months.

### Path B — Custom Hypervisor.framework VMM (the literal request)

Write the VMM yourself. `hv_vm_create`, `hv_vm_map`, `hv_vcpu_create` per thread,
`hv_vcpu_run`, `hv_vcpus_exit`, plus **everything the framework was giving you**:
a boot path, virtio-blk/net/console/fs device models, interrupt controller
(GIC) handling, device tree or ACPI, entropy, time. This is a from-scratch
mini-QEMU.

- **Gets:** per-vCPU thread QoS (so the *hint* of core-type assignment), custom
  devices, full control, and it's the interesting engineering.
- **Gives up:** **all macOS guests**, **all GPU acceleration**, one-click
  installs, and a lot of time. Realistic first milestone is "boots a Linux
  kernel to a serial console".
- **Precedent:** projects in this space (Ignition, BridgeVM, Uhyve's
  `xhypervisor`, `simpple-vm`) are research/engineering previews, not shippable
  desktop products.

### Path C — Hybrid (deferred; this is where a custom engine would slot in)

- Default engine: **Virtualization.framework** → satisfies requirements 1(a),
  2(macOS), 3, 4, 5 today.
- Optional second engine: **custom HVF VMM**, Linux-only and headless-first,
  for users who want CPU placement control and minimal overhead. Delivered as a
  *separate* VM type so it never compromises the main product.
- Optional third engine later: **embedded QEMU** for Linux 3D (Venus/VirGL) and
  oddball guests.

This keeps the honest promise ("all five requirements") while being buildable,
and it puts the impossible-to-merge parts behind a clear boundary.

---

## 4. Recommended architecture

```
┌─────────────────────────────────────────────────────────┐
│ HyperMachine.app  (SwiftUI, macOS 26+)                  │
│   · VM library sidebar                                  │
│   · Config editor (RAM / vCPU / placement / shares)     │
│   · Live VM display (VZVirtualMachineView)              │
│   · Guest catalog + one-click installer flow            │
└───────────────────────┬─────────────────────────────────┘
                        │  depends on
┌───────────────────────▼─────────────────────────────────┐
│ HyperMachineCore   (engine-agnostic, unit-tested)       │
│   · VMConfig model (Codable, persisted as JSON)          │
│   · HostCapabilities (P/E cores, RAM, legal ranges)      │
│   · Validator → [VMConfigIssue] (.error / .warning)      │
│   · Guest catalog (distro, image URL, sha256, seed)      │
└───────────────────────┬─────────────────────────────────┘
                        │  implemented by
┌───────────────────────▼─────────────────────────────────┐
│ VZEngine      (Virtualization.framework)   ← default    │
│ HVFEngine     (Hypervisor.framework)       ← later      │
│ QEMUEngine    (embedded QEMU)              ← later      │
└─────────────────────────────────────────────────────────┘
```

Keeping `HyperMachineCore` free of `Virtualization` imports is deliberate: it
makes the config model testable **without** the restricted entitlement, and it
is the piece that survives an engine swap. That is the part built in this
session.

**Adding a guest** is a catalog entry, not a code change:
`{name, arch, boot: .efi | .kernel | .macRestore, imageURL, sha256, diskGB, seed}`.

---

## 5. Host prerequisites

1. **Xcode: present but not in `/Applications`.** A full Xcode 27.2 beta sits at
   `~/Downloads/Xcode-beta.app`. Point `DEVELOPER_DIR` at its
   `Contents/Developer` — no `sudo` and no `xcode-select` needed. Without it,
   `swift test` fails and the app cannot be built.
2. **Entitlements: ad-hoc signing is enough — corrected.** This was the biggest
   open risk and it turned out not to be one. `com.apple.security.virtualization`
   is *not* gated behind a provisioning profile in practice: signing with
   `codesign --force --sign - --entitlements …` lets the process call
   `VZMacOSRestoreImage.latestSupported` and have the framework return a real
   image (verified: macOS 27.0.1, build 26A434). No Apple Developer account is
   required for this engine. `com.apple.vm.networking` (bridged networking) and
   `com.apple.security.hypervisor` are still separately restricted and unproven.
3. **Nested virtualization is not available on the M1 Pro.** The API is
   `VZGenericPlatformConfiguration.isNestedVirtualizationSupported` (macOS 15+)
   for Virtualization.framework — check it at runtime rather than guessing from
   the chip name. On this machine it is false, so KVM inside a guest is out of
   scope here.
4. **`VZMacGuestProvisioningOptions` is declared but not wired up.** The macOS 27
   SDK ships the type (with `fullName`, `username`, `password`,
   `logsInAutomatically`, `enablesRemoteLogin`), but no public configuration
   property accepts it yet (`provisioningOptions` appears on no header). So the
   install still cannot pre-create the user account, and Setup Assistant still
   runs on first boot — watch for this to land, because it removes the last
   manual step from the macOS flow.

---

## 6. Milestones

| # | Milestone | Deliverable | Status |
|---|---|---|---|
| **M0** | Config core | `VMConfig` + `HostCapabilities` + `Validator` + tests | **done** |
| **M1** | SwiftUI shell | VM list, configuration form, embedded `VZVirtualMachineView`, install progress | **done** |
| **M2** | macOS guest + GPU | restore-image plan + resumable download + `VZMacOSInstaller` + `VZMacGraphicsDeviceConfiguration`; installs and boots | **done** |
| **M3** | One-click catalog | Linux image download/verify pipeline, qcow2 flattening, cloud-init seeds; installs and boots unattended | **done** |
| **M4** | Settings and windows | edit an existing VM (resolution, shares, RAM, vCPU, network, security), one window per running guest | **done** |
| **M5** | Security pass | read-only shares, encrypted disks, clipboard off, signing/notarization — disk format and security toggles exist but only NAT/read-only-on-by-default are enforced | partial |
| **M6** | Custom HVF engine | Linux-only, per-vCPU QoS, serial console first | research |

### M2 as delivered

The macOS path is complete: `hm macos-install` downloads the restore image
(24.8 GiB for macOS 27.0.1 / build 26A434), creates the auxiliary storage and a
sparse boot disk, runs `VZMacOSInstaller`, and records the VM as installed.
`hm macos-boot` and the app's **Start** button then boot it.

The install sequence lives once, in `MacOSInstallDriver`, and is consumed by
both front ends — the CLI renders events as log lines, the app renders them as
a progress bar.

Two things learned from running it rather than reading about it:

- **Virtualization.framework runs the guest in a separate XPC helper.**
  `com.apple.Virtualization.VirtualMachine.xpc` is where the vCPU threads and
the guest's RAM actually live — the `hm` process itself stays small (a few
threads, ~90 MB resident). Measuring the app process to decide whether a guest
is executing gives a completely wrong answer; the helper is at ~190% CPU with
8.8 GiB resident while the guest boots.
- **The paravirtualized GPU is real and observable.** A booting guest also
  spawns `com.apple.gpusw.ParavirtualizedGraphicsGPUTask.xpc` processes, which
  is requirement #2 running.

`VZVirtualMachine.State` gained `.pausing`, `.resuming` and `.stopping` in
macOS 27. The CLI prints state transitions rather than assuming that a machine
which started is a machine which is running.

### M3 as delivered — the Linux path

A Linux VM is now created, booted and confirmed working end to end. The sequence
is: pick a catalog entry → download → verify against the vendor's manifest →
determine what the file actually is → attach the boot disk → write a NoCloud
seed → boot with EFI → wait for cloud-init to report back.

Three findings, all from running it rather than reading about it:

1. **A `.img` is not necessarily a raw image.** Ubuntu's arm64 cloud image is a
   qcow2 container. `VZDiskImageStorageDeviceAttachment` accepts the file and the
   guest stops immediately afterwards, with no error from the framework and no
   output on the serial console — the worst possible failure shape. So nothing is
   attached until `DiskImageInspector` has read the first few kilobytes and said
   what the file is, and the finished boot disk is checked for a protective MBR, a
   GPT, an EFI system partition and a FAT boot sector before the VM is saved.
2. **The cluster descriptor layout is not what the format description says.**
   Decoding a real image showed the host offset in the low 48 bits of an L2 entry
   rather than bits 9–55, bit 62 marking compression, bare DEFLATE with no zlib
   wrapper, and consecutive payloads packed back to back so a payload's length is
   the distance to the next one. That model was confirmed before it was trusted:
   all 9,639 compressed streams inflate to exactly one 64 KiB cluster, and cluster
   0 rebuilds a byte-exact protective MBR and GPT header. The flattened disk was
   then attached read-only by the host and its FAT32 EFI partition mounted, with
   `EFI/BOOT/BOOTAA64.EFI`, `shimaa64.efi` and `grubaa64.efi` all present —
   thousands of FAT clusters mutually consistent, which a wrong decode cannot
   fake.
3. **The framework will not tell you a disk cannot boot.** Hence a positive
   check rather than a hopeful one, and hence the handshake file: a guest that
   boots to a login prompt and a guest that wedges before the kernel are
   indistinguishable from the host side without one.

The reader refuses anything it does not implement (external data files,
zstd-compressed clusters, extended sub-cluster L2 entries, encrypted images,
delta images with a backing file) rather than guessing.

### M4 as delivered — settings and windows

One `VMEditorModel` backs both "New Virtual Machine" and "Settings", so the two
cannot drift: the form derives a `VMConfig` on demand and shows exactly the
diagnostics the engine would produce. It edits the boot disk's *size* only —
other disks and installer media are left alone — and grows a disk but never
shrinks it, because truncating a file under a guest's file system destroys it.
Editing is refused while the VM is running, since the device set is fixed at
creation.

Each running guest gets its own `WindowGroup`, keyed by name, so a guest can be
full-screened or moved to another display while the library window stays usable.

The editor is also the one component a unit test cannot reach, so it checks
itself: `--editor-selftest` drives the real model against a throwaway VM and
prints 23 checks covering resolution presets, shared folders, resources,
persistence and the framework's verdict.

### Input has to be declared, and fails silently if it is not

`VZVirtualMachineView`'s contract, from its own header, is that it forwards
input "if the virtual machine configuration includes a keyboard and a pointing
device". `VZVirtualMachineConfiguration.pointingDevices` is **empty by
default**, and `validate()` does not complain about that. The observable result
is a guest with no cursor at all — no error, no log line, just a mouse that does
nothing.

The macOS device set therefore includes `VZMacTrackpadConfiguration` (the
Mac-guest pointing device; `VZUSBScreenCoordinatePointingDeviceConfiguration` is
the fallback for guests older than macOS 13) next to `VZMacKeyboardConfiguration`.

The trackpad is a *relative* pointer, so the host side matters too: an `NSWindow`
ignores mouse-moved events unless `acceptsMouseMovedEvents` is set, and a view
that never becomes first responder never sees keys. Both are set explicitly in
the app and in the CLI's boot window.

Because a machine's device set is fixed at creation, changing input devices
requires rebooting the guest — an already-running VM cannot gain a trackpad.

---

## 7. Decisions

1. **Engine — Path A, Virtualization.framework only.** Settled. Per-vCPU
   core-type bias is therefore out of scope, and the placement policy in the
   config model is surfaced to the user as a scheduling hint with a warning,
   never as a reservation.
2. **First guest — macOS (latest supported).** Settled. Linux and Windows Arm
   reuse the same catalog and config model but need their own platform, boot
   loader and graphics device.
3. **Distribution** — still open. Mac App Store vs direct download +
   notarization; direct download is the norm for this category and avoids
   App Store friction around virtualization entitlements.
4. **Name/bundle id** — still `HyperMachine` as a placeholder.
5. **Never trust a filename, and never save a disk you have not inspected.**
   Settled, and it is the load-bearing decision of the Linux path. The cost is a
   few kilobytes of reads and a GPT parse; the alternative is a VM that saves
   successfully and then does nothing, which is the failure mode that wastes the
   most of a user's time.
6. **Flatten qcow2 rather than reject it.** Settled. The better-supported images
   are the ones published as containers, and refusing them would mean the app's
   own catalog could not install what it lists.

---

## 8. Prior art worth reading before writing a line

UTM (QEMU + AVF, the reference implementation of this whole idea),
VirtualBuddy (SwiftUI + AVF, closest to what's described here),
Tart (AVF for CI), OrbStack (own engine, Linux only, fastest).
