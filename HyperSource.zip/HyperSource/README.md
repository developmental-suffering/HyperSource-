# HyperMachine

A native macOS virtual machine manager for Apple Silicon, built on
**Virtualization.framework** (see [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for
why the direct Hypervisor.framework route was not taken).

> **Status:** the macOS guest path works end to end — download, install, boot —
> from both the app and the CLI, and **Linux now boots too**: a cloud image is
> downloaded, checksum-verified, flattened to a raw disk, booted under EFI, and
> cloud-init writes a handshake file back to the host when the guest is really
> up. Windows still has no engine.
> Two of the five original requirements cannot be implemented as written —
> read the architecture doc before planning around them.

## The five requirements, honestly

| # | Requirement | Reality |
|---|-------------|---------|
| 1 | Clean UI: RAM, CPU count, **and specific CPU cores** | RAM + vCPU count: fully doable. **Pinning a vCPU to a specific physical core is not possible on Apple Silicon** — macOS ignores affinity tags on arm64. What *is* possible is per-vCPU **core-type bias** (P-core vs E-core) via thread QoS — and only if we own the vCPU threads. |
| 2 | GPU hardware acceleration | **macOS guests: yes**, Metal-backed paravirtualized GPU. **Linux guests: 2D only** through Apple's frameworks. Linux 3D requires QEMU's experimental Venus/`virtio-gpu-gl` (Vulkan → MoltenVK), which is not Apple's framework. |
| 3 | One-click setup for Linux, macOS, etc. | Yes, with caveats. macOS = download restore image + `VZMacOSInstaller` (real one-click install, but Setup Assistant still runs on first boot). Linux = curated image catalog + EFI boot with a cloud-init seed: genuinely unattended, and **working today** for Debian 13 and Ubuntu 24.04 on arm64. |
| 4 | Secure virtualization | Doable and is a first-class design axis: minimal entitlements, hardened runtime, NAT-by-default networking, read-only-by-default shares, opt-in encrypted disks, no clipboard sharing by default. |
| 5 | Shared network folder | Yes — `VZVirtioFileSystemDeviceConfiguration` (virtio-fs) works for **both Linux and macOS** guests. |

## Why this matters

Requirement **2** and the second half of requirement **1** both point the same
way: they need low-level control that Apple's high-level
**Virtualization.framework** deliberately does not expose.

- **Hypervisor.framework** is CPU + memory only. It is a toolkit for writing a
  VMM from scratch — boot, firmware, every device, every driver. It gives you
  thread-level control (so per-vCPU core-type bias works) but **no GPU**, and
  **no practical macOS guests**.
- **Virtualization.framework** gives you macOS guests, Metal GPU acceleration,
  virtio-fs shares, and one-click installs for free — but it **owns its vCPU
  threads**, so you cannot set their QoS or placement.

There is no single framework that satisfies all five requirements. The
architecture doc proposes how to get the most of both.

## Layout

```
docs/ARCHITECTURE.md        feasibility, engine comparison, milestones
Sources/HyperMachineCore/   engine-agnostic VM configuration model, guest catalog,
                            disk-image inspector
Sources/HyperMachineVZ/     the Virtualization.framework engine (macOS and Linux
                            guests), qcow2 reader, install drivers
Sources/HyperMachineApp/    SwiftUI app: VM library, settings editor, one window
                            per running guest
Sources/hm/                 CLI: inspect the host, validate configs, install/boot
Tests/HyperMachineCoreTests/swift-testing suite (model and disk images)
Tests/HyperMachineVZTests/  swift-testing suite (qcow2 conversion, checksums)
Fixtures/                   sample valid and invalid VM configurations
Scripts/build-run.sh        build + sign + run the CLI
Scripts/build-app.sh        build + bundle + sign + launch the app
Resources/                  entitlements and Info.plist used for signing
```

Both front ends drive the same engine. `MacOSInstallDriver` in
`Sources/HyperMachineVZ` is the single implementation of the install sequence
(hardware model, auxiliary storage, machine identifier, disk sizing, installer
run), and `MacOSVMFactory.makeConfiguration` is the single place a macOS device
set is assembled.

The Linux side has the same shape: `LinuxInstallDriver` owns download → verify →
flatten → seed, and `LinuxVMFactory` owns the generic-platform device set. A
single `VMFactory.makeConfiguration` decides which of the two a saved VM gets, so
a VM always reopens the way it was created.

## Building and running

Xcode lives at `~/Downloads/Xcode-beta.app`, not in `/Applications`, so point
`DEVELOPER_DIR` at it (no `sudo`, no `xcode-select`):

```sh
export DEVELOPER_DIR="$HOME/Downloads/Xcode-beta.app/Contents/Developer"
swift build
swift test          # 71 tests in 16 suites
```

Everything that touches a VM must also be **signed with the Virtualization
entitlement** — the framework refuses to load a restore image otherwise.
Ad-hoc signing is enough; no Apple Developer account is needed:

```sh
codesign --force --sign - --entitlements Resources/HyperMachine.entitlements .build/debug/hm
```

`Scripts/build-run.sh` does both and then runs the CLI:

```sh
./Scripts/build-run.sh host                     # this Mac's virtualization budget
./Scripts/build-run.sh validate Fixtures/ubuntu-dev.json
./Scripts/build-run.sh selftest                 # 47 configuration checks
./Scripts/build-run.sh macos-plan               # live Apple restore-image plan
./Scripts/build-run.sh macos-validate           # build a macOS config, have the framework check it
./Scripts/build-run.sh linux-validate           # same, for the generic-platform device set
./Scripts/build-run.sh linux-create --name ubuntu --guest debian-13-cloud-arm64
./Scripts/build-run.sh image <file>             # what a disk image really is
```

`macos-plan` and `macos-validate` hit Apple's network. `macos-validate` proves
the whole device set (Mac platform, boot loader, storage, NAT, GPU display,
virtio-fs share, entropy) passes `VZVirtualMachineConfiguration.validate()`
without downloading the ~25 GB restore image.

### The app

The GUI is a SwiftPM executable that `Scripts/build-app.sh` wraps in a bundle
and signs. SwiftPM alone produces a bare executable, which is not enough: the
framework checks the entitlement on the *process*, and a bundled app also needs
an `Info.plist` to get a Dock icon and an activatable window.

```sh
./Scripts/build-app.sh              # build, bundle, sign, launch
./Scripts/build-app.sh --no-open    # just build and verify the signature
```

What it does:

- **New VM form** — guest from the built-in catalog, RAM slider and vCPU stepper
  bounded by the framework's real ranges, boot-disk size, NAT/bridged network,
  host folders shared over virtio-fs, security toggles (all off by default).
- **Core placement** — a P-core/E-core policy picker that states plainly that
  Apple Silicon has no CPU pinning and that this is a scheduling hint.
- **Live diagnostics** — the form runs the same validator the engine does and
  lists the resulting errors and warnings, so a disabled *Install* button is
  never a mystery.
- **Install progress** — a real bar plus a log, fed by the shared install
  driver. Download and install are separate 0→100% progressions.
- **Settings for an existing VM** — the same form in edit mode: resolution,
  shared folders, RAM, vCPU count, network mode and the security toggles, with
  the disk grown (never shrunk) to match. Editing is refused while a VM runs,
  because a machine's devices are fixed at creation.
- **Live screen** — an embedded `VZVirtualMachineView`, with the guest's state
  polled so a guest that powers itself off says so instead of leaving a black
  window. Each running VM gets **its own window**, so a guest can be
  full-screened or moved to another display while other machines stay visible in
  the library.

The app and the CLI share `~/Documents/HyperMachine/VMs`, so a VM installed by
one is bootable from the other.

A VM can also be started without a click, which is useful from a script:

```sh
open .build/HyperMachine.app --args --boot macOS
```

Launched this way the app is owned by LaunchServices, so it outlives whatever
started it. (A shell-backgrounded `hm macos-boot` does not: it dies with the
shell that spawned it.)

### Linux guests, and why the file extension is not evidence

A one-click Linux VM is a cloud image plus a seed. The image is downloaded and
checked against the vendor's own manifest (Ubuntu publishes SHA-256, Debian
SHA-512 — the algorithm is chosen from the digest's length, not the file name),
then attached as the boot disk, and a NoCloud seed made on the host sets the
hostname, a user account and SSH on first boot. When cloud-init finishes it
writes a timestamp, hostname and kernel version into a virtio-fs folder, which is
the only unambiguous way to know an unattended boot succeeded.

Two things went wrong on the way there, both worth knowing:

- **The extension lies.** Every guide says Ubuntu's cloud image is a raw disk
  image. On arm64 the file named `.img` is a qcow2 container (the amd64 image is
  raw, which is where the advice comes from). Virtualization.framework attaches a
  qcow2 file happily and then the guest stops immediately with no error at all.
  So `DiskImageInspector` looks at the bytes: `hm image <file>` tells you what a
  file really is, whether it has a GPT, and whether firmware would find a boot
  loader on it.
- **qcow2 is flattened, not rejected.** `QCOW2Converter` turns a container into a
  plain disk, which is what makes Ubuntu work. Its descriptor decoding was
  settled against a real image: all 9,639 compressed streams of the Ubuntu
  minimal image inflate to exactly one 64 KiB cluster each, and disk cluster 0
  rebuilds a byte-exact protective MBR and GPT header. The finished disk is then
  re-inspected — protective MBR, GPT, EFI system partition, FAT boot sector —
  and a disk that fails that check is deleted rather than saved, so a bad decode
  can never reach a boot attempt.

After the guest boots, the root partition is grown by cloud-init to fill the
virtual disk, so the 3.5 GiB image becomes the 16 GiB (or whatever) disk you
asked for.

### The settings editor checks itself

The editor is a SwiftUI form with `@MainActor` logic inside the app target, which
is the one place a unit test cannot reach. Run it headlessly instead:

```sh
./.build/HyperMachine.app/Contents/MacOS/HyperMachineApp --editor-selftest
```

It drives the real model against a throwaway VM: applies a resolution preset and
re-applies it over a custom size, adds and removes shared folders (checking
mount-tag uniqueness and read-only defaults), changes RAM and vCPU count,
validates, writes, reloads, and hands the result to
`VZVirtualMachineConfiguration.validate()`. 23 checks, no window, nothing left in
`~/Documents/HyperMachine/VMs` afterwards.

### Input devices are opt-in, and silent when missing

`VZVirtualMachineView` forwards keyboard and pointer events **only through input
devices declared in the machine's configuration**. `VZVirtualMachineConfiguration.pointingDevices`
is empty by default, and a guest with no pointing device has no cursor: mouse
movement does nothing and there is no error anywhere. The macOS factory
therefore declares `VZMacTrackpadConfiguration` alongside `VZMacKeyboardConfiguration`.
Device sets are fixed when the machine is created, so a change here only takes
effect on the VM's next boot.

### One VM at a time per machine identifier

Apple does not support running the same VM twice at once — the
`VZMacMachineIdentifier` is per-VM and cannot be shared by two live instances.
If a VM is already running from the CLI, start it from the CLI, not the app.

`hm validate` exits `0` when the config is legal on this machine, `1` when it
has errors (warnings alone still exit `0`), `65` for unparseable JSON, and `66`
for an unreadable file — so it works as a pre-flight step in a script.

### Toolchain note

Command Line Tools alone are not sufficient for this project. The
swift-testing macro plugin is wired up only by Xcode's toolchain; under CLT,
`swift test` fails with `plugin for module 'TestingMacros' not found`. That is a
toolchain packaging gap, not a code defect.
