import Foundation
import HyperMachineCore
import HyperMachineVZ

// Swift's stdout is block-buffered when it is not a terminal. Long installs run
// in the background with output redirected to a log, so line-buffer it or
// nothing is visible until the buffer fills.
setvbuf(stdout, nil, _IOLBF, 0)

// `hm` is the headless half of HyperMachine: it reports what the host can
// actually do and checks whether a saved VM configuration is legal on this
// machine. It is also the smoke test that runs without Xcode, since the
// swift-testing suite needs the full toolchain's macro plugin.

// NOTE: top-level globals in main.swift are initialised in source order, so
// `referenceHost` below would still be zeroed if we dispatched at the top of
// the file. The driver runs from the last line instead.

// MARK: - Commands

func printUsage() {
    print("""
    hm — HyperMachine's command line

      hm host                Show this Mac's virtualization budget
      hm validate <file>     Check a VM configuration against this host
      hm selftest            Run the configuration smoke tests
      hm catalog             List the guests that can be installed
      hm image <file>        Report what a disk image really is
      hm image <file> --convert <out>
                             Flatten a qcow2 image into a raw disk
      hm list                List the VMs in ~/Documents/HyperMachine
      hm boot --name <name>  Boot a VM in a window
      hm delete --name <n>   Delete a VM and its files

    Isolation:
      hm security --name <n>     What this VM exposes to the host, and the verdict
      hm network-test            Prove the live internet switch from inside the guest

    Linux:
      hm linux-create        Create a Linux VM from a catalog entry
      hm linux-validate      Build a Linux configuration and have the
                             framework validate it (needs the entitlement)
      hm rosetta-install     Install Rosetta for Linux guests

    macOS:
      hm macos-plan          Fetch the latest supported macOS restore image plan
      hm macos-validate      Build a macOS configuration and have the
                             framework validate it
      hm macos-install       Download macOS and install it into a new VM

    Options shared by the installers:
      --name <name>          VM name
      --ram <GiB>            guest memory
      --cpus <n>             vCPUs
      --disk <GiB>           boot disk size

    Options for linux-create:
      --guest <id>           catalog entry id (default: ubuntu-24.04-cloud-arm64)
      --iso <path>           installer ISO, for entries that need one
      --user <name>          account the unattended first boot creates
      --password <password>  password for that account
      --rosetta              expose Rosetta to the guest
      --secure-boot          enable EFI Secure Boot
      --isolated             create no network device at all (air-gapped)
      --lockdown             sealed posture: isolation, read-only shares, no
                             clipboard, no USB, no Rosetta

    Aliases kept for older scripts: macos-list, macos-boot.
    """)
}

func printHost() {
    let caps = HostCapabilities.current()
    let memory = Double(caps.physicalMemoryBytes) / 1_073_741_824

    print("""
    Host capabilities
      CPU cores        \(caps.performanceCores) performance + \(caps.efficiencyCores) efficiency (\(caps.totalCoreCount) total)
      Memory           \(String(format: "%.0f", memory)) GiB
      Max vCPUs        \(caps.maximumCPUCount)  (efficiency cores reserved for the host)
      Guest memory     \(String(format: "%.0f", Double(caps.minimumMemoryBytes) / 1_073_741_824))–\(String(format: "%.0f", Double(caps.maximumMemoryBytes) / 1_073_741_824)) GiB
      Nested virt      \(caps.supportsNestedVirtualization ? "available (M3 or newer)" : "unavailable (requires M3 or newer)")
    """)

    if !caps.supportsNestedVirtualization {
        print("\n  Note: this Mac cannot run a hypervisor inside a guest.")
    }
}

func validate(path: String) -> Int32 {
    let url = URL(fileURLWithPath: path)
    let data: Data
    do {
        data = try Data(contentsOf: url)
    } catch {
        FileHandle.standardError.write(Data("hm: cannot read \(path): \(error.localizedDescription)\n".utf8))
        return 66
    }

    let config: VMConfig
    do {
        config = try JSONDecoder().decode(VMConfig.self, from: data)
    } catch {
        FileHandle.standardError.write(Data("hm: \(path) is not a valid VM configuration: \(error)\n".utf8))
        return 65
    }

    let capabilities = HostCapabilities.current()
    let issues = config.validate(against: capabilities)

    print("\(config.name) — \(config.guest.rawValue), \(config.cpu.count) vCPU, \(String(format: "%.0f", config.memory.gibibytes)) GiB")
    print("  boot: \(config.bootMethod.rawValue)   network: \(config.network.mode.rawValue)   shares: \(config.shares.count)")

    guard !issues.isEmpty else {
        print("\n  No problems found.")
        return 0
    }

    print("")
    for issue in issues {
        let marker = issue.severity == .error ? "error" : "warning"
        print("  [\(marker)] \(issue.field): \(issue.message)")
    }

    let errorCount = issues.filter { $0.severity == .error }.count
    print("\n  \(errorCount) error(s), \(issues.count - errorCount) warning(s)")
    return errorCount > 0 ? 1 : 0
}

// MARK: - Smoke tests

/// Mirrors the reference machine: M1 Pro, 8 performance + 2 efficiency cores, 32 GiB.
let referenceHost = HostCapabilities(
    performanceCores: 8,
    efficiencyCores: 2,
    physicalMemoryBytes: 32 * 1_073_741_824,
    maximumCPUCount: 8,
    minimumMemoryBytes: 1 * 1_073_741_824,
    maximumMemoryBytes: 28 * 1_073_741_824,
    supportsNestedVirtualization: false
)

func runSelfTest() -> Int32 {
    var checks = 0
    var failures: [String] = []

    func check(_ condition: Bool, _ label: String) {
        checks += 1
        if !condition { failures.append(label) }
    }

    func config(
        guest: GuestKind = .linux,
        cpuCount: Int = 4,
        placement: CorePlacementPolicy = .balanced,
        memoryGiB: Double = 4,
        bootMethod: BootMethod = .efi,
        disks: [DiskConfig] = [DiskConfig(path: "a.raw", sizeBytes: 32 * 1_073_741_824, isBootVolume: true)],
        network: NetworkConfig = NetworkConfig(),
        shares: [ShareConfig] = [],
        display: DisplayConfig = DisplayConfig(),
        security: SecurityConfig = .default
    ) -> VMConfig {
        VMConfig(
            name: "selftest", guest: guest, bootMethod: bootMethod,
            cpu: CPUConfig(count: cpuCount, placement: placement),
            memory: MemoryConfig(gibibytes: memoryGiB),
            disks: disks, network: network, shares: shares,
            display: display, security: security
        )
    }

    func errors(_ c: VMConfig) -> [VMConfigIssue] {
        c.errors(against: referenceHost)
    }

    // --- Host topology ---
    let m1 = HostCapabilities.chipGeneration(brand: "Apple M1 Pro")
    let m3 = HostCapabilities.chipGeneration(brand: "Apple M3 Max")
    let m4 = HostCapabilities.chipGeneration(brand: "Apple M4")
    check(m1 == 1, "parse M1 generation (got \(String(describing: m1)))")
    check(m3 == 3, "parse M3 generation (got \(String(describing: m3)))")
    check(m4 == 4, "parse M4 generation (got \(String(describing: m4)))")
    check(HostCapabilities.chipGeneration(brand: "Intel(R) Core(TM) i9") == nil, "reject non-Apple brand")

    // --- vCPU bounds ---
    check(errors(config(cpuCount: 0)).count == 1, "zero vCPUs is an error")
    check(errors(config(cpuCount: 10)).count == 1, "10 vCPUs exceeds the host limit")
    check(config(cpuCount: 8).isRunnable(against: referenceHost), "8 vCPUs is allowed")
    check(config(cpuCount: 4, placement: .performancePreferred)
        .validate(against: referenceHost)
        .contains { $0.field == "cpu.placement" && $0.severity == .warning },
        "a placement policy warns that it is only a hint")

    // --- Memory bounds ---
    check(errors(config(memoryGiB: 0.5)).count == 1, "sub-1GiB memory is an error")
    check(errors(config(memoryGiB: 31)).count == 1, "31GiB leaves no room for the host")
    check(config(memoryGiB: 28).isRunnable(against: referenceHost), "28GiB is allowed")

    // --- Boot method ---
    check(config(guest: .macOS, memoryGiB: 8, bootMethod: .macRestore).isRunnable(against: referenceHost),
          "macOS with a restore image is valid")
    check(errors(config(guest: .macOS, memoryGiB: 8, bootMethod: .efi)).first?.field == "bootMethod",
          "macOS with EFI boot is rejected")
    check(errors(config(bootMethod: .macRestore)).first?.field == "bootMethod",
          "Linux with a restore image is rejected")

    // --- Storage ---
    check(errors(config(disks: [])).contains { $0.field == "disks" }, "no disks is an error")
    check(errors(config(disks: [DiskConfig(path: "a.raw", sizeBytes: 32 * 1_073_741_824)]))
        .contains { $0.message.contains("boot volume") }, "no boot volume is an error")

    // --- Networking ---
    check(errors(config(network: NetworkConfig(mode: .bridged, bridgedInterface: "en0")))
        .contains { $0.field == "network.mode" }, "bridged networking requires the opt-in")
    check(config(network: NetworkConfig(mode: .bridged, bridgedInterface: "en0"),
                 security: SecurityConfig(allowBridgedNetworking: true))
        .isRunnable(against: referenceHost), "bridged with opt-in and interface is valid")
    check(NetworkConfig().mode == .nat, "NAT is the default")

    // --- Shared folders ---
    check(ShareConfig(name: "x", hostPath: "/tmp/x").readOnly, "shares default to read-only")
    check(ShareConfig(name: "work-files", hostPath: "/tmp").isValidMountTag, "accepts a valid mount tag")
    check(!ShareConfig(name: "a/b", hostPath: "/tmp").isValidMountTag, "rejects a tag with a slash")
    check(errors(config(shares: [ShareConfig(name: "d", hostPath: "/one"),
                                 ShareConfig(name: "d", hostPath: "/two")]))
        .contains { $0.field == "shares.name" }, "duplicate mount tags are an error")
    check(errors(config(shares: [ShareConfig(name: "a", hostPath: "/same"),
                                 ShareConfig(name: "b", hostPath: "/same")]))
        .contains { $0.field == "shares.hostPath" }, "duplicate host paths are an error")

    // --- Display ---
    check(config(display: DisplayConfig(widthPixels: 320, heightPixels: 240))
        .errors(against: referenceHost).contains { $0.field == "display" }, "a tiny display is an error")
    check(config(display: DisplayConfig(gpuAcceleration: true))
        .validate(against: referenceHost)
        .contains { $0.field == "display.gpuAcceleration" }, "GPU acceleration warns for Linux")
    check(!config(guest: .macOS, memoryGiB: 8, bootMethod: .macRestore,
                  display: DisplayConfig(gpuAcceleration: true))
        .validate(against: referenceHost)
        .contains { $0.field == "display.gpuAcceleration" }, "GPU acceleration is fine for macOS")

    // --- Normalization ---
    let huge = config(cpuCount: 64, memoryGiB: 512).normalized(for: referenceHost)
    check(huge.cpu.count == 8, "oversized vCPU count clamps to the host limit")
    check(huge.memory.bytes == 28 * 1_073_741_824, "oversized memory clamps to the host limit")
    check(huge.isRunnable(against: referenceHost), "a clamped config is runnable")

    let tiny = config(cpuCount: 0, memoryGiB: 0.001, display: DisplayConfig(widthPixels: 1, heightPixels: 1))
        .normalized(for: referenceHost)
    check(tiny.cpu.count == 1, "undersized vCPU count clamps up")
    check(tiny.display.widthPixels == 640, "undersized display clamps up")
    check(tiny.isRunnable(against: referenceHost), "a raised config is runnable")

    // --- Persistence ---
    if let data = try? JSONEncoder().encode(huge),
       let decoded = try? JSONDecoder().decode(VMConfig.self, from: data) {
        check(decoded == huge, "a config round-trips through JSON")
    } else {
        check(false, "a config round-trips through JSON")
    }

    // --- Catalog ---
    check(Set(GuestCatalog.all.map(\.id)).count == GuestCatalog.all.count, "catalog ids are unique")
    for entry in GuestCatalog.all {
        check(entry.makeConfig(named: "c", capabilities: referenceHost)
            .isRunnable(against: referenceHost), "catalog entry \(entry.id) is runnable")
    }
    check(GuestCatalog.all.allSatisfy { !($0.guest != .macOS && $0.makeConfig(named: "c", capabilities: referenceHost).display.gpuAcceleration) },
          "only macOS catalog entries request an accelerated display")

    // --- This host ---
    let live = HostCapabilities.current()
    check(live.performanceCores >= 1, "the running host reports at least one performance core")
    check(live.physicalMemoryBytes > 0, "the running host reports its memory")
    check(live.maximumMemoryBytes < live.physicalMemoryBytes, "guests cannot take the whole machine")

    // --- Report ---
    print("hm selftest — reference host, M1 Pro 8P+2E / 32 GiB\n")
    if failures.isEmpty {
        print("  \(checks) checks passed")
        return 0
    }
    for failure in failures {
        print("  FAIL: \(failure)")
    }
    print("\n  \(failures.count) of \(checks) checks FAILED")
    return 1
}

// MARK: - Entry point

/// Builds a full macOS configuration and asks Virtualization.framework to
/// validate it. This exercises every device the factory assembles without
/// downloading a 15 GB restore image or installing anything.
func macosValidate() async -> Int32 {
    let root = URL(fileURLWithPath: NSTemporaryDirectory())
        .appendingPathComponent("hyper-machine-validate-\(UUID().uuidString)")
    defer { try? FileManager.default.removeItem(at: root) }

    do {
        let plan = try await MacOSInstallPlanner.latestSupported()
        print("plan: macOS \(plan.operatingSystemVersion) build \(plan.buildVersion)")

        let layout = MacOSVMFactory.StorageLayout(root: root)
        try layout.prepare()
        try plan.hardwareModelData.write(to: layout.hardwareModel, options: .atomic)

        _ = try MacOSVMFactory.createAuxiliaryStorage(
            at: layout.auxiliaryStorage,
            hardwareModelData: plan.hardwareModelData,
            overwrite: true
        )
        let identifier = try MacOSVMFactory.loadOrCreateMachineIdentifier(at: layout.machineIdentifier)
        print("auxiliary storage + machine identifier created")

        let sharedDirectory = root.appendingPathComponent("Shared")
        try FileManager.default.createDirectory(at: sharedDirectory, withIntermediateDirectories: true)

        // Virtualization.framework attaches a disk image but does not size it:
        // creating and sizing the file is the caller's job.
        let gib: UInt64 = 1_073_741_824
        let diskURL = root.appendingPathComponent("disk.raw")
        FileManager.default.createFile(atPath: diskURL.path, contents: nil)
        let handle = try FileHandle(forWritingTo: diskURL)
        try handle.truncate(atOffset: 32 * gib)
        try handle.close()

        var config = VMConfig.recommended(
            named: "macos-validate",
            guest: .macOS,
            capabilities: VZCapabilities.current()
        )
        config.cpu = CPUConfig(count: 4, placement: .performancePreferred)
        config.memory = MemoryConfig(gibibytes: 8)
        config.disks = [DiskConfig(path: diskURL.path, sizeBytes: 32 * gib, format: .raw, isBootVolume: true)]
        config.shares = [ShareConfig(name: "shared", hostPath: sharedDirectory.path, readOnly: true)]

        let warnings = config.validate(against: VZCapabilities.current())
        for warning in warnings {
            print("  [\(warning.severity)] \(warning.field): \(warning.message)")
        }
        guard config.isRunnable(against: VZCapabilities.current()) else {
            FileHandle.standardError.write(Data("hm: the configuration has errors\n".utf8))
            return 1
        }

        let vz = try MacOSVMFactory.makeConfiguration(
            from: config,
            hardwareModelData: plan.hardwareModelData,
            machineIdentifier: identifier,
            storage: layout
        )

        print("""

        Virtualization.framework accepted the configuration:
          vCPUs              \(vz.cpuCount)
          memory             \(vz.memorySize / 1_073_741_824) GiB
          platform           \(String(describing: type(of: vz.platform)))
          boot loader        \(vz.bootLoader.map { String(describing: type(of: $0)) } ?? "nil")
          storage devices    \(vz.storageDevices.count)
          network devices    \(vz.networkDevices.count)
          graphics devices   \(vz.graphicsDevices.count)
          directory shares   \(vz.directorySharingDevices.count)
          entropy devices    \(vz.entropyDevices.count)
          keyboards          \(vz.keyboards.count)
          pointing devices   \(vz.pointingDevices.count)
        """)
        return 0
    } catch let error as MacOSInstallError {
        FileHandle.standardError.write(Data("hm: \(error.description)\n".utf8))
        return 1
    } catch {
        FileHandle.standardError.write(Data("hm: \(error)\n".utf8))
        return 1
    }
}

func macosPlan() async -> Int32 {
    let frameworkRange = """
    framework allows  \(VZCapabilities.minimumAllowedCPUCount)-\
    \(VZCapabilities.maximumAllowedCPUCount) vCPUs, \
    \(VZCapabilities.minimumAllowedMemorySize / 1_073_741_824)-\
    \(VZCapabilities.maximumAllowedMemorySize / 1_073_741_824) GiB
    """
    print(frameworkRange)
    print("\nQuerying Apple for the latest supported macOS restore image...\n")

    do {
        let plan = try await MacOSInstallPlanner.latestSupported()
        print("""
        macOS \(plan.operatingSystemVersion) (build \(plan.buildVersion))
          image            \(plan.restoreImageURL.absoluteString)
          minimum vCPUs    \(plan.minimumSupportedCPUCount)
          minimum memory   \(String(format: "%.0f", plan.minimumMemoryGiB)) GiB
          hardware model   \(plan.hardwareModelData.count) bytes
        """)
        return 0
    } catch let error as MacOSInstallError {
        FileHandle.standardError.write(Data("hm: could not fetch the restore image.\n\n\(error.description)\n".utf8))
        return 1
    } catch {
        FileHandle.standardError.write(Data("hm: could not fetch the restore image: \(error)\n".utf8))
        return 1
    }
}

@MainActor
func run(_ arguments: [String]) async -> Never {
    switch arguments.first {
    case "host":
        printHost()
        exit(0)
    case "validate":
        guard arguments.count > 1 else {
            FileHandle.standardError.write(Data("usage: hm validate <config.json>\n".utf8))
            exit(64)
        }
        exit(validate(path: arguments[1]))
    case "selftest":
        exit(runSelfTest())
    case "macos-plan":
        exit(await macosPlan())
    case "macos-validate":
        exit(await macosValidate())
    case "macos-install":
        exit(await macosInstall(
            name: optionValue("--name", in: arguments) ?? "macOS",
            memoryGiB: Double(optionValue("--ram", in: arguments) ?? "8") ?? 8,
            cpus: Int(optionValue("--cpus", in: arguments) ?? "4") ?? 4,
            diskGiB: UInt64(optionValue("--disk", in: arguments) ?? "64") ?? 64
        ))
    case "catalog":
        exit(showCatalog())
    case "image":
        guard arguments.count > 1 else {
            FileHandle.standardError.write(
                Data("usage: hm image <file> [--convert <out.raw>]\n".utf8)
            )
            exit(64)
        }
        exit(imageInspect(
            path: arguments[1],
            convertTo: optionValue("--convert", in: arguments)
        ))
    case "list", "macos-list":
        exit(listVMs())
    case "linux-create":
        exit(await linuxCreate(
            name: optionValue("--name", in: arguments) ?? "linux",
            guestID: optionValue("--guest", in: arguments) ?? "ubuntu-24.04-cloud-arm64",
            memoryGiB: Double(optionValue("--ram", in: arguments) ?? "4") ?? 4,
            cpus: Int(optionValue("--cpus", in: arguments) ?? "2") ?? 2,
            diskGiB: UInt64(optionValue("--disk", in: arguments) ?? "32") ?? 32,
            isoPath: optionValue("--iso", in: arguments),
            username: optionValue("--user", in: arguments) ?? "hyper",
            password: optionValue("--password", in: arguments) ?? "hyper",
            rosetta: flagPresent("--rosetta", in: arguments),
            secureBoot: flagPresent("--secure-boot", in: arguments),
            isolated: flagPresent("--isolated", in: arguments),
            lockdown: flagPresent("--lockdown", in: arguments)
        ))
    case "security":
        guard let name = optionValue("--name", in: arguments) ?? arguments.dropFirst().first else {
            FileHandle.standardError.write(Data("usage: hm security --name <name>\n".utf8))
            exit(64)
        }
        exit(securityAudit(name: name))
    case "network-test":
        exit(await networkTest(
            imageEntry: optionValue("--guest", in: arguments) ?? "ubuntu-24.04-minimal-arm64",
            keep: flagPresent("--keep", in: arguments)
        ))
    case "linux-validate":
        exit(await linuxValidate())
    case "rosetta-install":
        exit(await rosettaInstall())
    case "delete":
        guard let name = optionValue("--name", in: arguments) ?? arguments.dropFirst().first else {
            FileHandle.standardError.write(Data("usage: hm delete --name <name>\n".utf8))
            exit(64)
        }
        exit(deleteVM(name: name))
    case "boot", "macos-boot":
        boot(name: optionValue("--name", in: arguments) ?? "macOS")
    default:
        printUsage()
        exit(arguments.first == nil || ["help", "-h", "--help"].contains(arguments.first!) ? 0 : 64)
    }
}

// Runs last, once every top-level global above has been initialised.
await run(Array(CommandLine.arguments.dropFirst()))
