import AppKit
import Foundation
import Virtualization
import HyperMachineCore
import HyperMachineVZ

// MARK: - Argument helpers

func optionValue(_ flag: String, in arguments: [String]) -> String? {
    guard let index = arguments.firstIndex(of: flag) else { return nil }
    let value = arguments.index(after: index)
    guard value < arguments.endIndex else { return nil }
    return arguments[value]
}

func flagPresent(_ flag: String, in arguments: [String]) -> Bool {
    arguments.contains(flag)
}

/// Prints throttled progress: a log written by a background job should have one
/// readable line per step, not thousands of carriage returns.
final class ProgressReporter: @unchecked Sendable {
    private let lock = NSLock()
    private var lastPercent = -1
    private let step: Int

    init(step: Int = 5) {
        self.step = step
    }

    func report(_ text: String) {
        print("  \(text)")
    }

    func report(fraction: Double, label: String) {
        let percent = Int((fraction * 100).rounded())
        lock.lock()
        let shouldPrint = percent >= lastPercent + step || percent >= 100
        if shouldPrint { lastPercent = percent }
        lock.unlock()

        if shouldPrint {
            print("  \(label): \(percent)%")
        }
    }
}

private func fail(_ message: String) -> Int32 {
    FileHandle.standardError.write(Data("hm: \(message)\n".utf8))
    return 1
}

// MARK: - list

func listVMs() -> Int32 {
    let vms = VMStore.all()
    guard !vms.isEmpty else {
        print("No VMs yet.")
        print("  Create a Linux one with: hm linux-create --name linux --guest ubuntu-24.04-cloud-arm64")
        return 0
    }
    print("VMs in \(VMStore.root.path):\n")
    for stored in vms {
        let config = stored.config
        let memory = String(format: "%.0f", config.memory.gibibytes)
        print("  \(config.name)")
        print("    \(config.guest.rawValue)   \(config.cpu.count) vCPU   \(memory) GiB   network \(config.network.mode.rawValue)")
        if let from = stored.installedFrom {
            print("    from       \(from.catalogName)\(from.build.map { " (\($0))" } ?? "")")
        }
        if let media = config.installMedia.first {
            print("    installer  \(URL(fileURLWithPath: media.path).lastPathComponent) still attached")
        }
        print("    status     \(stored.installed ? "installed" : "not installed")")
    }
    return 0
}

// MARK: - catalog

func showCatalog() -> Int32 {
    print("Guests HyperMachine can install:\n")
    for entry in GuestCatalog.all {
        let mark = entry.isImplemented ? " " : "✗"
        print("\(mark) \(entry.id)")
        print("    \(entry.name)")
        print("    \(entry.installKind.description)")
        if !entry.isImplemented {
            print("    no engine for this guest yet")
        }
    }
    print("\n  ✗ = no engine yet. Use `hm linux-create --guest <id>` to create one.")
    return 0
}

// MARK: - linux-create

func linuxCreate(
    name: String,
    guestID: String,
    memoryGiB: Double,
    cpus: Int,
    diskGiB: UInt64,
    isoPath: String?,
    username: String,
    password: String?,
    rosetta: Bool,
    secureBoot: Bool,
    isolated: Bool = false,
    lockdown: Bool = false
) async -> Int32 {
    guard let entry = GuestCatalog.entry(id: guestID) else {
        return fail("unknown guest '\(guestID)'. Run `hm catalog` to see the list.")
    }
    guard entry.isImplemented else {
        return fail("\(entry.name) has no engine yet.")
    }
    // Fail closed on injection before touching disk. Mirrors CloudInitSeed rules.
    if username.range(of: "^[A-Za-z][A-Za-z0-9_-]{0,31}$", options: .regularExpression) == nil {
        return fail("username must start with a letter, 1-32 [a-z0-9_-].")
    }
    if let password, (password.isEmpty || password.count > 256 || password.contains("\n") || password.contains("\r")) {
        return fail("password must be 1-256 chars with no newlines. Prefer SSH keys; --password is visible in `ps`.")
    }
    if !VMStore.isValidName(name) {
        return fail("'\(name)' is not a usable VM name.")
    }

    let reporter = ProgressReporter()
    var announcedDownload = false
    var announcedConversion = false

    do {
        let stored = try await LinuxInstallDriver.create(
            LinuxInstallRequest(
                name: name,
                entry: entry,
                cpuCount: cpus,
                memoryGiB: memoryGiB,
                diskGiB: diskGiB,
                network: NetworkConfig(mode: isolated ? .isolated : .nat),
                security: SecurityConfig(efiSecureBoot: secureBoot, lockdown: lockdown),
                rosettaEnabled: rosetta,
                localImageURL: isoPath.map { URL(fileURLWithPath: $0) },
                cloudInit: CloudInitConfig(hostname: name, username: username, password: password)
            )
        ) { event in
            switch event {
            case .resolvingImage(let url):
                print("Guest image: \(url)")
            case .usingCachedImage(let url):
                print("Already cached: \(url.path)")
            case .downloading(let fraction, _, _):
                if !announcedDownload {
                    announcedDownload = true
                    print("Downloading into \(VMStore.linuxImageCache.path)")
                }
                reporter.report(fraction: fraction, label: "download")
            case .downloaded(let bytes):
                print(String(format: "  download complete: %.2f GiB", Double(bytes) / 1_073_741_824))
            case .verifyingChecksum(let manifest):
                print("Verifying against \(manifest)")
            case .checksumVerified(let digest):
                print("  checksum matches the vendor's manifest (\(digest)…)")
            case .checksumUnavailable(let detail):
                print("  no checksum to verify: \(detail)")
            case .inspectingImage(let filename):
                print("Inspecting \(filename) to find out what it really is")
            case .imageInspected(let detail):
                print("  \(detail)")
            case .convertingImage(let fraction, _, _):
                if !announcedConversion {
                    announcedConversion = true
                    print("Converting the qcow2 container into a raw disk")
                }
                reporter.report(fraction: fraction, label: "convert")
            case .imageReady(let detail):
                print("  boot disk \(detail)")
            case .copyingImage(let url):
                print("Creating the boot disk at \(url.path)")
            case .writingSeed(let url):
                print("Writing the cloud-init seed to \(url.path)")
            case .preparingStorage(let root):
                print("VM directory: \(root.path)")
            case .finished:
                break
            }
        }

        print("")
        print("\(stored.config.name) is ready.")
        print("  guest     \(entry.name)")
        print("  vCPUs     \(stored.config.cpu.count)")
        print("  memory    \(String(format: "%.0f", stored.config.memory.gibibytes)) GiB")
        print("  disk      \(diskGiB) GiB")
        // Only an ISO install leaves media to remove. A cloud image is ready to
        // boot as it stands; the seed volume is not an installer.
        if entry.requiresLocalImage && !stored.config.installMedia.isEmpty {
            print("  installer media is attached: boot it, complete the install, then remove it.")
        }
        print("")
        print("Boot it with: hm boot --name \(stored.config.name)")
        if stored.config.serialConsoleLogging {
            print("Guest serial output is appended to \((try? VMStore.layout(for: name))?.consoleLog.path ?? "console.log").")
        }
        return 0
    } catch let error as ImageChecksum.ChecksumError {
        return fail(error.description)
    } catch let error as CloudInitSeed.SeedError {
        return fail(error.description)
    } catch let error as LinuxInstallDriver.InstallError {
        return fail(error.description)
    } catch let error as VMBuildError {
        return fail(error.description)
    } catch let error as VMStoreError {
        return fail(error.description)
    } catch {
        return fail("\(error)")
    }
}

// MARK: - image

/// Report what an image file really is, and optionally flatten it to raw.
///
/// The file extension is not evidence: Ubuntu's arm64 cloud image is named
/// `.img` and is really a qcow2 container. This is the command that settles it,
/// without creating a VM and without a 3 GB download.
func imageInspect(path: String, convertTo: String?) -> Int32 {
    let source = URL(fileURLWithPath: path)
    guard FileManager.default.fileExists(atPath: source.path) else {
        return fail("no file at \(path).")
    }

    do {
        let probe = try DiskImageInspector.probe(source)
        print(source.lastPathComponent)
        print("  format            \(probe.format.description)")
        print("  file size         \(describeBytes(probe.fileSizeBytes))")
        if probe.format == .qcow2, let virtual = probe.virtualSizeBytes {
            print("  virtual disk      \(describeBytes(virtual))")
        }
        print("  GPT               \(probe.hasGPT ? "yes" : "no")")
        if let esp = probe.efiSystemPartition {
            let fat = esp.hasFATBootSector ? "FAT boot sector present" : "no FAT boot sector"
            print("  EFI system part   \(describeBytes(esp.sizeBytes)) (\(fat))")
        }
        print("  attachable as-is  \(probe.format.isDirectlyAttachable ? "yes" : "no")")
        print("  bootable          \(probe.isBootable ? "yes" : "no")")
        for line in probe.analysis { print("  · \(line)") }

        guard let convertTo else { return probe.isBootable ? 0 : 1 }

        guard probe.format == .qcow2 else {
            return fail(
                "\(source.lastPathComponent) is \(probe.format.description), "
                    + "so there is nothing to flatten."
            )
        }

        let destination = URL(fileURLWithPath: convertTo)
        print("")
        print("Flattening into \(destination.path)")
        let reporter = ProgressReporter()
        try QCOW2Converter.convert(from: source, to: destination) { progress in
            reporter.report(fraction: progress.fraction, label: "convert")
        }

        let converted = try DiskImageInspector.probe(destination)
        print("  raw disk          \(describeBytes(converted.effectiveSizeBytes))")
        print("  bootable          \(converted.isBootable ? "yes" : "no")")
        for line in converted.analysis { print("  · \(line)") }
        return converted.isBootable ? 0 : 1
    } catch let error as QCOW2Converter.ConversionError {
        return fail(error.description)
    } catch let error as DiskImageInspectorError {
        return fail(error.description)
    } catch {
        return fail("\(error)")
    }
}

func describeBytes(_ bytes: UInt64) -> String {
    let gib = Double(bytes) / 1_073_741_824
    if gib >= 1 { return String(format: "%.2f GiB", gib) }
    return String(format: "%.1f MiB", Double(bytes) / 1_048_576)
}

// MARK: - security

/// Report every host interface a VM exposes, and whether the posture is sealed.
///
/// Exits 0 when nothing in the configuration crosses the isolation boundary,
/// 1 when something does, so it can gate a script.
func securityAudit(name: String) -> Int32 {
    let stored: StoredVM
    do {
        stored = try VMStore.load(name: name)
    } catch let error as VMStoreError {
        return fail(error.description)
    } catch {
        return fail("\(error)")
    }

    let config = stored.config
    let effective = SecurityPolicy.effective(config)
    let enforcements = SecurityPolicy.enforcements(for: config)

    print("Security posture of \(config.name)")
    print("  guest             \(config.guest.rawValue)")
    print("  lockdown          \(config.security.lockdown ? "on" : "off")")
    if !enforcements.isEmpty {
        print("  networking        \(config.network.mode.description)")
        print("  → as built        \(effective.network.mode.description)")
        print("")
        print("  Lockdown overrides:")
        for enforcement in enforcements {
            print("    · \(enforcement.message)")
        }
    }
    print("")
    print("  Host interfaces as this VM will actually be built:")

    for exposure in SecurityPolicy.exposures(of: effective) {
        let mark: String
        switch exposure.level {
        case .sealed: mark = "sealed "
        case .limited: mark = "limited"
        case .open: mark = "OPEN   "
        }
        print("  [\(mark)] \(exposure.area)")
        print("             \(exposure.detail)")
    }

    let sealed = SecurityPolicy.isFullySealed(config)
    print("")
    if sealed {
        print("  Nothing this project controls crosses the boundary.")
        print("")
        print("  This is not a claim that a hostile guest cannot escape. The virtio devices,")
        print("  the paravirtualized GPU and the XPC helper the guest runs in are Apple's code,")
        print("  and they remain attack surface no configuration can remove.")
        return 0
    }
    print("  Something above crosses the boundary. Run with lockdown for the sealed posture.")
    return 1
}

// MARK: - network-test

/// The watchdog this command installs in the guest on first boot.
///
/// `bash`'s `/dev/tcp` is the connectivity probe on purpose: it needs no
/// `curl`, no DNS and no extra package, and it fails immediately when there is
/// no backend behind the interface, which is exactly the thing being measured.
let networkWatchdogCommand = "nohup sh -c 'while true; do "
    + "if timeout 3 bash -c \"echo > /dev/tcp/1.1.1.1/443\" >/dev/null 2>&1; then s=ONLINE; else s=OFFLINE; fi; "
    + "a=$(ip -br addr show 2>/dev/null | tr -s \" \" \" \" | tr \"\\n\" \";\"); "
    + "r=$(ip route show default 2>/dev/null | tr -s \" \" \" \" | tr \"\\n\" \";\"); "
    + "echo \"$(date -Is) $s $a ROUTES=$r\" >> /mnt/hm-handshake/netwatch; "
    + "sleep 5; done' >/dev/null 2>&1 &"

/// Prove the network switch from inside the guest.
///
/// The host can only report what it intended. This creates a throwaway machine
/// whose first boot installs a watchdog that records its own view of its
/// networking every few seconds, then flips the live switch and reads back what
/// the guest actually saw. That is the difference between "no network device was
/// configured" and "the guest really cannot reach anything".
@MainActor
func networkTest(imageEntry: String, keep: Bool) async -> Int32 {
    guard let entry = GuestCatalog.entry(id: imageEntry) else {
        return fail("unknown guest '\(imageEntry)'. Run `hm catalog`.")
    }
    guard entry.installKind == .cloudImage else {
        return fail("\(entry.name) is not a cloud image, so this test cannot boot it unattended.")
    }

    let name = "network-test"
    let layout: VMLayout
    let watchFile: URL
    do {
        try? VMStore.delete(name: name)
        layout = try VMStore.layout(for: name)
        try layout.prepare()
        watchFile = layout.root
            .appendingPathComponent(LinuxInstallDriver.handshakeFolderName, isDirectory: true)
            .appendingPathComponent("netwatch")
    } catch {
        return fail("\(error)")
    }

    print("network isolation test")
    print("  building a throwaway '\(name)' VM with a network watchdog in the guest")

    let stored: StoredVM
    do {
        stored = try await LinuxInstallDriver.create(
            LinuxInstallRequest(
                name: name,
                entry: entry,
                cpuCount: 2,
                memoryGiB: 2,
                diskGiB: 8,
                cloudInit: CloudInitConfig(
                    hostname: name,
                    username: "hyper",
                    password: "hyper",
                    extraRunCommands: [networkWatchdogCommand]
                )
            ),
            onEvent: { _ in }
        )
    } catch let error as LinuxInstallDriver.InstallError {
        return fail(error.description)
    } catch {
        return fail("\(error)")
    }

    if VMStore.cachedLinuxImage(filename: entry.imageURL?.lastPathComponent ?? "") != nil {
        print("  image was already cached")
    }

    let configuration: VZVirtualMachineConfiguration
    do {
        configuration = try VMFactory.makeConfiguration(from: stored, storage: layout)
    } catch {
        return fail("could not build the machine: \(error)")
    }

    let machine = VZVirtualMachine(configuration: configuration)
    print("  network devices in the machine: \(machine.networkDevices.count)")
    do {
        try await machine.start()
    } catch {
        return fail("the VM failed to start: \(error)")
    }

    var failures = 0
    func check(_ label: String, _ passed: Bool, _ detail: String = "") {
        if passed {
            print("  ✔ \(label)")
        } else {
            failures += 1
            print("  ✘ \(label)\(detail.isEmpty ? "" : " — \(detail)")")
        }
    }

    func watchdogLines() -> [String] {
        guard let text = try? String(contentsOf: watchFile, encoding: .utf8) else { return [] }
        // Sanitize guest-written content: strip ANSI escapes and controls
        // before printing to the terminal.
        return text.split(whereSeparator: \.isNewline).map { line in
            String(line.unicodeScalars.filter { $0.value >= 32 && $0.value != 127 }.prefix(500))
        }.filter { !$0.isEmpty }
    }

    func waitForOutcome(_ outcome: String, after: Int, timeout: TimeInterval) async -> String? {
        let deadline = Date().addingTimeInterval(timeout)
        while Date() < deadline {
            let lines = watchdogLines()
            if lines.count > after,
               let match = lines[after...].first(where: { $0.contains(" \(outcome) ") }) {
                return match
            }
            try? await Task.sleep(nanoseconds: 1_000_000_000)
        }
        return nil
    }

    print("  waiting for the guest to boot and report (first boot takes a minute or two)")
    let online = await waitForOutcome("ONLINE", after: 0, timeout: 300)
    check("the guest boots and reaches the internet over NAT", online != nil, "no ONLINE report within 300s")
    if let line = online { print("     guest says: \(line)") }

    var seen = watchdogLines().count

    print("  switching the internet off…")
    do {
        let result = try await NetworkGate.setInternet(false, on: machine, name: name)
        check("the live switch reports the device disconnected", !result.isConnected, result.detail)
    } catch {
        check("the live switch could be applied", false, "\(error)")
    }
    let offline = await waitForOutcome("OFFLINE", after: seen, timeout: 90)
    check("the guest itself reports it can no longer reach anything", offline != nil, "still online after 90s")
    if let line = offline { print("     guest says: \(line)") }
    seen = watchdogLines().count

    print("  switching the internet back on…")
    do {
        // Verified, not assumed: the framework can accept the attachment and
        // discard it a moment later, which leaves the guest's link up with
        // nothing behind it. This waits and retries before believing it.
        let result = try await NetworkGate.setInternet(true, on: machine, name: name)
        check("the live switch reports the device reconnected", result.isConnected, result.detail)
    } catch {
        check("the switch could be restored", false, "\(error)")
    }
    let restored = await waitForOutcome("ONLINE", after: seen, timeout: 90)
    check("the guest itself reports connectivity is back", restored != nil, "still offline after 90s")
    if let line = restored { print("     guest says: \(line)") }

    print("  stopping the guest…")
    try? await machine.stop()

    if keep {
        print("  keeping \(name) for inspection")
    } else {
        try? VMStore.delete(name: name)
        print("  throwaway VM removed")
    }

    print("")
    print(failures == 0 ? "network isolation test: all checks passed" : "network isolation test: \(failures) check(s) failed")
    return failures == 0 ? 0 : 1
}

// MARK: - linux-validate

/// Builds a full generic-platform configuration — EFI firmware, a real variable
/// store, a virtio GPU, USB input, a virtio-fs share, a serial port and a
/// cloud-init seed built by `hdiutil` — and asks the framework to validate it.
/// No download, no boot.
func linuxValidate() async -> Int32 {
    let root = URL(fileURLWithPath: NSTemporaryDirectory())
        .appendingPathComponent("hyper-machine-linux-validate-\(UUID().uuidString)")
    defer { try? FileManager.default.removeItem(at: root) }

    do {
        let layout = VMLayout(root: root)
        try layout.prepare()

        let gib: UInt64 = 1_073_741_824
        try VMStore.createSizedDisk(at: layout.disk, sizeBytes: 32 * gib)

        let sharedFolder = root.appendingPathComponent("Shared", isDirectory: true)
        try FileManager.default.createDirectory(at: sharedFolder, withIntermediateDirectories: true)

        let seed = CloudInitConfig(hostname: "linux-validate", username: "hyper", password: "hyper")
        try CloudInitSeed.makeSeedISO(at: layout.cloudInitSeed, config: seed)
        let seedBytes = (try FileManager.default
            .attributesOfItem(atPath: layout.cloudInitSeed.path)[.size] as? NSNumber)?
            .uint64Value ?? 0

        var config = VMConfig.recommended(
            named: "linux-validate",
            guest: .linux,
            capabilities: VZCapabilities.current()
        )
        config.cpu = CPUConfig(count: 2, placement: .balanced)
        config.memory = MemoryConfig(gibibytes: 4)
        config.disks = [
            DiskConfig(path: layout.disk.path, sizeBytes: 32 * gib, format: .raw, isBootVolume: true),
            DiskConfig(
                path: layout.cloudInitSeed.path,
                sizeBytes: seedBytes,
                format: .raw,
                readOnly: true,
                isInstallMedia: true
            )
        ]
        config.shares = [ShareConfig(name: "shared", hostPath: sharedFolder.path, readOnly: false)]

        for issue in config.validate(against: VZCapabilities.current()) {
            print("  [\(issue.severity.rawValue)] \(issue.field): \(issue.message)")
        }
        guard config.isRunnable(against: VZCapabilities.current()) else {
            return fail("the configuration has errors")
        }

        let stored = StoredVM(config: config, installed: true)
        let vz = try VMFactory.makeConfiguration(from: stored, storage: layout)

        print("""

        Virtualization.framework accepted the configuration:
          vCPUs              \(vz.cpuCount)
          memory             \(vz.memorySize / gib) GiB
          platform           \(String(describing: type(of: vz.platform)))
          boot loader        \(vz.bootLoader.map { String(describing: type(of: $0)) } ?? "nil")
          storage devices    \(vz.storageDevices.count)
          network devices    \(vz.networkDevices.count)
          graphics devices   \(vz.graphicsDevices.count)
          directory shares   \(vz.directorySharingDevices.count)
          entropy devices    \(vz.entropyDevices.count)
          keyboards          \(vz.keyboards.count)
          pointing devices   \(vz.pointingDevices.count)
          serial ports       \(vz.serialPorts.count)
        """)
        print("\n  cloud-init seed built: \(seedBytes) bytes, label \(CloudInitSeed.volumeLabel)")
        print("  Rosetta for Linux: \(rosettaDescription())")
        return 0
    } catch let error as CloudInitSeed.SeedError {
        return fail(error.description)
    } catch let error as VMBuildError {
        return fail(error.description)
    } catch {
        return fail("\(error)")
    }
}

func rosettaDescription() -> String {
    switch VZLinuxRosettaDirectoryShare.availability {
    case .installed: return "installed"
    case .notInstalled: return "not installed (run `hm rosetta-install`)"
    case .notSupported: return "not supported on this Mac"
    @unknown default: return "unknown"
    }
}

// MARK: - rosetta-install

func rosettaInstall() async -> Int32 {
    print("Rosetta for Linux: \(rosettaDescription())")
    switch VZLinuxRosettaDirectoryShare.availability {
    case .installed:
        print("Nothing to do.")
        return 0
    case .notSupported:
        return fail("this Mac cannot run Rosetta for Linux.")
    default:
        print("Asking macOS to install Rosetta for Linux. macOS will prompt for confirmation.")
        let error: NSError? = await withCheckedContinuation { continuation in
            VZLinuxRosettaDirectoryShare.installRosetta { error in
                continuation.resume(returning: error as NSError?)
            }
        }
        if let error {
            return fail("\(error.localizedDescription)")
        }
        print("Done: \(rosettaDescription())")
        return 0
    }
}

// MARK: - delete

func deleteVM(name: String) -> Int32 {
    do {
        let layout = try VMStore.layout(for: name)
        guard FileManager.default.fileExists(atPath: layout.configFile.path) else {
            throw VMStoreError.notFound(name)
        }
        try VMStore.delete(name: name)
        print("Deleted \(name) and everything in \(layout.root.path).")
        return 0
    } catch let error as VMStoreError {
        return fail(error.description)
    } catch {
        return fail("\(error)")
    }
}

// MARK: - macos-install

func macosInstall(
    name: String,
    memoryGiB: Double,
    cpus: Int,
    diskGiB: UInt64
) async -> Int32 {
    let reporter = ProgressReporter()
    var announcedDownload = false
    var announcedInstall = false

    do {
        let stored = try await MacOSInstallDriver.install(
            MacOSInstallRequest(
                name: name,
                cpuCount: cpus,
                cpuPlacement: .performancePreferred,
                memoryGiB: memoryGiB,
                diskGiB: diskGiB
            )
        ) { event in
            // The CLI is the same driver as the app, just rendered as log lines.
            switch event {
            case .resolvingImage:
                print("Asking Apple for the latest supported macOS restore image...")
            case .resolved(let plan):
                print("  macOS \(plan.operatingSystemVersion) (build \(plan.buildVersion))")
            case .usingCachedImage(let url):
                print("Restore image already cached: \(url.path)")
            case .downloading(let fraction, _, _):
                if !announcedDownload {
                    announcedDownload = true
                    print("Downloading the restore image (~25 GB, resumable) into:\n  \(VMStore.restoreImageCache.path)")
                }
                reporter.report(fraction: fraction, label: "download")
            case .downloaded(_, let bytes):
                print(String(format: "  download complete: %.2f GiB", Double(bytes) / 1_073_741_824))
            case .preparingStorage(let root):
                print("VM directory: \(root.path)")
            case .installing(let fraction):
                if !announcedInstall {
                    announcedInstall = true
                    print("Installing macOS. This takes a while; do not quit.")
                }
                reporter.report(fraction: fraction, label: "install")
            case .finished:
                break
            }
        }

        print("")
        print("macOS \(stored.restoreImageBuild ?? "?") installed.")
        print("  name      \(name)")
        print("  vCPUs     \(stored.config.cpu.count)")
        print("  memory    \(String(format: "%.0f", stored.config.memory.gibibytes)) GiB")
        print("  disk      \(diskGiB) GiB")
        print("")
        print("Boot it with: hm boot --name \(name)")
        return 0
    } catch let error as MacOSInstallError {
        return fail(error.description)
    } catch let error as VMStoreError {
        return fail(error.description)
    } catch let error as VMBuildError {
        return fail(error.description)
    } catch {
        return fail("\(error)")
    }
}

// MARK: - boot

/// Strong references for the lifetime of the boot session. `NSApplication.run()`
/// never returns, but keeping these in one place makes ownership explicit.
enum BootSession {
    nonisolated(unsafe) static var machine: VZVirtualMachine?
    nonisolated(unsafe) static var view: VZVirtualMachineView?
    nonisolated(unsafe) static var window: NSWindow?
}

/// Closing the VM window has to mean something. Without this the window
/// disappears and the guest keeps running, invisible, until the process is
/// killed by hand.
final class BootWindowDelegate: NSObject, NSWindowDelegate {
    func windowWillClose(_ notification: Notification) {
        NSApplication.shared.terminate(nil)
    }
}

nonisolated(unsafe) let bootWindowDelegate = BootWindowDelegate()

private func describe(_ state: VZVirtualMachine.State) -> String {
    switch state {
    case .stopped: return "stopped"
    case .running: return "running"
    case .paused: return "paused"
    case .error: return "error"
    case .starting: return "starting"
    case .restoring: return "restoring"
    case .saving: return "saving"
    // macOS 27 added these three; their presence is why the CLI prints state
    // transitions at all rather than assuming a machine that started is a
    // machine that is running.
    case .pausing: return "pausing"
    case .resuming: return "resuming"
    case .stopping: return "stopping"
    @unknown default: return "unknown"
    }
}

@MainActor
func boot(name: String) -> Never {
    let stored: StoredVM
    let layout: VMLayout
    let configuration: VZVirtualMachineConfiguration

    do {
        stored = try VMStore.load(name: name)
        guard stored.installed else { throw VMStoreError.notInstalled(name) }
        // Re-validate on boot: a hand-edited vm.json must not reach the
        // framework with traversal paths or absurd sizes.
        let problems = stored.config.errors(against: HostCapabilities.current())
        if !problems.isEmpty {
            let first = problems.prefix(3).map { "\($0.field): \($0.message)" }.joined(separator: "; ")
            FileHandle.standardError.write(Data("hm: refusing to boot: invalid config: \(first)\n".utf8))
            exit(1)
        }
        layout = try VMStore.layout(for: name)
        configuration = try VMFactory.makeConfiguration(from: stored, storage: layout)
    } catch let error as VMStoreError {
        FileHandle.standardError.write(Data("hm: \(error.description)\n".utf8))
        exit(1)
    } catch let error as VMBuildError {
        FileHandle.standardError.write(Data("hm: \(error.description)\n".utf8))
        exit(1)
    } catch {
        FileHandle.standardError.write(Data("hm: \(error)\n".utf8))
        exit(1)
    }

    let application = NSApplication.shared
    // A terminal-launched binary is not a bundled app, so it has to ask for a
    // Dock icon and a focusable window explicitly.
    application.setActivationPolicy(.regular)

    let machine = VZVirtualMachine(configuration: configuration)
    let view = VZVirtualMachineView()
    view.virtualMachine = machine
    view.capturesSystemKeys = stored.config.captureSystemKeys
    view.automaticallyReconfiguresDisplay = stored.config.display.autoResizeDisplay

    let window = NSWindow(
        contentRect: NSRect(
            x: 0,
            y: 0,
            width: CGFloat(stored.config.display.widthPixels) / 2,
            height: CGFloat(stored.config.display.heightPixels) / 2
        ),
        styleMask: [.titled, .closable, .miniaturizable, .resizable],
        backing: .buffered,
        defer: false
    )
    window.title = "HyperMachine — \(name)"
    window.contentView = view
    window.isReleasedWhenClosed = false
    window.delegate = bootWindowDelegate
    window.center()
    window.makeKeyAndOrderFront(nil)

    BootSession.machine = machine
    BootSession.view = view
    BootSession.window = window

    // A window ignores mouse-moved events unless it is told otherwise, and a
    // view that is not first responder never sees keys. Without both of these
    // the guest gets a pointer that only moves while a button is held, and a
    // keyboard that does nothing.
    window.acceptsMouseMovedEvents = true
    window.makeFirstResponder(view)

    print("Booting \(name) (\(stored.config.cpu.count) vCPU, \(String(format: "%.0f", stored.config.memory.gibibytes)) GiB, \(stored.config.guest.rawValue)).")
    if stored.config.serialConsoleLogging {
        print("Guest serial output: \(layout.consoleLog.path)")
    }
    print("The VM window is open. Close it to stop the VM.")

    Task { @MainActor in
        do {
            try await machine.start()
            print("VM is running.")
        } catch {
            FileHandle.standardError.write(Data("hm: the VM failed to start: \(error)\n".utf8))
            exit(1)
        }

        // Watch the machine: a guest that dies on its own leaves the window
        // sitting there showing nothing, which is the least useful thing a
        // boot tool can do. Exit so the state is visible to a log or a script.
        var lastReported: VZVirtualMachine.State?
        while true {
            let state = machine.state
            if state != lastReported {
                lastReported = state
                print("guest state: \(describe(state))")
            }
            if state == .stopped || state == .error {
                print("The guest is no longer running.")
                exit(state == .error ? 1 : 0)
            }
            try? await Task.sleep(nanoseconds: 500_000_000)
        }
    }

    application.activate(ignoringOtherApps: true)
    application.run()
    exit(0)
}
