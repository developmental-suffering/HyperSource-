import Foundation
import HyperMachineCore
import HyperMachineVZ
import Virtualization

/// A headless check of the settings editor.
///
/// The editor is the one part of the app that cannot be reasoned about from a
/// unit test: it is a SwiftUI form, and its logic lives in an `@MainActor`
/// observable inside the app target. `--editor-selftest` drives the real model —
/// not a copy of it — against a throwaway VM and prints what it found, so
/// changing a resolution, adding a shared folder or resizing memory can be
/// verified without a screen.
///
/// The VM it edits is created and deleted inside the check, so a user's own
/// machines are never touched.
@MainActor
enum SettingsSelfTest {
    private static let vmName = "settings-selftest"

    static func runAndExit() -> Never {
        var failures = 0
        var checks = 0

        func check(_ label: String, _ passed: Bool, _ detail: String = "") {
            checks += 1
            if passed {
                print("  ✔ \(label)")
            } else {
                failures += 1
                print("  ✘ \(label)\(detail.isEmpty ? "" : " — \(detail)")")
            }
        }

        print("settings editor self-test")
        print("  a throwaway VM named '\(vmName)' is created and removed again")

        let shareRoot = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("hyper-machine-selftest-\(UUID().uuidString)")
        let first = shareRoot.appendingPathComponent("one/work")
        let second = shareRoot.appendingPathComponent("two/work")

        do {
            let root = try VMStore.directory(for: vmName)
            try? FileManager.default.removeItem(at: root)

            try FileManager.default.createDirectory(at: first, withIntermediateDirectories: true)
            try FileManager.default.createDirectory(at: second, withIntermediateDirectories: true)

            // A stand-in VM: a real sparse boot disk in the real store, so every
            // path the editor touches exists.
            let layout = try VMStore.layout(for: vmName)
            try layout.prepare()
            let size: UInt64 = 16 * 1_073_741_824
            try VMStore.createSizedDisk(at: layout.disk, sizeBytes: size)

            var config = VMConfig.recommended(
                named: vmName,
                guest: .linux,
                capabilities: VZCapabilities.current()
            )
            config.disks = [
                DiskConfig(path: layout.disk.path, sizeBytes: size, format: .raw, isBootVolume: true)
            ]
            try VMStore.save(StoredVM(config: config, installed: true), name: vmName)

            let stored = try VMStore.load(name: vmName)
            let editor = VMEditorModel(
                mode: .edit(stored),
                capabilities: VZCapabilities.current(),
                bridgedInterfaces: VZBridgedNetworkInterface.networkInterfaces
            )

            // MARK: Resolution

            let original = stored.config.display.matchingPresetID
            guard let target = DisplayConfig.presets.first(where: { $0.id != original }) else {
                print("  ✘ no alternative resolution preset to test with")
                exit(1)
            }
            editor.resolutionPresetID = target.id
            editor.applyResolutionPreset()
            check(
                "a resolution preset reaches the editor's fields",
                editor.widthPixels == target.widthPixels && editor.heightPixels == target.heightPixels,
                "wanted \(target.name), got \(editor.widthPixels)×\(editor.heightPixels)"
            )
            check(
                "the chosen resolution reaches the configuration",
                editor.config.display.widthPixels == target.widthPixels
                    && editor.config.display.heightPixels == target.heightPixels
            )
            editor.widthPixels = 1600
            editor.heightPixels = 1000
            check("a custom size is not mistaken for a preset", editor.config.display.matchingPresetID == nil)

            // Back to the preset: this is the value the persistence checks below
            // look for, and re-applying one over a custom size is worth covering
            // on its own.
            editor.resolutionPresetID = target.id
            editor.applyResolutionPreset()
            check(
                "a preset can be re-applied over a custom size",
                editor.widthPixels == target.widthPixels && editor.heightPixels == target.heightPixels
            )

            // MARK: Shared folders

            editor.addShare(hostPath: first.path)
            editor.addShare(hostPath: second.path)
            check("shared folders are added", editor.shares.count == 2, "got \(editor.shares.count)")
            check(
                "mount tags are unique and valid",
                editor.shares.map(\.name) == ["work", "work-2"],
                "got \(editor.shares.map(\.name))"
            )
            check("shares start read-only", editor.shares.allSatisfy(\.readOnly))
            check("shares reach the configuration", editor.config.shares.count == 2)

            if let share = editor.shares.first {
                editor.bindingForReadOnly(share).wrappedValue = false
            }
            check("read-only can be switched off", editor.shares.first?.readOnly == false)

            if let extra = editor.shares.last {
                editor.removeShare(extra)
            }
            check("a share can be removed", editor.shares.count == 1)

            // MARK: Resources

            editor.cpuCount = 2
            editor.memoryGiB = min(editor.memoryGiB + 2, editor.maximumMemoryGiB)
            check("vCPU count reaches the configuration", editor.config.cpu.count == 2)
            check(
                "memory reaches the configuration",
                abs(editor.config.memory.gibibytes - editor.memoryGiB) < 0.001
            )
            check(
                "memory stays inside the framework's range",
                editor.memoryGiB >= editor.minimumMemoryGiB && editor.memoryGiB <= editor.maximumMemoryGiB
            )

            // MARK: Lockdown

            editor.lockdown = true
            check("lockdown reaches the configuration", editor.config.security.lockdown)
            check(
                "the form reports what lockdown overrides",
                !editor.lockdownOverrides.isEmpty,
                "a share is writable and the network is not isolated, so it should have something to say"
            )
            let hardened = SecurityPolicy.effective(editor.config)
            check("lockdown leaves no network device", hardened.network.mode.isAirGapped)
            check("lockdown makes every shared folder read-only", hardened.shares.allSatisfy { $0.readOnly })
            check("the sealed posture is recognised as sealed", SecurityPolicy.isFullySealed(editor.config))
            check(
                "lockdown is a warning, not an error, so the VM still builds",
                editor.errors.isEmpty,
                editor.errors.map { "\($0.field): \($0.message)" }.joined(separator: "; ")
            )
            editor.lockdown = false
            check("lockdown can be switched back off", !editor.config.security.lockdown)

            // MARK: Validation and persistence

            check(
                "the edited configuration validates",
                editor.errors.isEmpty,
                editor.errors.map { "\($0.field): \($0.message)" }.joined(separator: "; ")
            )

            let updated = try editor.applying(to: stored)
            try VMStore.save(updated, name: vmName)
            let reloaded = try VMStore.load(name: vmName)

            check("the resolution was written to disk", reloaded.config.display.widthPixels == target.widthPixels)
            check("the shared folder was written to disk", reloaded.config.shares.count == 1)
            check(
                "the shared folder kept its host path",
                reloaded.config.shares.first?.hostPath == first.path,
                "got \(reloaded.config.shares.first?.hostPath ?? "nothing")"
            )
            check(
                "the memory was written to disk",
                abs(reloaded.config.memory.gibibytes - editor.memoryGiB) < 0.001
            )
            check("the vCPU count was written to disk", reloaded.config.cpu.count == 2)
            check("editing did not change the guest family", reloaded.config.guest == .linux)
            check(
                "editing did not touch the boot disk",
                reloaded.config.bootDisk?.path == layout.disk.path
            )
            check(
                "editing did not invent installer media",
                reloaded.config.installMedia.isEmpty
            )

            // MARK: The framework's verdict

            let configuration = try VMFactory.makeConfiguration(from: reloaded, storage: layout)
            try configuration.validate()
            check("Virtualization.framework accepts the edited VM", true)
            print(
                "     devices: \(configuration.storageDevices.count) storage, "
                    + "\(configuration.directorySharingDevices.count) shared folder(s), "
                    + "\(configuration.graphicsDevices.count) graphics, "
                    + "\(configuration.networkDevices.count) network, "
                    + "\(configuration.memorySize / 1_073_741_824) GiB memory, "
                    + "\(configuration.cpuCount) vCPU"
            )

            try? FileManager.default.removeItem(at: root)
        } catch {
            failures += 1
            print("  ✘ the self-test could not finish: \(error)")
        }

        try? FileManager.default.removeItem(at: shareRoot)

        print("")
        if failures == 0 {
            print("settings editor: \(checks) checks passed")
        } else {
            print("settings editor: \(failures) of \(checks) checks failed")
        }
        exit(failures == 0 ? 0 : 1)
    }
}
