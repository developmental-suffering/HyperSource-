import AppKit
import SwiftUI
import HyperMachineCore
import HyperMachineVZ

/// The configuration form, for both a new VM and an existing one's settings.
///
/// Every control is bounded by what the framework actually allows on this host,
/// and the diagnostics section shows the same messages the engine will emit —
/// including the honest ones about core placement, Linux GPU support, and
/// unimplemented disk formats.
struct EditorView: View {
    @ObservedObject var editor: VMEditorModel
    @EnvironmentObject private var model: AppModel
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 0) {
            header
            Divider()
            Form {
                if !editor.isEditing { guestSection }
                nameSection
                appearanceSection
                hardwareSection
                storageSection
                displaySection
                inputSection
                networkSection
                shareSection
                if editor.guest == .linux { linuxSection }
                securitySection
                diagnosticsSection
            }
            .formStyle(.grouped)
            Divider()
            footer
        }
        .frame(minWidth: 620, idealWidth: 680, minHeight: 560, idealHeight: 720)
    }

    private var header: some View {
        HStack(spacing: 12) {
            Image(systemName: editor.isEditing ? "slider.horizontal.3" : "plus.circle")
                .font(.system(size: 26, weight: .light))
                .foregroundStyle(.tint)
            VStack(alignment: .leading, spacing: 1) {
                Text(editor.isEditing ? "Settings — \(editor.name)" : "New Virtual Machine")
                    .font(.title3.weight(.semibold))
                Text(editor.isEditing
                     ? "Changes take effect the next time this VM starts."
                     : "Configured against this host's real limits.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
        }
        .padding(20)
    }

    // MARK: - Sections

    private var guestSection: some View {
        Section("Guest") {
            Picker("Guest", selection: $editor.catalogID) {
                ForEach(GuestCatalog.all) { entry in
                    Text(entry.name).tag(entry.id)
                }
            }
            if let entry = editor.entry {
                LabeledContent("Install", value: entry.installKind.description)
                Text(entry.note)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
                if !entry.isImplemented {
                    Label(
                        "There is no engine for this guest yet. It is listed so the gap is visible.",
                        systemImage: "hammer"
                    )
                    .font(.caption)
                    .foregroundStyle(.orange)
                }
                if entry.requiresLocalImage {
                    installerImageRow(entry)
                }
            }
        }
    }

    @ViewBuilder
    private func installerImageRow(_ entry: GuestCatalogEntry) -> some View {
        LabeledContent("Installer image") {
            HStack(spacing: 8) {
                Text(editor.localImageURL?.lastPathComponent ?? "None chosen")
                    .foregroundStyle(editor.localImageURL == nil ? .secondary : .primary)
                    .lineLimit(1)
                    .truncationMode(.middle)
                Button("Choose…") { chooseISO() }
            }
        }
        if let page = entry.downloadPageURL {
            Button("Open the download page") {
                NSWorkspace.shared.open(page)
            }
            .buttonStyle(.link)
            .font(.caption)
        }
    }

    private var nameSection: some View {
        Section("Name") {
            if editor.canChangeName {
                TextField("Name", text: $editor.name)
                if !VMStore.isValidName(editor.name) {
                    Text("Use letters, digits, dots, dashes and underscores.")
                        .font(.caption)
                        .foregroundStyle(.red)
                } else if VMStore.names().contains(editor.name) {
                    Text("A VM called “\(editor.name)” already exists.")
                        .font(.caption)
                        .foregroundStyle(.red)
                }
            } else {
                LabeledContent("Name", value: editor.name)
                Text("Renaming is not supported; create a new VM instead.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
    }

    private var appearanceSection: some View {
        Section("Appearance") {
            Picker("Accent", selection: $editor.accent) {
                Text("Blue").tag("blue")
                Text("Green").tag("green")
                Text("Orange").tag("orange")
                Text("Purple").tag("purple")
                Text("Pink").tag("pink")
                Text("Teal").tag("teal")
                Text("Red").tag("red")
            }
            .help("Sidebar tint for this VM.")
        }
    }

    private var hardwareSection: some View {
        Section("Hardware") {
            Stepper(value: $editor.cpuCount, in: max(1, editor.capabilities.minimumCPUCount)...max(1, editor.maximumCPUCount)) {
                LabeledContent("vCPUs", value: "\(editor.cpuCount)")
            }
            Picker("Core placement", selection: $editor.placement) {
                ForEach(CorePlacementPolicy.allCases, id: \.self) { policy in
                    Text(policy.title).tag(policy)
                }
            }
            Text(editor.placement.explanation)
                .font(.caption)
                .foregroundStyle(.secondary)
            Label(
                """
                Apple Silicon does not let a VM pin its vCPUs to specific cores: macOS \
                ignores thread affinity on arm64, and a VM's vCPU threads are owned by \
                Virtualization.framework. This is a scheduling hint, not a reservation.
                """,
                systemImage: "info.circle"
            )
            .font(.caption)
            .foregroundStyle(.secondary)
            .fixedSize(horizontal: false, vertical: true)

            LabeledContent("Memory") {
                HStack(spacing: 10) {
                    Slider(
                        value: $editor.memoryGiB,
                        in: editor.minimumMemoryGiB...max(editor.minimumMemoryGiB, editor.maximumMemoryGiB),
                        step: 1
                    )
                    .frame(minWidth: 200)
                    Text(formatGiB(editor.memoryGiB))
                        .monospacedDigit()
                        .frame(width: 74, alignment: .trailing)
                }
            }
            Text("This Mac allows at most \(formatGiB(editor.maximumMemoryGiB)) for one guest.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private var storageSection: some View {
        Section("Storage") {
            Stepper(value: $editor.diskGiB, in: 8...1024, step: 8) {
                LabeledContent("Boot volume", value: formatGiB(editor.diskGiB))
            }
            Text(editor.isEditing
                 ? "Disks can be grown but never shrunk: truncating the file under a guest's file system destroys it."
                 : "A sparse file — only what the guest writes is allocated on the host.")
                .font(.caption)
                .foregroundStyle(.secondary)
            if let stored = editor.editingStored, stored.config.disks.count > 1 {
                ForEach(stored.config.disks.filter { !$0.isBootVolume }) { disk in
                    LabeledContent(
                        URL(fileURLWithPath: disk.path).lastPathComponent,
                        value: "\(formatGiB(disk.gibibytes)) · \(disk.kind)"
                    )
                }
            }
        }
    }

    private var displaySection: some View {
        Section("Display") {
            Picker("Resolution", selection: $editor.resolutionPresetID) {
                ForEach(DisplayConfig.presets) { preset in
                    Text(preset.name).tag(preset.id)
                }
                Text("Custom").tag("")
            }
            .onChange(of: editor.resolutionPresetID) { _, _ in
                editor.applyResolutionPreset()
            }

            if editor.resolutionPresetID.isEmpty {
                LabeledContent("Width") {
                    HStack(spacing: 10) {
                        Slider(value: Binding(
                            get: { Double(editor.widthPixels) },
                            set: { editor.widthPixels = Int($0) }
                        ), in: 640...7680, step: 16)
                        Text("\(editor.widthPixels)")
                            .monospacedDigit()
                            .frame(width: 60, alignment: .trailing)
                    }
                }
                LabeledContent("Height") {
                    HStack(spacing: 10) {
                        Slider(value: Binding(
                            get: { Double(editor.heightPixels) },
                            set: { editor.heightPixels = Int($0) }
                        ), in: 480...4320, step: 16)
                        Text("\(editor.heightPixels)")
                            .monospacedDigit()
                            .frame(width: 60, alignment: .trailing)
                    }
                }
            }

            Toggle("GPU acceleration", isOn: $editor.gpuAcceleration)
                .disabled(!editor.guest.hasGPUAccelerationSupport)
            Text(editor.guest.hasGPUAccelerationSupport
                 ? "macOS guests get Apple's Metal-backed paravirtualized GPU."
                 : "Linux and Windows guests get a 2D virtio-gpu surface: Apple exposes no accelerated GPU device for them. For 3D Linux, use UTM/QEMU + Venus outside HyperMachine.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            Stepper(value: $editor.pixelsPerInch, in: 72...600, step: 1) {
                LabeledContent("Density", value: "\(editor.pixelsPerInch) PPI\(editor.hidpi ? " ×2 HiDPI" : "")")
            }
            .help("Pixels per inch for macOS guests; sharpness hint for 2D Linux/Windows surfaces.")
            Toggle("HiDPI (Retina) rendering", isOn: $editor.hidpi)
                .help("Doubles effective PPI for sharper text on 2D surfaces.")
            Toggle("Resize guest with window", isOn: $editor.autoResizeDisplay)
                .help("When off, the guest keeps its configured resolution.")
        }
    }

    private var inputSection: some View {
        Section("Input") {
            Toggle("Capture system keys (⌘Tab etc.)", isOn: $editor.captureSystemKeys)
            Text("When off, system shortcuts stay on the Mac. ⌃⌥ releases input.")
                .font(.caption)
                .foregroundStyle(.secondary)
        }
    }

    private var networkSection: some View {
        Section("Networking") {
            Picker("Mode", selection: $editor.networkMode) {
                Text("NAT — internet through this Mac").tag(NetworkMode.nat)
                Text("Isolated — no network device at all").tag(NetworkMode.isolated)
                Text("Bridged — a peer on your LAN").tag(NetworkMode.bridged)
            }
            Text(editor.networkMode.isolationSummary)
                .font(.caption)
                .foregroundStyle(editor.networkMode.isAirGapped ? .secondary : .primary)
                .fixedSize(horizontal: false, vertical: true)
            if editor.networkMode == .bridged {
                if editor.bridgedInterfaces.isEmpty {
                    Text("No bridgeable interfaces are available on this Mac.")
                        .font(.caption)
                        .foregroundStyle(.red)
                } else {
                    Picker("Interface", selection: $editor.bridgedInterface) {
                        ForEach(editor.bridgedInterfaces, id: \.identifier) { interface in
                            Text(interface.localizedDisplayName ?? interface.identifier)
                                .tag(Optional(interface.identifier))
                        }
                    }
                }
            }
        }
    }

    private var shareSection: some View {
        Section("Shared Folders") {
            if editor.shares.isEmpty {
                Text("No folders are shared with this guest.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            ForEach(Array(editor.shares.enumerated()), id: \.offset) { index, share in
                HStack(spacing: 10) {
                    Image(systemName: "folder")
                        .foregroundStyle(.tint)
                    VStack(alignment: .leading, spacing: 1) {
                        Text(share.hostPath)
                            .lineLimit(1)
                            .truncationMode(.middle)
                        Text("mount tag “\(share.name)”")
                            .font(.caption)
                            .foregroundStyle(share.isValidMountTag ? .secondary : .red)
                    }
                    Spacer()
                    Toggle("Auto", isOn: editor.bindingForAutoMount(share))
                        .toggleStyle(.checkbox)
                        .help("Mount automatically on guest boot")
                    Toggle("Read-only", isOn: editor.bindingForReadOnly(share))
                        .toggleStyle(.checkbox)
                    Button {
                        editor.removeShare(share)
                    } label: {
                        Image(systemName: "minus.circle")
                    }
                    .buttonStyle(.borderless)
                }
            }
            Button {
                chooseFolder()
            } label: {
                Label("Add Folder…", systemImage: "folder.badge.plus")
            }
        }
    }

    private var linuxSection: some View {
        Section("Linux") {
            LabeledContent("Username") {
                TextField("hyper", text: $editor.username)
                    .textFieldStyle(.roundedBorder)
                    .frame(maxWidth: 200)
            }
            LabeledContent("Password") {
                SecureField("leave empty to disable password login", text: $editor.password)
                    .textFieldStyle(.roundedBorder)
                    .frame(maxWidth: 200)
            }
            Text("Lowercase letters, digits, - and _. Stored in the seed volume; prefer SSH keys for production.")
                .font(.caption)
                .foregroundStyle(.secondary)
            Divider()
            Toggle("Run x86-64 binaries with Rosetta", isOn: $editor.rosettaEnabled)
                .disabled(model.rosetta == .notSupported)
            HStack(spacing: 6) {
                Text("Rosetta for Linux: \(rosettaLabel)")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                if model.rosetta == .notInstalled {
                    Button("Install…") { model.installRosetta() }
                        .buttonStyle(.link)
                        .font(.caption)
                }
            }
            if editor.rosettaEnabled {
                Text("Mount the “\(LinuxVMFactory.rosettaMountTag)” share in the guest to enable it.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Toggle("EFI Secure Boot", isOn: $editor.efiSecureBoot)
            Text("Signs the guest's boot chain with an Apple-managed platform key.")
                .font(.caption)
                .foregroundStyle(.secondary)

            Toggle("Log the guest's serial console", isOn: $editor.serialConsoleLogging)
            Text("Appends guest serial output to console.log in the VM's folder. Useful when a guest never reaches a graphical session.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)
        }
    }

    private var rosettaLabel: String {
        switch model.rosetta {
        case .installed: return "installed"
        case .notInstalled: return "not installed"
        case .notSupported: return "not supported on this Mac"
        @unknown default: return "unknown"
        }
    }

    private var securitySection: some View {
        Section("Security") {
            Toggle("Share the clipboard with the guest", isOn: $editor.clipboardSharing)
            Toggle("Allow USB passthrough", isOn: $editor.usbPassthrough)
            Toggle("Allow bridged networking", isOn: $editor.allowBridgedNetworking)
            Text("All off by default. Each one widens the guest's reach into the host.")
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            Divider()

            Toggle("Lockdown — seal this machine", isOn: $editor.lockdown)
            Text("""
            Enforced where the devices are built, not just hidden in this form: no network \
            device, every shared folder read-only, and clipboard, USB, bridged networking \
            and Rosetta off. The boot handshake needs a writable share, so a locked-down \
            guest cannot report its first boot back. It is not a claim that a hostile guest \
            cannot escape: the framework's own virtio devices and Apple's code beneath them \
            remain shared with the host.
            """)
                .font(.caption)
                .foregroundStyle(.secondary)
                .fixedSize(horizontal: false, vertical: true)

            if !editor.lockdownOverrides.isEmpty {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Lockdown overrides:")
                        .font(.caption.weight(.semibold))
                    ForEach(editor.lockdownOverrides) { override in
                        Text("· \(override.message)")
                            .font(.caption)
                            .foregroundStyle(.orange)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                }
                .padding(.leading, 2)
            }
        }
    }

    private var diagnosticsSection: some View {
        Section("Diagnostics") {
            if editor.issues.isEmpty {
                Label("No problems found.", systemImage: "checkmark.circle.fill")
                    .foregroundStyle(.green)
            } else {
                ForEach(Array(editor.issues.enumerated()), id: \.offset) { _, issue in
                    HStack(alignment: .firstTextBaseline, spacing: 8) {
                        Image(systemName: issue.severity == .error
                              ? "xmark.octagon.fill"
                              : "exclamationmark.triangle.fill")
                            .foregroundStyle(issue.severity == .error ? .red : .orange)
                        VStack(alignment: .leading, spacing: 1) {
                            Text(issue.field)
                                .font(.caption.monospaced())
                                .foregroundStyle(.secondary)
                            Text(issue.message)
                                .fixedSize(horizontal: false, vertical: true)
                        }
                    }
                }
            }
        }
    }

    // MARK: - Footer

    private var footer: some View {
        HStack(spacing: 12) {
            if let entry = editor.entry, !editor.isEditing, entry.isImplemented {
                Text(entry.installKind.isUnattended
                     ? "Installs without further input."
                     : "You will finish this installation inside the guest.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Button("Cancel") {
                model.cancelEditing()
                dismiss()
            }
            .keyboardShortcut(.cancelAction)
            Button(editor.isEditing ? "Save" : "Create") {
                model.commit(editor)
                dismiss()
            }
            .keyboardShortcut(.defaultAction)
            .buttonStyle(.borderedProminent)
            .disabled(!editor.canCommit)
        }
        .padding(20)
    }

    // MARK: - Pickers

    private func chooseFolder() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = false
        panel.canChooseDirectories = true
        panel.allowsMultipleSelection = false
        panel.prompt = "Share"
        panel.message = "Choose a folder to expose to the guest."
        if panel.runModal() == .OK, let url = panel.url {
            editor.addShare(hostPath: url.path)
        }
    }

    private func chooseISO() {
        let panel = NSOpenPanel()
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = false
        panel.prompt = "Use Image"
        panel.message = "Choose the installer ISO for this guest."
        panel.allowedContentTypes = [.diskImage, .data]
        if panel.runModal() == .OK, let url = panel.url {
            editor.localImageURL = url
        }
    }
}
