import SwiftUI

/// Arguments the app was launched with.
///
/// `--boot <name>` starts a VM as the window appears. Launched through
/// LaunchServices (`open`), that makes a VM startable from a script or a login
/// item without a click — and, unlike a shell-backgrounded process, it survives
/// whatever launched it.
struct LaunchOptions {
    var bootVM: String?
    /// `--editor-selftest` checks the settings editor against a throwaway VM,
    /// prints the result and exits without opening a window. The editor is the
    /// one part of the app with no unit test, so this is how its logic gets
    /// verified on a machine with no screen attached.
    var editorSelfTest = false

    init(arguments: [String]) {
        editorSelfTest = arguments.contains("--editor-selftest")

        guard let flag = arguments.firstIndex(of: "--boot") else { return }
        let value = arguments.index(after: flag)
        guard value < arguments.endIndex else { return }
        bootVM = arguments[value]
    }
}

let launchOptions = LaunchOptions(arguments: CommandLine.arguments)

/// The HyperMachine app.
///
/// Launched from a `.app` bundle that `Scripts/build-app.sh` assembles and
/// ad-hoc signs with `com.apple.security.virtualization`. That signature is not
/// optional: Virtualization.framework refuses to create a VM — or even fetch
/// Apple's restore-image catalog — from an unsigned process.
@main
struct HyperMachineApp: App {
    @StateObject private var model = AppModel()

    init() {
        if launchOptions.editorSelfTest {
            SettingsSelfTest.runAndExit()
        }
    }

    var body: some Scene {
        WindowGroup("HyperMachine") {
            ContentView()
                .environmentObject(model)
                .frame(minWidth: 900, minHeight: 600)
        }
        .defaultSize(width: 1080, height: 720)
        .commands {
            // The app has its own "New Virtual Machine" affordance, so replace
            // the stock New Window item rather than duplicating it.
            CommandGroup(replacing: .newItem) {
                Button("New Virtual Machine…") {
                    model.beginCreate()
                }
                .keyboardShortcut("n")
                .disabled(model.install != nil)
            }
            CommandGroup(after: .toolbar) {
                Button("Reload VMs") { model.reload() }
                    .keyboardShortcut("r")
            }
        }

        // One window per running VM, keyed by name. Separate from the main
        // window so a guest can be full-screened or moved to another display
        // while the main window is still used to manage other machines.
        WindowGroup("Virtual Machine", id: "vm", for: String.self) { $name in
            VirtualMachineWindowView(name: name)
                .environmentObject(model)
                .frame(minWidth: 720, minHeight: 480)
        }
        .defaultSize(width: 1280, height: 860)
    }
}
