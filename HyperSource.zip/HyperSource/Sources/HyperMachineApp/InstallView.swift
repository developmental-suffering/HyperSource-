import AppKit
import SwiftUI

/// Shows an install's progress.
///
/// There is no cancel: `VZMacOSInstaller` has no supported way to abort once it
/// has started, and a killed download is what the resumable downloader is for —
/// re-running resumes rather than starting over.
struct InstallView: View {
    @ObservedObject var session: InstallSession
    @EnvironmentObject private var model: AppModel
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(spacing: 12) {
                if session.phase.isTerminal {
                    Image(systemName: session.phase == .failed
                          ? "exclamationmark.triangle.fill"
                          : "checkmark.circle.fill")
                        .font(.title2)
                        .foregroundStyle(session.phase == .failed ? .orange : .green)
                } else {
                    ProgressView()
                        .controlSize(.small)
                }
                VStack(alignment: .leading, spacing: 2) {
                    Text(session.phase == .finished ? "\(session.name) is ready" : session.phase.title)
                        .font(.headline)
                    Text(session.detail)
                        .font(.callout)
                        .foregroundStyle(.secondary)
                        .lineLimit(2)
                }
                Spacer()
            }

            if !session.phase.isTerminal {
                ProgressView(value: session.fraction)
            }

            if let failure = session.failure {
                Text(failure)
                    .font(.callout)
                    .foregroundStyle(.red)
                    .textSelection(.enabled)
                    .fixedSize(horizontal: false, vertical: true)
            }

            ScrollView {
                VStack(alignment: .leading, spacing: 4) {
                    ForEach(Array(session.lines.enumerated()), id: \.offset) { _, line in
                        Text(line)
                            .font(.caption.monospaced())
                            .textSelection(.enabled)
                            .frame(maxWidth: .infinity, alignment: .leading)
                    }
                }
                .padding(10)
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(.quaternary.opacity(0.4), in: RoundedRectangle(cornerRadius: 8))

            HStack {
                Button("Copy Log") {
                    let text = ([session.detail] + session.lines).joined(separator: "\n")
                    NSPasteboard.general.clearContents()
                    NSPasteboard.general.setString(text, forType: .string)
                }
                .help("Copy progress detail and log to the clipboard")
                Spacer()
                Button(session.phase == .finished ? "Start \(session.name)" : "Close") {
                    let finished = session.phase == .finished
                    let name = session.name
                    model.dismissInstall()
                    if finished, model.start(name: name) {
                        openWindow(id: "vm", value: name)
                    }
                }
                .keyboardShortcut(.defaultAction)
                .disabled(!session.phase.isTerminal)
            }
        }
        .padding(22)
        .frame(minWidth: 560, idealWidth: 640, minHeight: 420, idealHeight: 500)
    }
}
