import AppKit
import SwiftUI
import Virtualization

/// The guest's screen, in its own window.
///
/// The screen used to be a pane inside the main window, which made a running
/// machine look like a setting. Each running VM gets its own window now, so the
/// machine can be full-screened, moved to another display and kept open while
/// the main window is used to manage other VMs.
struct VirtualMachineWindowView: View {
    @EnvironmentObject private var model: AppModel
    /// Which VM this window is for. `nil` only transiently, while the window is
    /// being created.
    let name: String?

    var body: some View {
        Group {
            if let name, let running = model.running[name] {
                RunningGuestView(running: running)
            } else {
                IdleView(name: name)
            }
        }
    }
}

private struct RunningGuestView: View {
    @ObservedObject var running: RunningVM
    @EnvironmentObject private var model: AppModel

    var body: some View {
        VStack(spacing: 0) {
            ZStack {
                Color.black
                VirtualMachineScreenView(
                    machine: running.machine,
                    capturesSystemKeys: running.captureSystemKeys,
                    automaticallyReconfiguresDisplay: running.autoResizeDisplay
                )
            }
            .overlay(alignment: .top) {
                if running.state == .starting {
                    Text("Starting \(running.name)…")
                        .padding(.horizontal, 14)
                        .padding(.vertical, 8)
                        .background(.thinMaterial, in: Capsule())
                        .padding(14)
                }
            }

            Divider()

            HStack(spacing: 10) {
                Circle()
                    .fill(color)
                    .frame(width: 9, height: 9)
                Text(running.state.rawValue)
                    .font(.callout.weight(.medium))
                Text(running.name)
                    .font(.callout)
                    .foregroundStyle(.secondary)

                if let message = running.message {
                    Text(message)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }

                if let note = running.networkNote {
                    Text(note)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .truncationMode(.middle)
                }

                Spacer()

                NetworkSwitch(running: running)

                Button {
                    model.stop(name: running.name)
                } label: {
                    Label("Stop", systemImage: "stop.fill")
                }
                .disabled(running.state == .stopped)

                Text("Resize the window to change the guest's resolution · ⌃⌥ releases input")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            .padding(.horizontal, 14)
            .padding(.vertical, 9)
            .background(.bar)
        }
    }

    private var color: Color {
        switch running.state {
        case .running: return .green
        case .failed: return .red
        case .stopped: return .secondary
        case .starting: return .orange
        }
    }
}

/// The live internet switch for a running guest.
///
/// Off does not block traffic with a rule — it removes the attachment, so the
/// guest's frames have nowhere to go at all. On re-attaches NAT, and the change
/// is verified rather than assumed, because the framework may discard an
/// attachment moments after accepting it.
private struct NetworkSwitch: View {
    @ObservedObject var running: RunningVM

    var body: some View {
        if running.hasNetworkDevice {
            Toggle(isOn: Binding(
                get: { running.internetEnabled },
                set: { newValue in Task { await running.setInternet(newValue) } }
            )) {
                Label(
                    running.internetEnabled ? "Internet" : "No internet",
                    systemImage: running.internetEnabled ? "network" : "network.slash"
                )
            }
            .toggleStyle(.switch)
            .disabled(running.switchingNetwork || running.state != .running)
            .help("""
            Off detaches the guest's network device: no NAT, no bridge, nothing behind \
            the interface. On re-attaches NAT through this Mac.
            """)
        } else {
            Label("Air-gapped", systemImage: "wifi.slash")
                .font(.callout)
                .foregroundStyle(.secondary)
                .help("""
                This machine was created with no network device at all, so there is nothing \
                to switch on. Recreate it without isolation to give it a network.
                """)
        }
    }
}

private struct IdleView: View {
    @EnvironmentObject private var model: AppModel
    let name: String?

    var body: some View {
        VStack(spacing: 14) {
            Image(systemName: "display.slash")
                .font(.system(size: 40, weight: .light))
                .foregroundStyle(.tertiary)
            Text(name.map { "\($0) is not running" } ?? "No virtual machine")
                .font(.title3)
            if let name, let record = model.record(named: name) {
                Button("Start \(name)") {
                    model.start(name: record.name)
                }
                .buttonStyle(.borderedProminent)
            }
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

/// Wraps Apple's VM view and makes it actually usable.
///
/// Three things SwiftUI will not do for a representable, all of which are
/// needed for a guest you can control:
///
/// 1. The view only receives input through devices declared on the machine, so
///    the configuration must include a keyboard *and* a pointing device.
/// 2. A window ignores mouse-moved events unless told otherwise, and a relative
///    pointing device is fed by `mouseMoved:` — without this the cursor only
///    moves while a button is held.
/// 3. Nothing focuses the view, so key events never reach it.
struct VirtualMachineScreenView: NSViewRepresentable {
    let machine: VZVirtualMachine
    var capturesSystemKeys: Bool = true
    var automaticallyReconfiguresDisplay: Bool = true

    func makeNSView(context: Context) -> VZVirtualMachineView {
        let view = VZVirtualMachineView()
        view.virtualMachine = machine
        // Without this the guest never sees Command-Tab, Control-Option-Delete
        // and friends.
        view.capturesSystemKeys = capturesSystemKeys
        view.automaticallyReconfiguresDisplay = automaticallyReconfiguresDisplay

        // Done once, from makeNSView rather than updateNSView: the status line
        // republishes on every state change, and re-stealing first responder
        // that often would fight the user for focus.
        DispatchQueue.main.async { [weak view] in
            guard let view, let window = view.window else { return }
            window.acceptsMouseMovedEvents = true
            if window.firstResponder !== view {
                window.makeFirstResponder(view)
            }
        }
        return view
    }

    func updateNSView(_ view: VZVirtualMachineView, context: Context) {
        if view.virtualMachine !== machine {
            view.virtualMachine = machine
        }
        if view.capturesSystemKeys != capturesSystemKeys {
            view.capturesSystemKeys = capturesSystemKeys
        }
        if view.automaticallyReconfiguresDisplay != automaticallyReconfiguresDisplay {
            view.automaticallyReconfiguresDisplay = automaticallyReconfiguresDisplay
        }
    }
}
