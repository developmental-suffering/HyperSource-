import Foundation
import SwiftUI
import Virtualization
import HyperMachineVZ

/// A running VM and the view that shows it.
///
/// `VZVirtualMachine` owns its vCPU threads, so there is nothing here that
/// influences scheduling: the core-placement policy was already folded into the
/// configuration when the machine was built, and on Apple Silicon it is only a
/// hint. This type exists to own the machine's lifetime and to notice when the
/// guest shuts itself down.
///
/// The framework's own `VZVirtualMachineDelegate` is a nonisolated protocol, so
/// conforming to it from a main-actor type is a data-race warning in Swift 6.
/// A short poll of `machine.state` gets the same information with no unchecked
/// isolation in the middle: the only thing it loses is the framework's error
/// object, which for a guest-initiated shutdown is not interesting anyway.
@MainActor
final class RunningVM: ObservableObject, Identifiable {
    enum State: String {
        case starting = "Starting"
        case running = "Running"
        case stopped = "Stopped"
        case failed = "Failed"
    }

    let id = UUID()
    let name: String
    let machine: VZVirtualMachine
    let captureSystemKeys: Bool
    let autoResizeDisplay: Bool

    @Published private(set) var state: State = .stopped
    @Published private(set) var message: String?

    /// Whether the guest currently has a network backend attached.
    @Published private(set) var internetEnabled = false
    /// Set while a switch change is in flight, so a second flip cannot race it.
    @Published private(set) var switchingNetwork = false
    /// What the last switch did, including the framework refusing it.
    @Published private(set) var networkNote: String?
    /// False when the machine was built with no network device at all, in which
    /// case there is nothing to switch — only a recreation can add one.
    @Published private(set) var hasNetworkDevice = false

    private let onFinish: @MainActor () -> Void
    private var monitor: Task<Void, Never>?

    init(
        name: String,
        configuration: VZVirtualMachineConfiguration,
        captureSystemKeys: Bool = true,
        autoResizeDisplay: Bool = true,
        onFinish: @escaping @MainActor () -> Void
    ) {
        self.name = name
        self.machine = VZVirtualMachine(configuration: configuration)
        self.captureSystemKeys = captureSystemKeys
        self.autoResizeDisplay = autoResizeDisplay
        self.onFinish = onFinish
        self.hasNetworkDevice = !self.machine.networkDevices.isEmpty
        self.internetEnabled = NetworkGate.isConnected(self.machine)
    }

    /// Turn the guest's internet on or off while it runs.
    ///
    /// Verified rather than assumed: the framework can accept the attachment and
    /// discard it a moment later, leaving the guest's link up with nothing behind
    /// it. `NetworkGate` settles and retries before believing a re-attachment.
    func setInternet(_ enabled: Bool) async {
        guard hasNetworkDevice, !switchingNetwork else { return }
        switchingNetwork = true
        defer { switchingNetwork = false }

        do {
            let result = try await NetworkGate.setInternet(enabled, on: machine, name: name)
            internetEnabled = result.isConnected
            networkNote = result.detail
        } catch {
            // Read the real state back rather than guessing: a refused change
            // leaves the device detached, which is the safe end of the switch.
            internetEnabled = NetworkGate.isConnected(machine)
            networkNote = "\(error)"
        }
    }

    func start() async {
        state = .starting
        do {
            try await machine.start()
            state = .running
            startMonitoring()
        } catch {
            state = .failed
            message = "\(error)"
            onFinish()
        }
    }

    func stop() async {
        monitor?.cancel()
        guard machine.canStop else {
            state = .stopped
            return
        }
        do {
            try await machine.stop()
        } catch {
            // A guest that already powered itself off can report a failed stop;
            // that is not worth surfacing as a problem.
            message = "\(error)"
        }
        state = .stopped
    }

    /// Watch for the guest powering itself off, which the app would otherwise
    /// never notice — the embedded view just goes black.
    private func startMonitoring() {
        monitor?.cancel()
        monitor = Task { @MainActor [weak self] in
            while !Task.isCancelled {
                try? await Task.sleep(nanoseconds: 500_000_000)
                guard let self, !Task.isCancelled else { return }
                switch self.machine.state {
                case .stopped:
                    self.state = .stopped
                    self.monitor = nil
                    self.onFinish()
                    return
                case .error:
                    self.state = .failed
                    self.message = "The guest stopped with an error."
                    self.monitor = nil
                    self.onFinish()
                    return
                default:
                    continue
                }
            }
        }
    }
}
