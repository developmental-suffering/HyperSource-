import Foundation
import SwiftUI
import Virtualization
import HyperMachineCore
import HyperMachineVZ

/// The editable form behind both "New Virtual Machine" and "Settings".
///
/// One model for both, because they are the same set of controls. It derives a
/// `VMConfig` from the fields on demand, so the form shows exactly the
/// diagnostics the engine will produce, and nothing here can claim a capability
/// the host does not have: memory, vCPU count and the bridged interfaces all
/// come from the framework's own reported ranges.
@MainActor
final class VMEditorModel: ObservableObject, Identifiable {
    enum Mode {
        case create
        case edit(StoredVM)
    }

    let id = UUID()
    let mode: Mode
    let capabilities: HostCapabilities
    let bridgedInterfaces: [VZBridgedNetworkInterface]

    @Published var catalogID: String
    @Published var name: String
    @Published var cpuCount: Int
    @Published var placement: CorePlacementPolicy
    @Published var memoryGiB: Double
    @Published var diskGiB: Double
    @Published var resolutionPresetID: String
    @Published var widthPixels: Int
    @Published var heightPixels: Int
    @Published var pixelsPerInch: Int
    @Published var hidpi: Bool
    @Published var autoResizeDisplay: Bool
    @Published var captureSystemKeys: Bool
    @Published var accent: String
    @Published var gpuAcceleration: Bool
    @Published var networkMode: NetworkMode
    @Published var bridgedInterface: String?
    @Published var shares: [ShareConfig]
    @Published var clipboardSharing: Bool
    @Published var usbPassthrough: Bool
    @Published var allowBridgedNetworking: Bool
    @Published var efiSecureBoot: Bool
    @Published var lockdown: Bool
    @Published var rosettaEnabled: Bool
    @Published var serialConsoleLogging: Bool
    @Published var localImageURL: URL?
    @Published var username: String
    @Published var password: String

    init(
        mode: Mode,
        capabilities: HostCapabilities,
        bridgedInterfaces: [VZBridgedNetworkInterface]
    ) {
        self.mode = mode
        self.capabilities = capabilities
        self.bridgedInterfaces = bridgedInterfaces
        self.catalogID = GuestCatalog.all[0].id
        self.name = "macOS"
        self.cpuCount = 4
        self.placement = .performancePreferred
        self.memoryGiB = 8
        self.diskGiB = 64
        self.resolutionPresetID = DisplayConfig.presets.first {
            $0.widthPixels == 1920 && $0.heightPixels == 1080
        }?.id ?? ""
        self.widthPixels = 1920
        self.heightPixels = 1080
        self.pixelsPerInch = 160
        self.hidpi = false
        self.autoResizeDisplay = true
        self.captureSystemKeys = true
        self.accent = "blue"
        self.gpuAcceleration = true
        self.networkMode = .nat
        self.bridgedInterface = bridgedInterfaces.first?.identifier
        self.shares = []
        self.clipboardSharing = false
        self.usbPassthrough = false
        self.allowBridgedNetworking = false
        self.efiSecureBoot = false
        self.lockdown = false
        self.rosettaEnabled = false
        self.serialConsoleLogging = true
        self.localImageURL = nil
        self.username = "hyper"
        self.password = "hyper"

        if case .edit(let stored) = mode {
            load(from: stored)
        }
    }

    private func load(from stored: StoredVM) {
        let config = stored.config
        catalogID = GuestCatalog.all.first { $0.guest == config.guest }?.id ?? catalogID
        name = config.name
        cpuCount = config.cpu.count
        placement = config.cpu.placement
        memoryGiB = config.memory.gibibytes
        if let boot = config.bootDisk { diskGiB = (boot.gibibytes).rounded() }
        resolutionPresetID = config.display.matchingPresetID ?? ""
        widthPixels = config.display.widthPixels
        heightPixels = config.display.heightPixels
        pixelsPerInch = config.display.pixelsPerInch
        hidpi = config.display.hidpi
        autoResizeDisplay = config.display.autoResizeDisplay
        captureSystemKeys = config.captureSystemKeys
        accent = config.accent
        gpuAcceleration = config.display.gpuAcceleration
        networkMode = config.network.mode
        bridgedInterface = config.network.bridgedInterface
        shares = config.shares
        clipboardSharing = config.security.clipboardSharing
        usbPassthrough = config.security.usbPassthrough
        allowBridgedNetworking = config.security.allowBridgedNetworking
        efiSecureBoot = config.security.efiSecureBoot
        lockdown = config.security.lockdown
        rosettaEnabled = config.rosettaEnabled
        serialConsoleLogging = config.serialConsoleLogging
        if let from = stored.installedFrom {
            username = ""
            password = ""
            _ = from
        }
    }

    // MARK: - Derived

    var isEditing: Bool {
        if case .edit = mode { return true }
        return false
    }

    var editingStored: StoredVM? {
        if case .edit(let stored) = mode { return stored }
        return nil
    }

    /// Guest of the entry being created, or of the VM being edited.
    var guest: GuestKind {
        if let stored = editingStored { return stored.config.guest }
        return entry?.guest ?? .macOS
    }

    var entry: GuestCatalogEntry? {
        GuestCatalog.entry(id: catalogID)
    }

    var installKind: InstallKind? {
        if isEditing { return nil }
        return entry?.installKind
    }

    var maximumMemoryGiB: Double { Double(capabilities.maximumMemoryBytes) / 1_073_741_824 }
    var minimumMemoryGiB: Double { Double(capabilities.minimumMemoryBytes) / 1_073_741_824 }
    var maximumCPUCount: Int { capabilities.maximumCPUCount }

    /// The configuration the engine would build. In edit mode this starts from
    /// the stored config so the platform-specific parts (the boot disk beyond
    /// its size, installer media, the guest type) are preserved untouched.
    var config: VMConfig {
        var base: VMConfig
        if let stored = editingStored {
            base = stored.config
        } else {
            base = entry?.makeConfig(named: name, capabilities: capabilities)
                ?? VMConfig.recommended(named: name, guest: .macOS, capabilities: capabilities)
        }

        base.name = name
        base.cpu = CPUConfig(count: cpuCount, placement: placement)
        base.memory = MemoryConfig(gibibytes: memoryGiB)
        base.network = NetworkConfig(mode: networkMode, bridgedInterface: bridgedInterface)
        base.shares = shares
        base.rosettaEnabled = rosettaEnabled
        base.serialConsoleLogging = serialConsoleLogging
        base.security = SecurityConfig(
            clipboardSharing: clipboardSharing,
            usbPassthrough: usbPassthrough,
            allowBridgedNetworking: allowBridgedNetworking,
            efiSecureBoot: efiSecureBoot,
            lockdown: lockdown
        )

        var display = base.display
        display.widthPixels = widthPixels
        display.heightPixels = heightPixels
        display.pixelsPerInch = max(72, min(600, pixelsPerInch))
        display.hidpi = hidpi
        display.autoResizeDisplay = autoResizeDisplay
        display.gpuAcceleration = gpuAcceleration
        base.display = display
        base.captureSystemKeys = captureSystemKeys
        base.accent = accent

        // Only the boot volume's size is editable here. Data disks and installer
        // media are managed separately so a resize cannot touch them.
        if let index = base.disks.firstIndex(where: \.isBootVolume) {
            base.disks[index].sizeBytes = UInt64(diskGiB) * 1_073_741_824
        }
        return base
    }

    var issues: [VMConfigIssue] {
        config.validate(against: capabilities)
    }

    /// What lockdown will override in the current form, so the effect is
    /// visible while the settings are being edited rather than after the VM has
    /// been built.
    var lockdownOverrides: [SecurityPolicy.Enforcement] {
        SecurityPolicy.enforcements(for: config)
    }

    var errors: [VMConfigIssue] { issues.filter { $0.severity == .error } }
    var warnings: [VMConfigIssue] { issues.filter { $0.severity == .warning } }

    var nameIsUsable: Bool {
        if isEditing { return VMStore.isValidName(name) }
        return VMStore.isValidName(name) && !VMStore.names().contains(name)
    }

    /// An ISO install needs a file; a cloud image does not.
    var needsLocalImage: Bool {
        installKind == .installerISO
    }

    var hasRequiredImage: Bool {
        !needsLocalImage || localImageURL != nil
    }

    var canCommit: Bool {
        guard errors.isEmpty, nameIsUsable, hasRequiredImage else { return false }
        if isEditing { return true }
        return entry?.isImplemented == true
    }

    var canChangeName: Bool { !isEditing }

    // MARK: - Committing

    func makeRequest() -> InstallRequest {
        let selectedEntry = entry ?? GuestCatalog.all[0]
        switch selectedEntry.guest {
        case .macOS:
            return .macOS(
                MacOSInstallRequest(
                    name: name,
                    cpuCount: cpuCount,
                    cpuPlacement: placement,
                    memoryGiB: memoryGiB,
                    diskGiB: UInt64(diskGiB),
                    network: NetworkConfig(mode: networkMode, bridgedInterface: bridgedInterface),
                    shares: shares,
                    display: config.display,
                    security: config.security
                )
            )
        case .linux, .windows:
            return .linux(
                LinuxInstallRequest(
                    name: name,
                    entry: selectedEntry,
                    cpuCount: cpuCount,
                    cpuPlacement: placement,
                    memoryGiB: memoryGiB,
                    diskGiB: UInt64(diskGiB),
                    network: NetworkConfig(mode: networkMode, bridgedInterface: bridgedInterface),
                    shares: shares,
                    display: config.display,
                    security: config.security,
                    rosettaEnabled: rosettaEnabled,
                    serialConsoleLogging: serialConsoleLogging,
                    localImageURL: localImageURL,
                    cloudInit: CloudInitConfig(
                        hostname: name,
                        username: username.isEmpty ? "hyper" : username,
                        password: password.isEmpty ? nil : password
                    )
                )
            )
        }
    }

    /// Fold the edits back into the stored VM.
    ///
    /// - Throws: whatever `VMStore.resizeDisk` throws. Growing the boot disk is
    ///   the one edit that touches a file rather than just JSON.
    func applying(to stored: StoredVM) throws -> StoredVM {
        var updated = stored
        var edited = config
        edited.id = stored.config.id
        edited.guest = stored.config.guest
        edited.bootMethod = stored.config.bootMethod
        updated.config = edited

        // Grow, never shrink. A guest's file system would not survive the
        // alternative, so a smaller number here is simply ignored.
        if let boot = edited.bootDisk, let layout = try? VMStore.layout(for: stored.config.name) {
            try VMStore.resizeDisk(at: URL(fileURLWithPath: boot.path), to: boot.sizeBytes)
            _ = layout
        }
        return updated
    }

    // MARK: - Shared folders

    func addShare(hostPath: String) {
        let tag = URL(fileURLWithPath: hostPath).lastPathComponent
        var candidate = tag.isEmpty ? "shared" : tag
        var suffix = 2
        while shares.contains(where: { $0.name == candidate }) {
            candidate = "\(tag)-\(suffix)"
            suffix += 1
        }
        shares.append(ShareConfig(name: candidate, hostPath: hostPath, readOnly: true))
    }

    func removeShare(_ share: ShareConfig) {
        shares.removeAll { $0.id == share.id }
    }

    func bindingForReadOnly(_ share: ShareConfig) -> Binding<Bool> {
        Binding(
            get: { [weak self] in self?.shares.first { $0.id == share.id }?.readOnly ?? true },
            set: { [weak self] newValue in
                guard let self,
                      let index = self.shares.firstIndex(where: { $0.id == share.id })
                else { return }
                self.shares[index].readOnly = newValue
            }
        )
    }

    func bindingForAutoMount(_ share: ShareConfig) -> Binding<Bool> {
        Binding(
            get: { [weak self] in self?.shares.first { $0.id == share.id }?.autoMount ?? true },
            set: { [weak self] newValue in
                guard let self,
                      let index = self.shares.firstIndex(where: { $0.id == share.id })
                else { return }
                self.shares[index].autoMount = newValue
            }
        )
    }

    // MARK: - Resolution

    func applyResolutionPreset() {
        guard let preset = DisplayConfig.presets.first(where: { $0.id == resolutionPresetID })
        else { return }
        widthPixels = preset.widthPixels
        heightPixels = preset.heightPixels
    }
}
