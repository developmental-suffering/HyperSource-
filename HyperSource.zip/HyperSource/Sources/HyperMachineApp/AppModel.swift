import Foundation
import SwiftUI
import Virtualization
import HyperMachineCore
import HyperMachineVZ

/// A VM as it exists on disk, plus what the UI needs to show it.
struct VMRecord: Identifiable {
    var stored: StoredVM
    /// Bytes this VM actually occupies on the host.
    var allocatedBytes: UInt64

    var name: String { stored.config.name }
    var id: String { name }
    var installed: Bool { stored.installed }
    var config: VMConfig { stored.config }
    var hasInstallerMedia: Bool { !stored.config.installMedia.isEmpty }

    var summary: String {
        let memory = String(format: "%.0f", stored.config.memory.gibibytes)
        return "\(stored.config.cpu.count) vCPU · \(memory) GiB · \(stored.config.guest.rawValue)"
    }
}

/// What the install progress sheet is running.
enum InstallRequest {
    case macOS(MacOSInstallRequest)
    case linux(LinuxInstallRequest)

    var name: String {
        switch self {
        case .macOS(let request): return request.name
        case .linux(let request): return request.name
        }
    }
}

/// Everything the UI talks to. Behaviours live here rather than in views so the
/// window is a rendering of state, not a driver of it.
@MainActor
final class AppModel: ObservableObject {
    /// The framework's real budget, not the sysctl estimate: the controls in the
    /// editor have to match what `validate()` will actually enforce.
    @Published private(set) var capabilities: HostCapabilities
    @Published private(set) var brand: String?
    @Published private(set) var bridgedInterfaces: [VZBridgedNetworkInterface] = []
    @Published private(set) var rosetta: VZLinuxRosettaAvailability = .notInstalled

    @Published private(set) var vms: [VMRecord] = []
    @Published var selectedName: String?

    /// One editor per sheet; creating and editing share it.
    @Published var editor: VMEditorModel?
    @Published var install: InstallSession?
    /// Running machines, keyed by VM name. Each has its own window.
    @Published private(set) var running: [String: RunningVM] = [:]
    @Published var problem: String?

    init() {
        capabilities = VZCapabilities.current()
        brand = HostCapabilities.machineBrand
        bridgedInterfaces = VZBridgedNetworkInterface.networkInterfaces
        rosetta = VZLinuxRosettaDirectoryShare.availability
        reload()
    }

    var selectedRecord: VMRecord? {
        guard let selectedName else { return nil }
        return vms.first { $0.name == selectedName }
    }

    func reload() {
        vms = VMStore.names().compactMap { name in
            guard let stored = try? VMStore.load(name: name),
                  let layout = try? VMStore.layout(for: name)
            else { return nil }
            return VMRecord(
                stored: stored,
                allocatedBytes: VMStore.allocatedBytes(of: layout.disk)
            )
        }
        if selectedName == nil || !vms.contains(where: { $0.name == selectedName }) {
            selectedName = vms.first?.name
        }
    }

    func record(named name: String) -> VMRecord? {
        vms.first { $0.name == name }
    }

    // MARK: - Editor

    func beginCreate() {
        guard install == nil else { return }
        editor = VMEditorModel(
            mode: .create,
            capabilities: capabilities,
            bridgedInterfaces: bridgedInterfaces
        )
    }

    func beginEdit(_ record: VMRecord) {
        guard install == nil else { return }
        guard running[record.name] == nil else {
            problem = "Stop \(record.name) before changing its settings. A machine's devices are fixed while it runs."
            return
        }
        editor = VMEditorModel(
            mode: .edit(record.stored),
            capabilities: capabilities,
            bridgedInterfaces: bridgedInterfaces
        )
    }

    func cancelEditing() {
        editor = nil
    }

    /// Persist an edited configuration, or create the VM.
    func commit(_ editor: VMEditorModel) {
        switch editor.mode {
        case .edit(let original):
            do {
                let updated = try editor.applying(to: original)
                try VMStore.save(updated, name: updated.config.name)
                if editor.name != original.config.name {
                    // Renaming would mean moving the directory; refuse rather
                    // than half-do it.
                    problem = "Renaming a VM is not supported yet. Create a new one instead."
                }
                self.editor = nil
                reload()
                selectedName = updated.config.name
            } catch let error as VMStoreError {
                problem = error.description
            } catch {
                problem = "\(error)"
            }

        case .create:
            let request = editor.makeRequest()
            self.editor = nil
            startInstall(request)
        }
    }

    func removeInstallerMedia(from record: VMRecord) {
        guard running[record.name] == nil else {
            problem = "Stop \(record.name) before removing its installer media."
            return
        }
        var stored = record.stored
        stored.config.disks.removeAll(where: \.isInstallMedia)
        do {
            try VMStore.save(stored, name: record.name)
            reload()
        } catch {
            problem = "\(error)"
        }
    }

    func delete(_ record: VMRecord) {
        guard running[record.name] == nil else {
            problem = "Stop \(record.name) before deleting it."
            return
        }
        do {
            try VMStore.delete(name: record.name)
        } catch let error as VMStoreError {
            problem = error.description
        } catch {
            problem = "\(error)"
        }
        reload()
    }

    // MARK: - Installing

    func startInstall(_ request: InstallRequest) {
        guard install == nil else { return }
        let session = InstallSession(name: request.name)
        install = session

        Task { [weak self] in
            do {
                switch request {
                case .macOS(let mac):
                    _ = try await MacOSInstallDriver.install(mac) { event in
                        session.consume(event)
                    }
                case .linux(let linux):
                    _ = try await LinuxInstallDriver.create(linux) { event in
                        session.consume(event)
                    }
                }
                self?.reload()
            } catch {
                session.fail("\(error)")
            }
        }
    }

    func dismissInstall() {
        install = nil
        reload()
    }

    // MARK: - Running

    /// Boot a VM into its own window. Returns whether it started.
    @discardableResult
    func start(name: String) -> Bool {
        guard running[name] == nil else { return true }
        guard let record = record(named: name) else {
            problem = "No VM named '\(name)'."
            return false
        }
        guard record.installed else {
            problem = "\(name) has not finished installing."
            return false
        }

        do {
            let layout = try VMStore.layout(for: record.name)
            // Re-validate before boot: hand-edited vm.json must not boot.
            let problems = record.stored.config.errors(against: capabilities)
            if !problems.isEmpty {
                problem = "Refusing to boot: \(problems[0].field): \(problems[0].message)"
                return false
            }
            let configuration = try VMFactory.makeConfiguration(from: record.stored, storage: layout)
            let machine = RunningVM(
                name: record.name,
                configuration: configuration,
                captureSystemKeys: record.stored.config.captureSystemKeys,
                autoResizeDisplay: record.stored.config.display.autoResizeDisplay
            ) { [weak self] in
                self?.running[name] = nil
            }
            running[name] = machine
            Task { await machine.start() }
            return true
        } catch let error as VMBuildError {
            problem = error.description
            return false
        } catch {
            problem = "\(error)"
            return false
        }
    }

    func stop(name: String) {
        guard let machine = running[name] else { return }
        Task {
            await machine.stop()
            self.running[name] = nil
        }
    }

    func stopAll() {
        for name in running.keys { stop(name: name) }
    }

    // MARK: - Rosetta

    func installRosetta() {
        guard rosetta == .notInstalled else { return }
        VZLinuxRosettaDirectoryShare.installRosetta { [weak self] error in
            Task { @MainActor in
                guard let self else { return }
                if let error {
                    self.problem = "Rosetta for Linux could not be installed: \(error.localizedDescription)"
                }
                self.rosetta = VZLinuxRosettaDirectoryShare.availability
            }
        }
    }
}
