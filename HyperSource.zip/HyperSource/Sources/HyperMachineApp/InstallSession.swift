import Foundation
import HyperMachineVZ

/// Renders either install driver's events as something a person can watch.
@MainActor
final class InstallSession: ObservableObject, Identifiable {
    enum Phase {
        case resolving
        case downloading
        case verifying
        case preparing
        case installing
        case finished
        case failed

        var title: String {
            switch self {
            case .resolving: return "Resolving the image"
            case .downloading: return "Downloading"
            case .verifying: return "Verifying the download"
            case .preparing: return "Preparing storage"
            case .installing: return "Installing"
            case .finished: return "Done"
            case .failed: return "Failed"
            }
        }

        var isTerminal: Bool { self == .finished || self == .failed }
    }

    let id = UUID()
    let name: String

    @Published private(set) var phase: Phase = .resolving
    @Published private(set) var fraction: Double = 0
    @Published private(set) var detail: String = ""
    @Published private(set) var lines: [String] = []
    @Published private(set) var failure: String?

    /// Progress arrives on the main actor but not necessarily in order, so never
    /// let the bar move backwards within a phase.
    private var lastLoggedDecile = -1
    private var phaseStart = Date()
    private var phaseStartBytes: Int64 = 0

    init(name: String) {
        self.name = name
    }

    /// Move to a new phase, resetting the bar. Downloading, verifying and
    /// installing are separate progressions; running them into one bar would
    /// show it fall from 100% back to 0 for no visible reason.
    private func enter(_ next: Phase) {
        guard phase != next else { return }
        phase = next
        fraction = 0
        lastLoggedDecile = -1
        phaseStart = Date()
        phaseStartBytes = 0
    }

    private func throughputDetail(received: Int64, total: Int64) -> String {
        let gib = Double(received) / 1_073_741_824
        let base = total > 0
            ? String(format: "%.1f of %.1f GiB", gib, Double(total) / 1_073_741_824)
            : String(format: "%.1f GiB", gib)
        let elapsed = max(0.5, Date().timeIntervalSince(phaseStart))
        let rate = Double(max(0, received - phaseStartBytes)) / elapsed
        guard rate > 0, total > received else { return base }
        let mbps = rate / 1_048_576
        let eta = Int(Double(total - received) / rate)
        return String(format: "%@ · %.0f MB/s · ~%d:%02d left", base, mbps, eta / 60, eta % 60)
    }

    private func note(_ line: String) {
        lines.append(line)
    }

    private func logDecile(_ value: Double, label: String) {
        let decile = Int(value * 10)
        guard decile > lastLoggedDecile else { return }
        lastLoggedDecile = decile
        note("\(label): \(decile * 10)%")
    }

    // MARK: - macOS

    func consume(_ event: MacOSInstallEvent) {
        switch event {
        case .resolvingImage:
            enter(.resolving)
            detail = "Contacting Apple…"
            note("Querying the macOS restore-image catalog.")

        case .resolved(let plan):
            detail = "macOS \(plan.operatingSystemVersion) (build \(plan.buildVersion))"
            note("macOS \(plan.operatingSystemVersion), build \(plan.buildVersion).")
            note("""
            Apple's floor for this image: \(plan.minimumSupportedCPUCount) vCPUs, \
            \(String(format: "%.0f", plan.minimumMemoryGiB)) GiB. A smaller request \
            will be raised to match.
            """)

        case .usingCachedImage(let url):
            enter(.preparing)
            note("Reusing the cached restore image at \(url.path).")

        case .downloading(let reported, let received, let total):
            let firstMac = (phase != .downloading)
            enter(.downloading)
            if firstMac { phaseStartBytes = received }
            fraction = max(fraction, reported)
            detail = throughputDetail(received: received, total: total)
            logDecile(reported, label: "Downloaded")

        case .downloaded(_, let bytes):
            fraction = 1
            note(String(format: "Restore image complete (%.2f GiB).", Double(bytes) / 1_073_741_824))

        case .preparingStorage(let root):
            enter(.preparing)
            detail = "Creating the boot disk"
            note("VM directory: \(root.path)")

        case .installing(let reported):
            enter(.installing)
            fraction = max(fraction, reported)
            detail = "The guest is being installed; this takes a while."
            logDecile(reported, label: "Installed")

        case .finished:
            enter(.finished)
            fraction = 1
            detail = "\(name) is ready to boot."
            note("Install complete.")
        }
    }

    // MARK: - Linux

    func consume(_ event: LinuxInstallEvent) {
        switch event {
        case .resolvingImage(let url):
            enter(.resolving)
            detail = "Finding the guest image"
            note("Guest image: \(url)")

        case .usingCachedImage(let url):
            note("Already cached: \(url.path)")

        case .downloading(let reported, let received, let total):
            let firstLinux = (phase != .downloading)
            enter(.downloading)
            if firstLinux { phaseStartBytes = received }
            fraction = max(fraction, reported)
            detail = throughputDetail(received: received, total: total)
            logDecile(reported, label: "Downloaded")

        case .downloaded(let bytes):
            note(String(format: "Image complete (%.2f GiB).", Double(bytes) / 1_073_741_824))

        case .verifyingChecksum(let manifest):
            enter(.verifying)
            detail = "Checking the image against the vendor's checksum"
            note("Verifying against \(manifest)")

        case .checksumVerified(let digest):
            note("Checksum matches the vendor's manifest (\(digest)…).")

        case .checksumUnavailable(let detail):
            note("No checksum to verify: \(detail)")

        case .inspectingImage(let filename):
            enter(.verifying)
            detail = "Checking what the downloaded image really is"
            note("Inspecting \(filename)")

        case .imageInspected(let summary):
            note(summary)

        case .convertingImage(let reported, _, _):
            enter(.preparing)
            fraction = max(fraction, reported)
            detail = "Converting the image into a raw disk"
            logDecile(reported, label: "Converted")

        case .imageReady(let summary):
            note("Boot disk: \(summary)")

        case .copyingImage(let url):
            enter(.preparing)
            detail = "Cloning the image into the VM"
            note("Creating the boot disk at \(url.path)")

        case .writingSeed(let url):
            detail = "Writing the cloud-init seed"
            note("Writing the seed volume to \(url.path)")

        case .preparingStorage(let root):
            enter(.preparing)
            detail = "Preparing storage"
            note("VM directory: \(root.path)")

        case .finished:
            enter(.finished)
            fraction = 1
            detail = "\(name) is ready to boot."
            note("Done. The first boot configures the guest over cloud-init.")
        }
    }

    func fail(_ text: String) {
        phase = .failed
        failure = text
        lines.append(text)
    }
}
