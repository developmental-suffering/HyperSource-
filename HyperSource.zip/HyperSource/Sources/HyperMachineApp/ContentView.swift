import AppKit
import SwiftUI
import HyperMachineCore
import HyperMachineVZ

struct ContentView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.openWindow) private var openWindow
    @Environment(\.controlActiveState) private var controlActiveState

    var body: some View {
        NavigationSplitView {
            SidebarView()
                .navigationSplitViewColumnWidth(min: 260, ideal: 300, max: 360)
        } detail: {
            if let record = model.selectedRecord {
                VMDetailView(record: record)
            } else {
                WelcomeView()
            }
        }
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button {
                    model.beginCreate()
                } label: {
                    Label("New Virtual Machine", systemImage: "plus")
                }
                .help("Create a virtual machine")
                .disabled(model.install != nil)
            }
        }
        .sheet(item: $model.editor) { editor in
            EditorView(editor: editor)
                .environmentObject(model)
        }
        .sheet(item: $model.install) { session in
            InstallView(session: session)
                .environmentObject(model)
                .interactiveDismissDisabled(!session.phase.isTerminal)
        }
        .alert(
            "HyperMachine",
            isPresented: Binding(
                get: { model.problem != nil },
                set: { if !$0 { model.problem = nil } }
            ),
            presenting: model.problem
        ) { _ in
            Button("OK", role: .cancel) { model.problem = nil }
        } message: { problem in
            Text(problem)
        }
        .task {
            // `--boot <name>`: start a VM as the window appears, which makes a
            // VM launchable from a script or a login item with no click.
            if let name = launchOptions.bootVM {
                if model.start(name: name) {
                    openWindow(id: "vm", value: name)
                }
            }
        }
    }
}

// MARK: - Sidebar

private struct SidebarView: View {
    @EnvironmentObject private var model: AppModel
    @State private var search = ""
    @State private var filter: Filter = .all

    enum Filter: String, CaseIterable {
        case all = "All", running = "Running", macOS = "macOS", linux = "Linux"
    }

    var filtered: [VMRecord] {
        model.vms.filter { record in
            let q = search.trimmingCharacters(in: .whitespacesAndNewlines).lowercased()
            if !q.isEmpty, !record.name.lowercased().contains(q) { return false }
            switch filter {
            case .all: return true
            case .running: return model.running[record.name] != nil
            case .macOS: return record.config.guest == .macOS
            case .linux: return record.config.guest == .linux
            }
        }
    }

    var body: some View {
        VStack(spacing: 0) {
            HStack(spacing: 8) {
                Image(systemName: "magnifyingglass").foregroundStyle(.secondary)
                TextField("Search", text: $search)
                    .textFieldStyle(.plain)
                if !search.isEmpty {
                    Button { search = "" } label: { Image(systemName: "xmark.circle.fill") }
                        .buttonStyle(.borderless).foregroundStyle(.secondary)
                }
            }
            .padding(.horizontal, 10).padding(.vertical, 6)
            Picker("", selection: $filter) {
                ForEach(Filter.allCases, id: \.self) { f in Text(f.rawValue).tag(f) }
            }
            .pickerStyle(.segmented)
            .padding(.horizontal, 10).padding(.bottom, 6)
            List(selection: $model.selectedName) {
                if filtered.isEmpty {
                    VStack(alignment: .leading, spacing: 6) {
                        Text(model.vms.isEmpty ? "No virtual machines" : "No matches")
                            .font(.callout.weight(.medium))
                        Text("Create one to install macOS or Linux.")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                    .padding(.vertical, 6)
                    .listRowSeparator(.hidden)
                } else {
                    ForEach(filtered) { record in
                        VMRowView(record: record, isRunning: model.running[record.name] != nil)
                            .tag(record.name)
                            .contextMenu {
                                Button(model.running[record.name] != nil ? "Stop" : "Start") {
                                    if model.running[record.name] != nil { model.stop(name: record.name) }
                                    else { _ = model.start(name: record.name) }
                                }
                                Button("Settings…") { model.beginEdit(record) }
                                Button("Reveal in Finder") {
                                    if let layout = try? VMStore.layout(for: record.name) {
                                        NSWorkspace.shared.activateFileViewerSelecting([layout.root])
                                    }
                                }
                                Button("Delete…", role: .destructive) { model.delete(record) }
                            }
                    }
                }
            }
            .listStyle(.sidebar)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            HostFooter()
        }
    }
}

private struct VMRowView: View {
    let record: VMRecord
    let isRunning: Bool

    private var symbol: String {
        if isRunning { return "play.circle.fill" }
        if !record.installed { return "exclamationmark.circle" }
        if record.config.guest == .windows { return "app.window" }
        return record.config.guest == .macOS ? "macwindow" : "terminal"
    }

    private var tint: Color {
        if isRunning { return .green }
        if !record.installed { return .orange }
        switch record.config.accent {
        case "green": return .green
        case "orange": return .orange
        case "purple": return .purple
        case "pink": return .pink
        case "teal": return .teal
        case "red": return .red
        default: return .accentColor
        }
    }

    var body: some View {
        HStack(spacing: 9) {
            Image(systemName: symbol)
                .foregroundStyle(tint)
                .font(.system(size: 15))
            VStack(alignment: .leading, spacing: 1) {
                Text(record.name)
                    .lineLimit(1)
                Text(isRunning ? "Running" : record.summary)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                    .lineLimit(1)
            }
        }
        .padding(.vertical, 3)
    }
}

/// The host's real budget, so the numbers in the editor are never a surprise:
/// this is what the framework will actually enforce.
private struct HostFooter: View {
    @EnvironmentObject private var model: AppModel
    @State private var showDetails = false

    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            Divider()
            Button {
                showDetails.toggle()
            } label: {
                HStack(spacing: 6) {
                    Image(systemName: "cpu")
                    Text("\(model.brand ?? "Apple Silicon") · \(model.capabilities.performanceCores)P+\(model.capabilities.efficiencyCores)E · \(formatGiB(Double(model.capabilities.physicalMemoryBytes)))")
                        .font(.caption.weight(.semibold))
                        .lineLimit(1)
                    Spacer()
                    Image(systemName: showDetails ? "chevron.up" : "chevron.down")
                        .font(.caption2).foregroundStyle(.secondary)
                }
            }
            .buttonStyle(.plain)
            .help("Host virtualization budget")
            if showDetails {
                VStack(alignment: .leading, spacing: 2) {
                    Text(verbatim: "up to \(model.capabilities.maximumCPUCount) vCPUs · max \(formatGiB(Double(model.capabilities.maximumMemoryBytes))) per guest")
                    if model.capabilities.supportsNestedVirtualization {
                        Text("Nested virtualization available")
                    }
                }
                .font(.caption)
                .foregroundStyle(.secondary)
                .padding(.top, 4)
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.horizontal, 12)
        .padding(.vertical, 10)
        .background(.bar)
    }
}

// MARK: - Welcome

private struct WelcomeView: View {
    @EnvironmentObject private var model: AppModel

    var body: some View {
        VStack(spacing: 16) {
            Image(systemName: "shippingbox")
                .font(.system(size: 52, weight: .light))
                .foregroundStyle(.tertiary)
            VStack(spacing: 4) {
                Text("HyperMachine")
                    .font(.title2.weight(.semibold))
                Text("Local virtual machines on Apple's Virtualization framework.")
                    .foregroundStyle(.secondary)
            }
            Button {
                model.beginCreate()
            } label: {
                Label("Create a Virtual Machine", systemImage: "plus")
            }
            .buttonStyle(.borderedProminent)
            .controlSize(.large)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
}

// MARK: - Detail

struct VMDetailView: View {
    @EnvironmentObject private var model: AppModel
    @Environment(\.openWindow) private var openWindow
    let record: VMRecord

    private var isRunning: Bool { model.running[record.name] != nil }

    var body: some View {
        Form {
            Section {
                HStack(alignment: .center, spacing: 14) {
                    Image(systemName: record.config.guest == .macOS ? "macwindow" : "terminal")
                        .font(.system(size: 34, weight: .light))
                        .foregroundStyle(.tint)
                    VStack(alignment: .leading, spacing: 2) {
                        Text(record.name)
                            .font(.title2.weight(.semibold))
                        Text(statusLine)
                            .foregroundStyle(.secondary)
                    }
                    Spacer()
                    if isRunning {
                        Button(role: .destructive) {
                            model.stop(name: record.name)
                        } label: {
                            Label("Stop", systemImage: "stop.fill")
                        }
                    } else {
                        Button {
                            if model.start(name: record.name) {
                                openWindow(id: "vm", value: record.name)
                            }
                        } label: {
                            Label("Start", systemImage: "play.fill")
                        }
                        .buttonStyle(.borderedProminent)
                        .disabled(!record.installed)
                    }
                }
                .padding(.vertical, 4)
            }

            if !record.installed {
                Section {
                    Label(
                        "This VM has not finished installing.",
                        systemImage: "exclamationmark.triangle.fill"
                    )
                    .foregroundStyle(.orange)
                }
            }

            if record.hasInstallerMedia {
                Section {
                    Label(
                        "Installer media is attached. Boot the VM and complete the installation, then remove the media.",
                        systemImage: "opticaldisc"
                    )
                    .foregroundStyle(.secondary)
                    Button("Remove Installer Media") {
                        model.removeInstallerMedia(from: record)
                    }
                    .disabled(isRunning)
                }
            }

            Section("Essentials") {
                LabeledContent("Guest", value: record.config.guest.rawValue)
                LabeledContent("vCPUs", value: "\(record.config.cpu.count) · \(record.config.cpu.placement.title)")
                LabeledContent("Memory", value: "\(formatGiB(record.config.memory.gibibytes))")
                LabeledContent("Boot volume", value: bootDiskSummary)
                LabeledContent("Display", value: "\(record.config.display.widthPixels) × \(record.config.display.heightPixels)\(record.config.display.hidpi ? " · HiDPI" : "")")
                LabeledContent("Graphics", value: record.config.display.gpuAcceleration
                               ? "Metal-backed (paravirtualized)"
                               : "Virtio GPU (2D)")
                LabeledContent("Network", value: record.config.network.mode == .bridged
                               ? "Bridged — \(record.config.network.bridgedInterface ?? "?")"
                               : record.config.network.mode.description)
                LabeledContent("Folders", value: record.config.shares.isEmpty ? "None" : "\(record.config.shares.count) shared")
            }

            if !record.config.shares.isEmpty {
                Section("Shared Folders") {
                    ForEach(record.config.shares) { share in
                        VStack(alignment: .leading, spacing: 2) {
                            Text(share.hostPath)
                                .lineLimit(1)
                                .truncationMode(.middle)
                            Text("mount tag “\(share.name)”\(share.readOnly ? " · read-only" : " · writable")\(share.autoMount ? "" : " · manual mount")")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
            }

            DisclosureGroup("Advanced — paths, features, provenance") {
                LabeledContent("On disk", value: formatBytes(record.allocatedBytes))
                LabeledContent("Rosetta", value: record.config.rosettaEnabled ? "exposed" : "off")
                LabeledContent("Secure Boot", value: record.config.security.efiSecureBoot ? "on" : "off")
                LabeledContent("Serial log", value: record.config.serialConsoleLogging ? "on" : "off")
                LabeledContent("Captures keys", value: record.config.captureSystemKeys ? "on" : "off")
                LabeledContent("Auto-resize", value: record.config.display.autoResizeDisplay ? "on" : "off")
                if record.config.security.lockdown {
                    Label("Lockdown is on.", systemImage: "lock.shield")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                if let from = record.stored.installedFrom {
                    LabeledContent("Image", value: from.catalogName)
                    LabeledContent("Installed", value: from.date.formatted(date: .abbreviated, time: .shortened))
                }
                LabeledContent("Location") {
                    HStack(spacing: 8) {
                        Text(record.config.name)
                            .font(.body.monospaced())
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                        Button("Reveal in Finder") {
                            reveal()
                        }
                        .buttonStyle(.link)
                    }
                }
            }

            Section {
                HStack {
                    Button("Settings…") {
                        model.beginEdit(record)
                    }
                    .disabled(isRunning)
                    Spacer()
                    Button("Delete…", role: .destructive) {
                        model.delete(record)
                    }
                    .disabled(isRunning)
                }
            } footer: {
                Text(isRunning
                     ? "Stop the VM to change its settings: a machine's devices are fixed while it runs."
                     : "Changes take effect the next time the VM starts.")
            }
        }
        .formStyle(.grouped)
    }

    private var statusLine: String {
        if isRunning { return "Running" }
        if record.installed { return "Ready" }
        return "Not installed"
    }

    private var bootDiskSummary: String {
        guard let boot = record.config.bootDisk else { return "none" }
        return "\(formatGiB(boot.gibibytes)) (\(boot.format.rawValue))"
    }

    private func reveal() {
        guard let layout = try? VMStore.layout(for: record.name) else { return }
        NSWorkspace.shared.activateFileViewerSelecting([layout.root])
    }
}

// MARK: - Formatting

func formatGiB(_ value: Double) -> String {
    String(format: value < 10 ? "%.1f GiB" : "%.0f GiB", value)
}

func formatBytes(_ bytes: UInt64) -> String {
    let formatter = ByteCountFormatter()
    formatter.countStyle = .file
    return formatter.string(fromByteCount: Int64(bytes))
}

extension CorePlacementPolicy {
    var title: String {
        switch self {
        case .performancePreferred: return "Performance preferred"
        case .balanced: return "Balanced"
        case .efficiencyPreferred: return "Efficiency preferred"
        }
    }

    var explanation: String {
        switch self {
        case .performancePreferred: return "Ask for high-QoS vCPU threads, biased toward performance cores."
        case .balanced: return "No explicit bias; let the scheduler decide."
        case .efficiencyPreferred: return "Ask for low-QoS vCPU threads, biased toward efficiency cores."
        }
    }
}
