import Foundation

// MARK: - Guest

/// Which operating system family a VM is configured for. This drives which
/// boot path and which device set is legal, so it is NOT cosmetic.
public enum GuestKind: String, Codable, Sendable, CaseIterable {
    case macOS
    case linux
    case windows

    /// Only macOS guests can be given a GPU-accelerated display device by
    /// Apple's Virtualization.framework. Linux/Windows guests get a 2D
    /// virtio-gpu surface only.
    public var hasGPUAccelerationSupport: Bool {
        self == .macOS
    }
}

// MARK: - CPU

/// How the user wants vCPU work biased across the host's performance and
/// efficiency cores.
///
/// Apple Silicon has no CPU pinning: macOS ignores thread affinity tags on
/// arm64, and QoS classes are a scheduling *hint*, never a guarantee. This type
/// therefore describes an intent, and the UI must not present it as a
/// reservation.
public enum CorePlacementPolicy: String, Codable, Sendable, CaseIterable {
    /// Ask for high-QoS vCPU threads, biased toward performance cores.
    case performancePreferred
    /// No explicit bias; let the scheduler decide.
    case balanced
    /// Ask for low-QoS vCPU threads, biased toward efficiency cores.
    case efficiencyPreferred
}

public struct CPUConfig: Codable, Equatable, Sendable {
    public var count: Int
    public var placement: CorePlacementPolicy

    public init(count: Int, placement: CorePlacementPolicy = .balanced) {
        self.count = count
        self.placement = placement
    }
}

// MARK: - Memory

public struct MemoryConfig: Codable, Equatable, Sendable {
    public var bytes: UInt64

    public init(bytes: UInt64) {
        self.bytes = bytes
    }

    public init(gibibytes: Double) {
        self.bytes = UInt64(gibibytes * 1_073_741_824)
    }

    public var gibibytes: Double {
        Double(bytes) / 1_073_741_824
    }
}

// MARK: - Storage

public enum DiskFormat: String, Codable, Sendable, CaseIterable {
    case raw
    case sparseImage
    /// Sparse image encrypted with a user-supplied passphrase. Requirement #4.
    case encryptedSparseImage

    public var isEncrypted: Bool {
        self == .encryptedSparseImage
    }
}

public struct DiskConfig: Codable, Equatable, Sendable, Identifiable {
    public var id: UUID
    public var path: String
    public var sizeBytes: UInt64
    public var format: DiskFormat
    public var isBootVolume: Bool

    /// Newer than the first saved configs, so they are stored optionally and
    /// surfaced through the accessors below. A hand-written decoder would be
    /// the alternative; this keeps `VMConfig` decodable from every version of
    /// `vm.json` the project has ever written, with less ceremony.
    private var readOnlyStorage: Bool?
    private var isInstallMediaStorage: Bool?

    private enum CodingKeys: String, CodingKey {
        case id, path, sizeBytes, format, isBootVolume
        case readOnlyStorage = "readOnly"
        case isInstallMediaStorage = "isInstallMedia"
    }

    /// A writable data disk or a read-only one. Attaching a writable disk that
    /// the guest cannot write to is a silent surprise, so this is explicit.
    public var readOnly: Bool {
        get { readOnlyStorage ?? false }
        set { readOnlyStorage = newValue }
    }

    /// Installer media (an ISO). Read-only in practice, and removable once the
    /// guest has been installed.
    public var isInstallMedia: Bool {
        get { isInstallMediaStorage ?? false }
        set { isInstallMediaStorage = newValue }
    }

    public init(
        id: UUID = UUID(),
        path: String,
        sizeBytes: UInt64,
        format: DiskFormat = .raw,
        isBootVolume: Bool = false,
        readOnly: Bool = false,
        isInstallMedia: Bool = false
    ) {
        self.id = id
        self.path = path
        self.sizeBytes = sizeBytes
        self.format = format
        self.isBootVolume = isBootVolume
        self.readOnlyStorage = readOnly
        self.isInstallMediaStorage = isInstallMedia
    }

    public var gibibytes: Double {
        Double(sizeBytes) / 1_073_741_824
    }

    public var kind: String {
        if isInstallMedia { return "installer media" }
        if isBootVolume { return "boot volume" }
        return readOnly ? "read-only disk" : "data disk"
    }
}

// MARK: - Networking

public enum NetworkMode: String, Codable, Sendable, CaseIterable {
    /// NAT through the host. The guest reaches the internet and cannot be
    /// reached from the LAN. Safe default.
    case nat
    /// Guest appears as a peer on the physical LAN. Requires the separately
    /// approved `com.apple.vm.networking` entitlement.
    case bridged
    /// **No network device is created at all.**
    ///
    /// This is not a firewall and not a blocked route: there is no virtio-net
    /// device in the machine, so the guest has no interface to configure, no
    /// MAC address, nothing to send a frame from, and no guest driver talking to
    /// a host backend. That is the strongest isolation this framework can
    /// express, and the only one worth calling air-gapped.
    case isolated

    /// Whether the guest can reach anything outside its own machine.
    public var allowsInternet: Bool { self == .nat || self == .bridged }

    /// True only when no network device exists, rather than a device with
    /// nothing reachable behind it.
    public var isAirGapped: Bool { self == .isolated }

    /// Whether the guest shares a physical link with other machines on the LAN.
    public var isLANPeer: Bool { self == .bridged }

    public var description: String {
        switch self {
        case .nat: return "NAT (internet through the host)"
        case .bridged: return "Bridged (a peer on your LAN)"
        case .isolated: return "Isolated (no network device at all)"
        }
    }

    /// The one-line promise shown next to the control in the UI.
    public var isolationSummary: String {
        switch self {
        case .nat:
            return "The guest can reach the internet; the internet cannot reach the guest."
        case .bridged:
            return "The guest is a peer on your network and reachable by other machines on it."
        case .isolated:
            return "No network device is created. The guest has no interface, no address and nowhere to send a packet."
        }
    }
}

public struct NetworkConfig: Codable, Equatable, Sendable {
    public var mode: NetworkMode
    /// BSD interface name (e.g. "en0") when `mode == .bridged`.
    public var bridgedInterface: String?

    public init(mode: NetworkMode = .nat, bridgedInterface: String? = nil) {
        self.mode = mode
        self.bridgedInterface = bridgedInterface
    }
}

// MARK: - Shared folders

/// A host directory exposed to the guest over virtio-fs (requirement #5).
public struct ShareConfig: Codable, Equatable, Sendable, Identifiable {
    public var id: UUID
    /// Virtio-fs mount tag. Must be a valid tag: no slashes, no whitespace.
    public var name: String
    public var hostPath: String
    public var readOnly: Bool
    /// If true, mount automatically on guest boot.
    public var autoMount: Bool

    public init(
        id: UUID = UUID(),
        name: String,
        hostPath: String,
        readOnly: Bool = true,
        autoMount: Bool = true
    ) {
        self.id = id
        self.name = name
        self.hostPath = hostPath
        self.readOnly = readOnly
        self.autoMount = autoMount
    }

    public var isValidMountTag: Bool {
        guard !name.isEmpty, name.count <= 64 else { return false }
        guard name != "." && name != ".." else { return false }
        // Strict allow-list: injection via cloud-init shell/YAML is closed
        // by refusing quotes, $, ;, backticks, slashes and whitespace up front.
        return name.allSatisfy { $0.isLetter || $0.isNumber || $0 == "-" || $0 == "_" || $0 == "." }
    }

    /// Host path safety for validator use (string-level only).
    public var hasSafeHostPath: Bool {
        guard hostPath.hasPrefix("/"), !hostPath.isEmpty else { return false }
        // Reject traversal and home-expansion tricks; canonicalization
        // happens at build time.
        if hostPath.contains("..") || hostPath.contains("~") { return false }
        return true
    }
}

// MARK: - Display

public struct DisplayConfig: Codable, Equatable, Sendable {
    public var widthPixels: Int
    public var heightPixels: Int
    public var pixelsPerInch: Int
    /// Request an accelerated display device. Only honoured for macOS guests.
    public var gpuAcceleration: Bool
    /// Resize the guest display when the host window resizes.
    /// Stored optionally so every existing vm.json still decodes.
    private var autoResizeStorage: Bool?
    /// HiDPI (Retina) rendering hint for the guest display.
    private var hidpiStorage: Bool?

    private enum CodingKeys: String, CodingKey {
        case widthPixels, heightPixels, pixelsPerInch, gpuAcceleration
        case autoResizeStorage = "autoResizeDisplay"
        case hidpiStorage = "hidpi"
    }

    public init(
        widthPixels: Int = 1920,
        heightPixels: Int = 1080,
        pixelsPerInch: Int = 80,
        gpuAcceleration: Bool = true,
        autoResizeDisplay: Bool = true,
        hidpi: Bool = false
    ) {
        self.widthPixels = widthPixels
        self.heightPixels = heightPixels
        self.pixelsPerInch = pixelsPerInch
        self.gpuAcceleration = gpuAcceleration
        self.autoResizeStorage = autoResizeDisplay
        self.hidpiStorage = hidpi
    }

    /// Follow host window resizes. Wired to VZVirtualMachineView.
    public var autoResizeDisplay: Bool {
        get { autoResizeStorage ?? true }
        set { autoResizeStorage = newValue }
    }

    /// HiDPI rendering hint. Raises effective PPI for sharper 2D output
    /// on Linux/Windows where no Metal GPU exists.
    public var hidpi: Bool {
        get { hidpiStorage ?? false }
        set { hidpiStorage = newValue }
    }

    /// Effective PPI accounting for HiDPI.
    public var effectivePPI: Int { hidpi ? pixelsPerInch * 2 : pixelsPerInch }

    public static let minimumWidthPixels = 640
    public static let minimumHeightPixels = 480

    /// Resolutions offered in the UI. A guest display can be any size the
    /// device accepts; these are the ones people actually want.
    public static let presets: [DisplayPreset] = [
        DisplayPreset(name: "1280 × 800", widthPixels: 1280, heightPixels: 800),
        DisplayPreset(name: "1440 × 900", widthPixels: 1440, heightPixels: 900),
        DisplayPreset(name: "1680 × 1050", widthPixels: 1680, heightPixels: 1050),
        DisplayPreset(name: "1920 × 1080", widthPixels: 1920, heightPixels: 1080),
        DisplayPreset(name: "2560 × 1440", widthPixels: 2560, heightPixels: 1440),
        DisplayPreset(name: "3840 × 2160", widthPixels: 3840, heightPixels: 2160),
        DisplayPreset(name: "2560 × 1600", widthPixels: 2560, heightPixels: 1600),
        DisplayPreset(name: "3456 × 2234", widthPixels: 3456, heightPixels: 2234)
    ]

    /// Which preset this display matches, if any. Used to drive a picker that
    /// stays honest about a custom size.
    public var matchingPresetID: String? {
        DisplayConfig.presets
            .first { $0.widthPixels == widthPixels && $0.heightPixels == heightPixels }?
            .id
    }
}

/// A named screen size.
public struct DisplayPreset: Identifiable, Hashable, Sendable {
    public let name: String
    public let widthPixels: Int
    public let heightPixels: Int

    public var id: String { "\(widthPixels)x\(heightPixels)" }

    public init(name: String, widthPixels: Int, heightPixels: Int) {
        self.name = name
        self.widthPixels = widthPixels
        self.heightPixels = heightPixels
    }
}

// MARK: - Security

/// Secure-by-default knobs (requirement #4). Every default here is the
/// restrictive one; the user has to opt in to the risky behaviour.
public struct SecurityConfig: Codable, Equatable, Sendable {
    public var clipboardSharing: Bool
    public var usbPassthrough: Bool
    public var allowBridgedNetworking: Bool

    private var efiSecureBootStorage: Bool?
    private var lockdownStorage: Bool?

    private enum CodingKeys: String, CodingKey {
        case clipboardSharing, usbPassthrough, allowBridgedNetworking
        case efiSecureBootStorage = "efiSecureBoot"
        case lockdownStorage = "lockdown"
    }

    /// Lockdown: the hardened posture, enforced rather than suggested.
    ///
    /// When on, `SecurityPolicy` forces the networking to `isolated` (no network
    /// device at all), every shared folder read-only, and clipboard sharing, USB
    /// passthrough, bridged networking and Rosetta off — regardless of what the
    /// rest of the configuration says. The enforcement happens where the device
    /// set is built, so the settings cannot contradict the promise.
    ///
    /// It is not a claim that a guest cannot escape. It removes every host
    /// interface this project controls; the framework's own virtio devices and
    /// Apple's code underneath them remain the shared attack surface.
    public var lockdown: Bool {
        get { lockdownStorage ?? false }
        set { lockdownStorage = newValue }
    }

    /// EFI Secure Boot for generic-platform guests, using Apple's managed
    /// platform key. macOS-guests-only builds must leave this off: the Mac
    /// platform authenticates its own boot chain.
    public var efiSecureBoot: Bool {
        get { efiSecureBootStorage ?? false }
        set { efiSecureBootStorage = newValue }
    }

    public init(
        clipboardSharing: Bool = false,
        usbPassthrough: Bool = false,
        allowBridgedNetworking: Bool = false,
        efiSecureBoot: Bool = false,
        lockdown: Bool = false
    ) {
        self.clipboardSharing = clipboardSharing
        self.usbPassthrough = usbPassthrough
        self.allowBridgedNetworking = allowBridgedNetworking
        self.efiSecureBootStorage = efiSecureBoot
        self.lockdownStorage = lockdown
    }

    /// The configuration a brand new VM gets before the user touches anything.
    public static let `default` = SecurityConfig()
}

// MARK: - Boot

/// How the guest is booted. This is the single biggest fork in the engine.
public enum BootMethod: String, Codable, Sendable, CaseIterable {
    /// Apple restore image + `VZMacOSInstaller`. macOS guests only.
    case macRestore
    /// UEFI firmware boot from attached storage. Linux/Windows.
    case efi
    /// Direct kernel + initrd + cmdline boot. Fastest; requires our own kernel.
    case kernel
}

// MARK: - The VM

public struct VMConfig: Codable, Equatable, Sendable, Identifiable {
    public var id: UUID
    public var name: String
    public var guest: GuestKind
    public var bootMethod: BootMethod
    public var cpu: CPUConfig
    public var memory: MemoryConfig
    public var disks: [DiskConfig]
    public var network: NetworkConfig
    public var shares: [ShareConfig]
    public var display: DisplayConfig
    public var security: SecurityConfig

    // Additive fields, stored optionally so every config this project has ever
    // written still decodes. `private` storage plus a public accessor keeps the
    // JSON key tidy without a hand-written decoder.
    private var rosettaEnabledStorage: Bool?
    private var serialConsoleLoggingStorage: Bool?
    private var captureSystemKeysStorage: Bool?
    private var accentStorage: String?

    private enum CodingKeys: String, CodingKey {
        case id, name, guest, bootMethod, cpu, memory, disks, network, shares, display, security
        case rosettaEnabledStorage = "rosettaEnabled"
        case serialConsoleLoggingStorage = "serialConsoleLogging"
        case captureSystemKeysStorage = "captureSystemKeys"
        case accentStorage = "accent"
    }

    /// Expose Apple's Rosetta for Linux to an arm64 Linux guest, so x86-64
    /// binaries inside it run at native speed. Linux guests on Apple Silicon
    /// only; the guest still has to mount the share and register `binfmt_misc`.
    public var rosettaEnabled: Bool {
        get { rosettaEnabledStorage ?? false }
        set { rosettaEnabledStorage = newValue }
    }

    /// Attach a serial console whose output is appended to `console.log` in the
    /// VM's directory. This is the only way to observe a guest's boot progress
    /// from the host when the guest never reaches a graphical session — which
    /// is exactly the situation for an unattended Linux first boot.
    public var serialConsoleLogging: Bool {
        get { serialConsoleLoggingStorage ?? false }
        set { serialConsoleLoggingStorage = newValue }
    }

    /// Forward Command-Tab etc. into the guest. Default on.
    public var captureSystemKeys: Bool {
        get { captureSystemKeysStorage ?? true }
        set { captureSystemKeysStorage = newValue }
    }

    /// Per-VM sidebar accent name: blue, green, orange, purple, pink, teal.
    public var accent: String {
        get { accentStorage ?? "blue" }
        set { accentStorage = newValue }
    }

    public init(
        id: UUID = UUID(),
        name: String,
        guest: GuestKind,
        bootMethod: BootMethod,
        cpu: CPUConfig,
        memory: MemoryConfig,
        disks: [DiskConfig],
        network: NetworkConfig = NetworkConfig(),
        shares: [ShareConfig] = [],
        display: DisplayConfig = DisplayConfig(),
        security: SecurityConfig = .default,
        rosettaEnabled: Bool = false,
        serialConsoleLogging: Bool = false,
        captureSystemKeys: Bool = true,
        accent: String = "blue"
    ) {
        self.id = id
        self.name = name
        self.guest = guest
        self.bootMethod = bootMethod
        self.cpu = cpu
        self.memory = memory
        self.disks = disks
        self.network = network
        self.shares = shares
        self.display = display
        self.security = security
        self.rosettaEnabledStorage = rosettaEnabled
        self.serialConsoleLoggingStorage = serialConsoleLogging
        self.captureSystemKeysStorage = captureSystemKeys
        self.accentStorage = accent
    }

    /// The boot volume, if one is marked.
    public var bootDisk: DiskConfig? {
        disks.first(where: \.isBootVolume)
    }

    /// Installer media attached to the VM, if any.
    public var installMedia: [DiskConfig] {
        disks.filter(\.isInstallMedia)
    }

    /// A sensible starting point for a new VM, already clamped to host limits.
    public static func recommended(
        named name: String,
        guest: GuestKind,
        capabilities: HostCapabilities
    ) -> VMConfig {
        let bootMethod: BootMethod = guest == .macOS ? .macRestore : .efi
        let memory: MemoryConfig = guest == .macOS
            ? MemoryConfig(gibibytes: 8)
            : MemoryConfig(gibibytes: 4)

        // Only macOS guests can have an accelerated display, so don't ask for
        // one on a Linux or Windows VM and then warn the user about it.
        var display = DisplayConfig()
        display.gpuAcceleration = guest.hasGPUAccelerationSupport

        let config = VMConfig(
            name: name,
            guest: guest,
            bootMethod: bootMethod,
            // Two vCPUs is the smallest count that still feels like a computer
            // while leaving the host responsive on every supported Mac.
            cpu: CPUConfig(count: min(2, capabilities.maximumCPUCount), placement: .balanced),
            memory: memory,
            disks: [
                DiskConfig(
                    path: "Disks/\(name).raw",
                    sizeBytes: UInt64(guest == .macOS ? 64 : 32) * 1_073_741_824,
                    format: .raw,
                    isBootVolume: true
                )
            ],
            display: display,
            // Generic-platform guests log to a serial console; it is the only
            // way to see what an unattended first boot is doing. macOS guests
            // have no equivalent the host can read.
            serialConsoleLogging: guest != .macOS
        )
        return config.normalized(for: capabilities)
    }
}
