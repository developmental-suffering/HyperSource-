import Foundation

/// A single problem found in a `VMConfig`.
public struct VMConfigIssue: Equatable, Sendable {
    public enum Severity: String, Sendable {
        /// The VM cannot be created as configured.
        case error
        /// The VM will run, but not the way the user probably expects.
        case warning
    }

    public let severity: Severity
    /// Dotted path to the offending field, e.g. `cpu.count`.
    public let field: String
    public let message: String

    public init(severity: Severity, field: String, message: String) {
        self.severity = severity
        self.field = field
        self.message = message
    }
}

extension VMConfig {
    /// All problems with this configuration, most severe first.
    public func validate(against capabilities: HostCapabilities) -> [VMConfigIssue] {
        var issues: [VMConfigIssue] = []

        if name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            issues.append(.init(severity: .error, field: "name", message: "The VM needs a name."))
        }

        // --- CPU count ------------------------------------------------------
        if cpu.count < capabilities.minimumCPUCount || cpu.count < 1 {
            issues.append(.init(
                severity: .error,
                field: "cpu.count",
                message: "A VM needs at least \(max(1, capabilities.minimumCPUCount)) vCPU."
            ))
        } else if cpu.count > capabilities.maximumCPUCount {
            issues.append(.init(
                severity: .error,
                field: "cpu.count",
                message: """
                \(cpu.count) vCPUs exceeds the host limit of \(capabilities.maximumCPUCount). \
                Handing the efficiency cores to a guest is allowed only by \
                raising the limit explicitly.
                """
            ))
        }

        if cpu.placement == .efficiencyPreferred && cpu.count > capabilities.efficiencyCores {
            issues.append(.init(
                severity: .warning,
                field: "cpu.placement",
                message: """
                This Mac has \(capabilities.efficiencyCores) efficiency cores, so a \
                \(cpu.count)-vCPU VM cannot be placed on efficiency cores alone.
                """
            ))
        }

        if cpu.placement != .balanced {
            issues.append(.init(
                severity: .warning,
                field: "cpu.placement",
                message: """
                Apple Silicon has no CPU pinning. This is a scheduling hint \
                (thread QoS), not a reservation: macOS may still migrate the \
                vCPU threads.
                """
            ))
        }

        // --- Memory ---------------------------------------------------------
        if memory.bytes < capabilities.minimumMemoryBytes {
            issues.append(.init(
                severity: .error,
                field: "memory.bytes",
                message: """
                \(formatGiB(memory.bytes)) GiB is below the minimum of \
                \(formatGiB(capabilities.minimumMemoryBytes)) GiB.
                """
            ))
        } else if memory.bytes > capabilities.maximumMemoryBytes {
            issues.append(.init(
                severity: .error,
                field: "memory.bytes",
                message: """
                \(formatGiB(memory.bytes)) GiB exceeds the host limit of \
                \(formatGiB(capabilities.maximumMemoryBytes)) GiB. \
                \(formatGiB(HostCapabilities.hostReserveBytes)) GiB is reserved for the host.
                """
            ))
        }

        // --- Boot method vs guest ------------------------------------------
        switch (guest, bootMethod) {
        case (.macOS, .macRestore):
            break
        case (.macOS, _):
            issues.append(.init(
                severity: .error,
                field: "bootMethod",
                message: "macOS guests must boot from an Apple restore image."
            ))
        case (_, .macRestore):
            issues.append(.init(
                severity: .error,
                field: "bootMethod",
                message: "Only macOS guests can use a restore image."
            ))
        case (_, .kernel):
            // Modelled because the framework exposes VZLinuxBootLoader, but
            // nothing here builds one: it needs a kernel, an initrd and a
            // command line we do not fetch or manage yet.
            issues.append(.init(
                severity: .error,
                field: "bootMethod",
                message: """
                Direct kernel boot is not implemented yet. Generic guests boot \
                through EFI firmware.
                """
            ))
        default:
            break
        }

        // --- Guest-specific switches ----------------------------------------
        if rosettaEnabled && guest != .linux {
            issues.append(.init(
                severity: .error,
                field: "rosettaEnabled",
                message: "Run x86-64 binaries with Rosetta is a Linux guest feature only."
            ))
        }

        if security.efiSecureBoot {
            if guest == .macOS {
                issues.append(.init(
                    severity: .error,
                    field: "security.efiSecureBoot",
                    message: """
                    A macOS guest authenticates its own boot chain through the Mac \
                    platform; EFI Secure Boot does not apply to it.
                    """
                ))
            }
            if bootMethod != .efi {
                issues.append(.init(
                    severity: .error,
                    field: "security.efiSecureBoot",
                    message: "Secure Boot needs EFI firmware."
                ))
            }
        }

        // --- Disks ----------------------------------------------------------
        if disks.isEmpty {
            issues.append(.init(
                severity: .error,
                field: "disks",
                message: "The VM has no storage attached."
            ))
        } else if !disks.contains(where: \.isBootVolume) {
            issues.append(.init(
                severity: .error,
                field: "disks",
                message: "No disk is marked as the boot volume."
            ))
        }

        // Security: disk paths come verbatim from vm.json and reach
        // VZDiskImageStorageDeviceAttachment + truncate(). Reject relative
        // paths and traversal here so a crafted config cannot point the
        // guest at /etc/passwd or ~/.ssh.
        var seenCanonicalDisks = Set<String>()
        for disk in disks {
            if disk.path.isEmpty {
                issues.append(.init(severity: .error, field: "disks.path", message: "A disk has an empty path."))
                continue
            }
            if !disk.path.hasPrefix("/") {
                issues.append(.init(severity: .error, field: "disks.path", message: "\(disk.path) must be an absolute path."))
            }
            if disk.path.contains("..") || disk.path.contains("~") {
                issues.append(.init(severity: .error, field: "disks.path", message: "\(disk.path) must not contain .. or ~."))
            }
            let canonical = (disk.path as NSString).standardizingPath.lowercased()
            if !seenCanonicalDisks.insert(canonical).inserted {
                issues.append(.init(severity: .error, field: "disks.path", message: "\(disk.path) is attached more than once."))
            }
            // Boot volume must live inside the VM directory; installer media
            // (user ISO) may live anywhere but must still be absolute.
            if disk.isBootVolume && !disk.isInstallMedia {
                let vmDir = "/Documents/HyperMachine/VMs/\(name)/"
                if !disk.path.contains(vmDir) && !disk.path.contains("/VMs/") {
                    issues.append(.init(severity: .warning, field: "disks.path", message: "Boot volume \(disk.path) is outside the VM directory."))
                }
            }
        }

        if let boot = disks.first(where: \.isBootVolume), boot.sizeBytes < 10 * 1_073_741_824 {
            issues.append(.init(
                severity: .warning,
                field: "disks",
                message: """
                A \(formatGiB(boot.sizeBytes)) GiB boot volume is very small for \
                \(guest == .macOS ? "macOS" : guest.rawValue).
                """
            ))
        }

        if disks.filter(\.isBootVolume).count > 1 {
            issues.append(.init(
                severity: .error,
                field: "disks",
                message: "More than one disk is marked as the boot volume."
            ))
        }

        if disks.filter(\.isInstallMedia).count > 1 {
            issues.append(.init(
                severity: .error,
                field: "disks",
                message: "Only one installer image can be attached at a time."
            ))
        }

        if let media = disks.first(where: \.isInstallMedia), !media.readOnly {
            issues.append(.init(
                severity: .warning,
                field: "disks",
                message: """
                Installer images are attached read-only in practice; \
                \(URL(fileURLWithPath: media.path).lastPathComponent) will be \
                protected regardless.
                """
            ))
        }

        for disk in disks where disk.format != .raw {
            issues.append(.init(
                severity: .warning,
                field: "disks.format",
                message: """
                \(disk.format.rawValue) disks are not implemented yet: \
                \(URL(fileURLWithPath: disk.path).lastPathComponent) will be \
                created as a plain raw file.
                """
            ))
        }

        // --- Networking -----------------------------------------------------
        // Isolation is the absence of a device, so there is nothing to misconfigure
        // and nothing to warn about here. What it does *not* stop is the guest
        // reaching your files through a shared folder, which the share checks
        // below say plainly.
        if network.mode == .bridged {
            if !security.allowBridgedNetworking {
                issues.append(.init(
                    severity: .error,
                    field: "network.mode",
                    message: """
                    Bridged networking puts the guest directly on your LAN and needs \
                    the restricted com.apple.vm.networking entitlement. \
                    Enable bridged networking in Security settings first.
                    """
                ))
            }
            if (network.bridgedInterface ?? "").isEmpty {
                issues.append(.init(
                    severity: .error,
                    field: "network.bridgedInterface",
                    message: "Bridged networking needs a host interface."
                ))
            }
        }

        // --- Shares ---------------------------------------------------------
        var seenTags = Set<String>()
        var seenPaths = Set<String>()
        let sensitiveRoots = ["/etc", "/var/db", "/private/etc", "/System", "/bin", "/sbin", "/usr/bin"]
        for share in shares {
            if !share.isValidMountTag {
                issues.append(.init(
                    severity: .error,
                    field: "shares.name",
                    message: """
                    "\(share.name)" is not a valid virtio-fs mount tag: use 1-64 \
                    letters, digits, dashes, underscores or dots (no spaces, slashes or shell characters).
                    """
                ))
            }
            if !seenTags.insert(share.name).inserted {
                issues.append(.init(
                    severity: .error,
                    field: "shares.name",
                    message: """
                    Two shared folders both use the tag "\(share.name)".
                    """
                ))
            }
            if !seenPaths.insert(share.hostPath).inserted {
                issues.append(.init(
                    severity: .error,
                    field: "shares.hostPath",
                    message: "\(share.hostPath) is shared more than once."
                ))
            }
            // Canonical duplicate detection: /tmp/a vs /tmp/a/ are the same.
            let canonicalShare = (share.hostPath as NSString).standardizingPath.lowercased()
            if seenPaths.contains(canonicalShare + "/") || seenPaths.contains(String(canonicalShare.dropLast())) {
                issues.append(.init(
                    severity: .error,
                    field: "shares.hostPath",
                    message: "\(share.hostPath) duplicates another share after normalization."
                ))
            }
            if !share.hasSafeHostPath {
                issues.append(.init(
                    severity: .error,
                    field: "shares.hostPath",
                    message: "\(share.hostPath) must be an absolute path without .. or ~."
                ))
            }
            for root in sensitiveRoots where share.hostPath == root || share.hostPath.hasPrefix(root + "/") {
                issues.append(.init(
                    severity: .error,
                    field: "shares.hostPath",
                    message: "Sharing \(share.hostPath) would expose host system files to the guest."
                ))
            }
            if share.hostPath == "/" || share.hostPath == NSHomeDirectory() {
                issues.append(.init(
                    severity: .error,
                    field: "shares.hostPath",
                    message: "Sharing \(share.hostPath) would expose the whole host to the guest."
                ))
            }
            if !share.readOnly {
                let isolationNote = network.mode.isAirGapped
                    ? " The guest is air-gapped, but a shared folder is still a two-way door into this Mac."
                    : ""
                issues.append(.init(
                    severity: .warning,
                    field: "shares.readOnly",
                    message: """
                    "\(share.name)" is writable, so the guest can modify files in \
                    \(share.hostPath) on your Mac.\(isolationNote)
                    """
                ))
            }
        }

        // --- Lockdown -------------------------------------------------------
        // Report what the posture will override, so a configuration that
        // contradicts it is visible before the VM is built rather than after.
        for enforcement in SecurityPolicy.enforcements(for: self) {
            issues.append(.init(
                severity: .warning,
                field: "security.lockdown",
                message: enforcement.message
            ))
        }

        if security.lockdown && security.allowBridgedNetworking {
            // Covered by the enforcements above; listed separately because this
            // combination is what a user reaches for when they are trying to
            // defeat lockdown without turning it off.
            issues.append(.init(
                severity: .warning,
                field: "network.mode",
                message: """
                Lockdown overrides bridged networking. Turn lockdown off first if \
                putting this guest on your LAN is what you actually want.
                """
            ))
        }

        // --- Display --------------------------------------------------------
        if display.widthPixels < DisplayConfig.minimumWidthPixels
            || display.heightPixels < DisplayConfig.minimumHeightPixels {
            issues.append(.init(
                severity: .error,
                field: "display",
                message: """
                Display must be at least \
                \(DisplayConfig.minimumWidthPixels)x\(DisplayConfig.minimumHeightPixels).
                """
            ))
        }

        if display.gpuAcceleration && !guest.hasGPUAccelerationSupport {
            issues.append(.init(
                severity: .warning,
                field: "display.gpuAcceleration",
                message: """
                \(guest.rawValue) guests cannot use a GPU-accelerated display through \
                Apple's frameworks; they get a 2D virtio-gpu surface and software \
                rendering instead. For 3D Linux use UTM/QEMU with Venus (Vulkan→MoltenVK) \
                outside HyperMachine — not available via Virtualization.framework.
                """
            ))
        }

        if display.pixelsPerInch < 72 || display.pixelsPerInch > 600 {
            issues.append(.init(
                severity: .error,
                field: "display.pixelsPerInch",
                message: "Display density must be 72–600 PPI."
            ))
        }

        let allowedAccents = ["blue", "green", "orange", "purple", "pink", "teal", "red"]
        if !allowedAccents.contains(accent) {
            issues.append(.init(
                severity: .error,
                field: "accent",
                message: "Accent must be one of \(allowedAccents.joined(separator: ", "))."
            ))
        }

        // Errors before warnings, then by field for a stable order.
        return issues.sorted { lhs, rhs in
            if lhs.severity != rhs.severity {
                return lhs.severity == .error
            }
            return lhs.field < rhs.field
        }
    }

    public func errors(against capabilities: HostCapabilities) -> [VMConfigIssue] {
        validate(against: capabilities).filter { $0.severity == .error }
    }

    /// Whether the VM can actually be created as configured.
    public func isRunnable(against capabilities: HostCapabilities) -> Bool {
        errors(against: capabilities).isEmpty
    }

    /// Pull every out-of-range value back to something the host will accept.
    ///
    /// The UI should call this on load and before saving, so a config edited on
    /// a bigger Mac still opens on a smaller one instead of failing validation.
    public func normalized(for capabilities: HostCapabilities) -> VMConfig {
        var copy = self
        copy.cpu.count = min(max(copy.cpu.count, max(1, capabilities.minimumCPUCount)), capabilities.maximumCPUCount)
        copy.memory.bytes = min(max(copy.memory.bytes, capabilities.minimumMemoryBytes), capabilities.maximumMemoryBytes)
        copy.display.widthPixels = max(copy.display.widthPixels, DisplayConfig.minimumWidthPixels)
        copy.display.heightPixels = max(copy.display.heightPixels, DisplayConfig.minimumHeightPixels)
        copy.display.pixelsPerInch = max(copy.display.pixelsPerInch, 1)

        // Exactly one boot volume, and installer media is never it.
        if !copy.disks.isEmpty {
            var bootAssigned = false
            for index in copy.disks.indices {
                if copy.disks[index].isInstallMedia {
                    copy.disks[index].isBootVolume = false
                    copy.disks[index].readOnly = true
                    continue
                }
                if copy.disks[index].isBootVolume {
                    if bootAssigned { copy.disks[index].isBootVolume = false }
                    bootAssigned = true
                }
            }
            if !bootAssigned, let first = copy.disks.firstIndex(where: { !$0.isInstallMedia }) {
                copy.disks[first].isBootVolume = true
            }
        }
        return copy
    }
}

private func formatGiB(_ bytes: UInt64) -> String {
    let gib = Double(bytes) / 1_073_741_824
    return String(format: gib < 10 ? "%.1f" : "%.0f", gib)
}
