import Foundation

/// The one place that decides what a configuration is allowed to expose.
///
/// Lockdown is enforced here rather than described in the UI, because a promise
/// that lives in a form is a promise that can be contradicted by the JSON. The
/// factories call `effective(_:)` immediately before building the device set, so
/// the devices a guest actually gets are the hardened ones.
public enum SecurityPolicy {
    /// One thing lockdown changes about a configuration.
    public struct Enforcement: Equatable, Sendable, Identifiable {
        public let field: String
        public let message: String

        public var id: String { field }

        public init(field: String, message: String) {
            self.field = field
            self.message = message
        }
    }

    /// What lockdown would change if this configuration were built now.
    ///
    /// Empty when lockdown is off, and empty when it is on but the
    /// configuration already complies — so a caller can use it to detect drift
    /// rather than having to compare fields itself.
    public static func enforcements(for config: VMConfig) -> [Enforcement] {
        guard config.security.lockdown else { return [] }
        var findings: [Enforcement] = []

        if config.network.mode != .isolated {
            findings.append(
                Enforcement(
                    field: "network.mode",
                    message: """
                    Lockdown leaves the guest with no network device, so \
                    \(config.network.mode.description) is replaced by isolation.
                    """
                )
            )
        }

        let writable = config.shares.filter { !$0.readOnly }
        if !writable.isEmpty {
            let names = writable.map { "'\($0.name)'" }.joined(separator: ", ")
            findings.append(
                Enforcement(
                    field: "shares.readOnly",
                    message: """
                    \(writable.count) shared folder(s) are mounted read-only: \(names). \
                    A writable share is a two-way door into your Mac.
                    """
                )
            )
        }

        if config.security.clipboardSharing {
            findings.append(Enforcement(
                field: "security.clipboardSharing",
                message: "Clipboard sharing is switched off; it moves data across the isolation boundary."
            ))
        }
        if config.security.usbPassthrough {
            findings.append(Enforcement(
                field: "security.usbPassthrough",
                message: "USB passthrough is switched off; a passed-through device is the guest driving host hardware."
            ))
        }
        if config.security.allowBridgedNetworking {
            findings.append(Enforcement(
                field: "security.allowBridgedNetworking",
                message: "Bridged networking is switched off; it would put the guest on your LAN."
            ))
        }
        if config.rosettaEnabled {
            findings.append(Enforcement(
                field: "rosettaEnabled",
                message: """
                Rosetta for Linux is switched off. It works by giving the guest a \
                directory share of host code, which is a host interface this \
                posture does not allow.
                """
            ))
        }
        return findings
    }

    /// The configuration as it will actually be built.
    public static func effective(_ config: VMConfig) -> VMConfig {
        guard config.security.lockdown else { return config }

        var hardened = config
        hardened.network = NetworkConfig(mode: .isolated, bridgedInterface: nil)
        hardened.shares = config.shares.map { share in
            var readOnly = share
            readOnly.readOnly = true
            return readOnly
        }
        hardened.rosettaEnabled = false
        hardened.security = SecurityConfig(
            clipboardSharing: false,
            usbPassthrough: false,
            allowBridgedNetworking: false,
            // Left as chosen: Secure Boot is a separate feature, and forcing it
            // on would make lockdown able to break a VM that boots unsigned.
            efiSecureBoot: config.security.efiSecureBoot,
            lockdown: true
        )
        return hardened
    }

    // MARK: - Audit

    /// One host interface a configuration exposes, and how exposed it is.
    public struct HostExposure: Equatable, Sendable, Identifiable {
        public enum Level: String, Sendable {
            /// Nothing crosses the boundary for this area.
            ///
            /// Deliberately not called `none`: comparing an optional `Level` to
            /// `.none` silently means "is nil" rather than "is sealed", and a
            /// security report that reads the opposite of what it says is the
            /// worst kind of bug.
            case sealed
            /// A data path exists, but it is one-way or read-only in practice.
            case limited
            /// The guest can change something on the host, or reach beyond it.
            case open

            public var symbol: String { rawValue }
        }

        public let area: String
        public let level: Level
        public let detail: String

        public var id: String { area }
    }

    /// Everything this configuration exposes to a guest that turned hostile.
    ///
    /// Deliberately a description of *this project's* choices. It does not and
    /// cannot cover Virtualization.framework itself: the virtio devices, the
    /// paravirtualized GPU and the XPC helper Apple runs the guest in are all
    /// shared code, and a guest that exploits one of those is outside anything
    /// configurable from here.
    public static func exposures(of config: VMConfig) -> [HostExposure] {
        var findings: [HostExposure] = []

        switch config.network.mode {
        case .isolated:
            findings.append(HostExposure(
                area: "Network",
                level: .sealed,
                detail: "No network device exists, so there is no egress path and no listening stack."
            ))
        case .nat:
            findings.append(HostExposure(
                area: "Network",
                level: .limited,
                detail: "The guest can reach the internet through the host. Inbound connections are not forwarded."
            ))
        case .bridged:
            findings.append(HostExposure(
                area: "Network",
                level: .open,
                detail: "The guest is a peer on your LAN, reachable by other machines on it."
            ))
        }

        let writable = config.shares.filter { !$0.readOnly }
        if config.shares.isEmpty {
            findings.append(HostExposure(
                area: "Shared folders",
                level: .sealed,
                detail: "No host directory is exposed to the guest."
            ))
        } else if writable.isEmpty {
            findings.append(HostExposure(
                area: "Shared folders",
                level: .limited,
                detail: "\(config.shares.count) folder(s) shared read-only: the guest can read them but not change them."
            ))
        } else {
            findings.append(HostExposure(
                area: "Shared folders",
                level: .open,
                detail: """
                \(writable.count) of \(config.shares.count) folder(s) are writable, so the guest can
                create, change and delete files on your Mac.
                """
            ))
        }

        findings.append(HostExposure(
            area: "Clipboard",
            level: config.security.clipboardSharing ? .open : .sealed,
            detail: config.security.clipboardSharing
                ? "Sharing text between host and guest in both directions."
                : "Not shared."
        ))

        findings.append(HostExposure(
            area: "USB devices",
            level: config.security.usbPassthrough ? .open : .sealed,
            detail: config.security.usbPassthrough
                ? "The guest can drive a device attached to this Mac."
                : "The guest has no access to host USB devices."
        ))

        findings.append(HostExposure(
            area: "Rosetta for Linux",
            level: config.rosettaEnabled ? .limited : .sealed,
            detail: config.rosettaEnabled
                ? "Exposes a host code directory to the guest so x86-64 binaries run; read-only, one way."
                : "Not enabled."
        ))

        findings.append(HostExposure(
            area: "Serial console",
            level: config.serialConsoleLogging ? .limited : .sealed,
            detail: config.serialConsoleLogging
                ? "Guest output is appended to a file on this Mac. The host has no input path back."
                : "Not attached."
        ))

        findings.append(HostExposure(
            area: "EFI Secure Boot",
            level: config.security.efiSecureBoot ? .sealed : .limited,
            detail: config.security.efiSecureBoot
                ? "Enabled with Apple's managed platform key: the guest refuses unsigned boot code."
                : "Not enabled, so the guest will boot unsigned EFI binaries."
        ))

        return findings
    }

    /// True when nothing in this configuration exposes a host interface **as it
    /// will be built** — lockdown included.
    ///
    /// Only the parts this project controls: see `exposures(of:)` for why that
    /// is not the same as "a hostile guest cannot escape".
    public static func isFullySealed(_ config: VMConfig) -> Bool {
        isSealedAsWritten(effective(config))
    }

    /// True when the configuration as it stands right now exposes nothing, with
    /// no policy applied.
    ///
    /// This is the one to use for drift: a locked-down configuration can still
    /// have fields that contradict the posture, and they are exactly what an
    /// audit should point at.
    public static func isSealedAsWritten(_ config: VMConfig) -> Bool {
        config.network.mode.isAirGapped
            && config.shares.allSatisfy { $0.readOnly }
            && !config.security.clipboardSharing
            && !config.security.usbPassthrough
            && !config.security.allowBridgedNetworking
            && !config.rosettaEnabled
    }
}
