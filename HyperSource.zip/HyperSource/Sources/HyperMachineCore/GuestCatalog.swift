import Foundation

/// How a guest gets onto its disk.
///
/// This is the difference between "click install and come back" and "click
/// install and finish the installer yourself", so it is explicit rather than
/// inferred from the guest type.
public enum InstallKind: String, Codable, Sendable, CaseIterable {
    /// Apple's restore image, installed by `VZMacOSInstaller`. macOS only.
    case appleRestoreImage
    /// A prebuilt raw disk image that boots straight into a configured system.
    /// Unattended: the seed we attach sets the hostname, user and network.
    case cloudImage
    /// A vendor installer ISO. The framework boots it; a human completes the
    /// installation inside the guest.
    case installerISO

    public var isUnattended: Bool {
        self != .installerISO
    }

    public var description: String {
        switch self {
        case .appleRestoreImage: return "Apple restore image (unattended install)"
        case .cloudImage: return "Prebuilt cloud image (unattended first boot)"
        case .installerISO: return "Installer ISO (you complete the install)"
        }
    }
}

/// A guest the app can install with no manual image hunting — requirement #3.
public struct GuestCatalogEntry: Codable, Equatable, Sendable, Identifiable {
    public var id: String
    public var name: String
    /// Short line for a picker, e.g. "Ubuntu 24.04 LTS".
    public var shortName: String
    public var guest: GuestKind
    public var bootMethod: BootMethod
    public var installKind: InstallKind

    /// Where the image comes from. `nil` for macOS, which is fetched through
    /// `VZMacOSRestoreImage.latestSupported`, and for entries whose image the
    /// user has to supply.
    public var imageURL: URL?
    /// Vendor checksum manifest, fetched and verified before the image is used.
    ///
    /// Deliberately not a hard-coded hash: pinning a stale digest in the source
    /// silently breaks installs the day upstream rebuilds an image.
    public var checksumManifestURL: URL?
    /// Where a human downloads the image from, when we cannot fetch it.
    public var downloadPageURL: URL?

    public var recommendedDiskGiB: Int
    public var recommendedMemoryGiB: Double
    public var needsCloudInitSeed: Bool
    /// Whether an engine for this guest exists yet. The catalog is also the
    /// roadmap, so this is what keeps the UI from offering what cannot run.
    public var isImplemented: Bool
    public var note: String

    public init(
        id: String,
        name: String,
        shortName: String,
        guest: GuestKind,
        bootMethod: BootMethod,
        installKind: InstallKind,
        imageURL: URL?,
        checksumManifestURL: URL? = nil,
        downloadPageURL: URL? = nil,
        recommendedDiskGiB: Int,
        recommendedMemoryGiB: Double,
        needsCloudInitSeed: Bool,
        isImplemented: Bool = true,
        note: String
    ) {
        self.id = id
        self.name = name
        self.shortName = shortName
        self.guest = guest
        self.bootMethod = bootMethod
        self.installKind = installKind
        self.imageURL = imageURL
        self.checksumManifestURL = checksumManifestURL
        self.downloadPageURL = downloadPageURL
        self.recommendedDiskGiB = recommendedDiskGiB
        self.recommendedMemoryGiB = recommendedMemoryGiB
        self.needsCloudInitSeed = needsCloudInitSeed
        self.isImplemented = isImplemented
        self.note = note
    }

    /// True when the app has to ask for a file on disk.
    public var requiresLocalImage: Bool {
        installKind == .installerISO
    }

    /// Turn a catalog entry into a ready-to-run configuration for this host.
    public func makeConfig(named name: String, capabilities: HostCapabilities) -> VMConfig {
        var config = VMConfig.recommended(named: name, guest: guest, capabilities: capabilities)
        config.bootMethod = bootMethod
        config.memory = MemoryConfig(gibibytes: min(
            recommendedMemoryGiB,
            Double(capabilities.maximumMemoryBytes) / 1_073_741_824
        ))
        if var boot = config.disks.first(where: \.isBootVolume) {
            boot.sizeBytes = UInt64(recommendedDiskGiB) * 1_073_741_824
            config.disks = [boot]
        }
        return config.normalized(for: capabilities)
    }
}

/// The built-in image catalog.
///
/// Cloud images are fetched from the vendor and checksum-verified; where the
/// vendor ships qcow2 rather than raw (Ubuntu on arm64), the install driver
/// flattens it. ISO entries name the vendor download page instead of pinning a
/// versioned filename that would rot within a release cycle.
public enum GuestCatalog {
    public static let all: [GuestCatalogEntry] = [
        GuestCatalogEntry(
            id: "macos-latest",
            name: "macOS (latest supported)",
            shortName: "macOS",
            guest: .macOS,
            bootMethod: .macRestore,
            installKind: .appleRestoreImage,
            imageURL: nil,
            recommendedDiskGiB: 64,
            recommendedMemoryGiB: 8,
            needsCloudInitSeed: false,
            note: """
            Fetched from Apple via VZMacOSRestoreImage.latestSupported, then installed \
            with VZMacOSInstaller. This is the only guest that gets a GPU-accelerated \
            display. Setup Assistant runs on first boot.
            """
        ),
        GuestCatalogEntry(
            id: "debian-13-cloud-arm64",
            name: "Debian 13 (arm64, unattended)",
            shortName: "Debian 13",
            guest: .linux,
            bootMethod: .efi,
            installKind: .cloudImage,
            imageURL: URL(string: "https://cloud.debian.org/images/cloud/trixie/latest/debian-13-genericcloud-arm64.raw"),
            checksumManifestURL: URL(string: "https://cloud.debian.org/images/cloud/trixie/latest/SHA512SUMS"),
            downloadPageURL: URL(string: "https://cloud.debian.org/images/cloud/trixie/latest/"),
            recommendedDiskGiB: 32,
            recommendedMemoryGiB: 4,
            needsCloudInitSeed: true,
            note: """
            A genuinely raw image, verified against Debian's SHA-512 manifest and \
            attached with a NoCloud seed that sets the hostname, a user account and \
            SSH. The first boot grows the root partition to fill the disk and then \
            touches the handshake file, which is how the app knows the guest really \
            came up. Booting takes about a minute; watch console.log for progress.
            """
        ),
        GuestCatalogEntry(
            id: "ubuntu-24.04-cloud-arm64",
            name: "Ubuntu 24.04 LTS (arm64, unattended)",
            shortName: "Ubuntu 24.04",
            guest: .linux,
            bootMethod: .efi,
            installKind: .cloudImage,
            imageURL: URL(string: "https://cloud-images.ubuntu.com/releases/noble/release/ubuntu-24.04-server-cloudimg-arm64.img"),
            checksumManifestURL: URL(string: "https://cloud-images.ubuntu.com/releases/noble/release/SHA256SUMS"),
            downloadPageURL: URL(string: "https://cloud-images.ubuntu.com/releases/noble/release/"),
            recommendedDiskGiB: 32,
            recommendedMemoryGiB: 4,
            needsCloudInitSeed: true,
            note: """
            Ubuntu publishes this one as qcow2 on arm64 (the amd64 image is raw, \
            which is why most guides say otherwise). HyperMachine flattens it to a \
            raw disk, then attaches a NoCloud seed so the first boot configures the \
            hostname, a user account and SSH — no installer to sit through.
            """
        ),
        GuestCatalogEntry(
            id: "ubuntu-24.04-minimal-arm64",
            name: "Ubuntu 24.04 LTS minimal (arm64, unattended)",
            shortName: "Ubuntu minimal",
            guest: .linux,
            bootMethod: .efi,
            installKind: .cloudImage,
            imageURL: URL(string: "https://cloud-images.ubuntu.com/minimal/releases/noble/release/ubuntu-24.04-minimal-cloudimg-arm64.img"),
            checksumManifestURL: URL(string: "https://cloud-images.ubuntu.com/minimal/releases/noble/release/SHA256SUMS"),
            downloadPageURL: URL(string: "https://cloud-images.ubuntu.com/minimal/releases/noble/release/"),
            recommendedDiskGiB: 16,
            recommendedMemoryGiB: 2,
            needsCloudInitSeed: true,
            note: """
            The same unattended flow with a much smaller download (also qcow2, also \
            flattened) — the quickest guest to try first.
            """
        ),
        GuestCatalogEntry(
            id: "ubuntu-server-iso-arm64",
            name: "Ubuntu Server installer (arm64)",
            shortName: "Ubuntu Server ISO",
            guest: .linux,
            bootMethod: .efi,
            installKind: .installerISO,
            imageURL: nil,
            downloadPageURL: URL(string: "https://cdimage.ubuntu.com/releases/24.04/release/"),
            recommendedDiskGiB: 32,
            recommendedMemoryGiB: 4,
            needsCloudInitSeed: false,
            note: """
            Download the arm64 live-server ISO from Ubuntu, then choose it here. The \
            framework boots the ISO and you complete the install in the guest — the \
            media stays attached until you remove it in Settings.
            """
        ),
        GuestCatalogEntry(
            id: "debian-13-iso-arm64",
            name: "Debian installer (arm64)",
            shortName: "Debian ISO",
            guest: .linux,
            bootMethod: .efi,
            installKind: .installerISO,
            imageURL: nil,
            downloadPageURL: URL(string: "https://cdimage.debian.org/debian-cd/current/arm64/iso-cd/"),
            recommendedDiskGiB: 32,
            recommendedMemoryGiB: 4,
            needsCloudInitSeed: false,
            note: "Pick the arm64 netinst or DVD ISO from Debian. You complete the install in the guest."
        ),
        GuestCatalogEntry(
            id: "alpine-virt-arm64",
            name: "Alpine Linux (aarch64) appliance",
            shortName: "Alpine",
            guest: .linux,
            bootMethod: .efi,
            installKind: .installerISO,
            imageURL: nil,
            downloadPageURL: URL(string: "https://dl-cdn.alpinelinux.org/alpine/latest-stable/releases/aarch64/"),
            recommendedDiskGiB: 8,
            recommendedMemoryGiB: 2,
            needsCloudInitSeed: false,
            note: """
            Take the aarch64 "virt" ISO. Alpine is tiny, which makes it the quickest \
            guest for testing engine changes.
            """
        ),
        GuestCatalogEntry(
            id: "windows-11-arm64",
            name: "Windows 11 (Arm) — bring your own ISO",
            shortName: "Windows 11",
            guest: .windows,
            bootMethod: .efi,
            installKind: .installerISO,
            imageURL: nil,
            downloadPageURL: URL(string: "https://www.microsoft.com/software-download/windows11arm64"),
            recommendedDiskGiB: 64,
            recommendedMemoryGiB: 8,
            needsCloudInitSeed: false,
            isImplemented: false,
            note: """
            No public ARM64 download URL, so the user supplies an ISO. Windows 11 \
            also requires a TPM, which this framework does not expose, so the engine \
            for it is not written. Listed so the gap is visible.
            """
        )
    ]

    public static func entry(id: String) -> GuestCatalogEntry? {
        all.first { $0.id == id }
    }

    public static func entries(for guest: GuestKind) -> [GuestCatalogEntry] {
        all.filter { $0.guest == guest }
    }

    /// Entries whose engine exists today.
    public static var installable: [GuestCatalogEntry] {
        all.filter(\.isImplemented)
    }
}
