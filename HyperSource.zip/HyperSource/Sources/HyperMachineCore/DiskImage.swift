import Foundation

/// What a file on disk actually is.
///
/// This exists because the file *extension* lies. Every guide says Ubuntu's
/// cloud image is a raw disk image; on arm64 the file named `.img` is in fact
/// qcow2, which the framework will happily attach and then fail to boot with no
/// explanation. Sniffing the bytes is the only way to know.
public enum DiskImageFormat: String, Codable, Sendable, CaseIterable {
    /// A flat disk image: the file *is* the disk. What
    /// `VZDiskImageStorageDeviceAttachment` needs.
    case raw
    /// Copy-on-write container. Needs conversion before it can be attached.
    case qcow2
    case unknown

    public var isDirectlyAttachable: Bool { self == .raw }

    public var description: String {
        switch self {
        case .raw: return "raw disk image"
        case .qcow2: return "qcow2 (not directly attachable)"
        case .unknown: return "unrecognised format"
        }
    }
}

/// The GUID Partition Table entry for an EFI system partition.
public struct EFISystemPartition: Sendable, Equatable {
    public var startOffset: UInt64
    public var sizeBytes: UInt64
    /// A FAT boot sector at the partition's first sector. Firmware needs one.
    public var hasFATBootSector: Bool

    public var gibibytes: Double { Double(sizeBytes) / 1_073_741_824 }
}

/// The result of looking at a disk image without mounting it.
public struct DiskImageProbe: Sendable, Equatable {
    public var url: URL
    public var format: DiskImageFormat
    public var fileSizeBytes: UInt64
    /// For qcow2, the size of the virtual disk the container represents.
    public var virtualSizeBytes: UInt64?
    public var hasProtectiveMBR: Bool
    public var hasGPT: Bool
    public var efiSystemPartition: EFISystemPartition?
    /// Human-readable findings, for logs and the CLI.
    public var analysis: [String]

    /// Whether the firmware could find a boot loader here.
    public var isBootable: Bool {
        format.isDirectlyAttachable
            && hasGPT
            && (efiSystemPartition?.hasFATBootSector ?? false)
    }

    /// The size a guest will see.
    public var effectiveSizeBytes: UInt64 {
        virtualSizeBytes ?? fileSizeBytes
    }
}

public enum DiskImageInspectorError: Error, CustomStringConvertible {
    case unreadable(String)

    public var description: String {
        switch self {
        case .unreadable(let detail): return "could not read the image: \(detail)"
        }
    }
}

/// Reads the bytes a disk image starts with and reports what they mean.
///
/// Deliberately no mounting, no `hdiutil`, no external tools: the questions
/// ("is this raw?", "would firmware find a boot loader?") are all answerable
/// from the first few kilobytes.
public enum DiskImageInspector {
    public static let qcow2Magic: [UInt8] = [0x51, 0x46, 0x49, 0xFB]
    static let gptSignature: [UInt8] = Array("EFI PART".utf8)
    /// `C12A7328-F81F-11D2-BA4B-00A0C93EC93B`, in the mixed-endian byte order
    /// GPT stores GUIDs in.
    static let efiSystemPartitionType: [UInt8] = [
        0x28, 0x73, 0x2A, 0xC1, 0x1F, 0xF8, 0xD2, 0x11,
        0xBA, 0x4B, 0x00, 0xA0, 0xC9, 0x3E, 0xC9, 0x3B
    ]

    /// A GUID partition table cannot live in a file smaller than this.
    static let minimumGPTImageBytes: UInt64 = 34 * 512

    public static func probe(_ url: URL) throws -> DiskImageProbe {
        let attributes = try? FileManager.default.attributesOfItem(atPath: url.path)
        let fileSize = (attributes?[.size] as? NSNumber)?.uint64Value ?? 0

        let handle: FileHandle
        do {
            handle = try FileHandle(forReadingFrom: url)
        } catch {
            throw DiskImageInspectorError.unreadable(error.localizedDescription)
        }
        defer { try? handle.close() }

        // 64 KiB covers the qcow2 header, the protective MBR, the GPT header and
        // a generous run of partition entries.
        let head: Data
        do {
            head = try handle.read(upToCount: 64 * 1024) ?? Data()
        } catch {
            throw DiskImageInspectorError.unreadable(error.localizedDescription)
        }

        var probe = DiskImageProbe(
            url: url,
            format: .unknown,
            fileSizeBytes: fileSize,
            virtualSizeBytes: nil,
            hasProtectiveMBR: false,
            hasGPT: false,
            efiSystemPartition: nil,
            analysis: []
        )

        if head.count >= 4, Array(head[0..<4]) == qcow2Magic {
            probe.format = .qcow2
            probe.analysis.append("qcow2 container: the file is not a flat disk image")
            if let header = QCOW2Header(data: head) {
                probe.virtualSizeBytes = header.virtualSizeBytes
                probe.analysis.append(
                    "qcow2 v\(header.version), \(header.clusterBits)-bit clusters, "
                        + "virtual disk \(header.virtualSizeBytes / 1_073_741_824) GiB"
                )
            } else {
                probe.analysis.append("qcow2 header is truncated")
            }
            return probe
        }

        probe.format = .raw
        probe.virtualSizeBytes = fileSize

        guard head.count >= 1024 else {
            probe.analysis.append("file is smaller than one sector; not a disk image")
            return probe
        }

        // Protective MBR: a single 0xEE partition is how a GPT disk stays
        // legible to tools that only understand MBR.
        let mbrSignature = leU16(head, 510)
        let firstPartitionType = head[450]
        probe.hasProtectiveMBR = mbrSignature == 0xAA55 && firstPartitionType == 0xEE
        if probe.hasProtectiveMBR {
            probe.analysis.append("protective MBR present")
        }

        guard Array(head[512..<520]) == gptSignature else {
            probe.analysis.append("no EFI PART at sector 1: this disk is unpartitioned or not GPT")
            return probe
        }
        probe.hasGPT = true

        let entryLBA = leU64(head, 512 + 72)
        var entryCount = Int(leU32(head, 512 + 80))
        var entrySize = Int(leU32(head, 512 + 84))
        // A malformed header must not send us reading gigabytes; fall back to the
        // values the specification requires when they are absent.
        if entrySize == 0 { entrySize = 128 }
        guard entrySize >= 128, entrySize <= 4096 else {
            probe.analysis.append("GPT partition entry size \(entrySize) is out of range")
            return probe
        }
        if entryCount > 4096 { entryCount = 4096 }

        let tableOffset = Int(entryLBA) * 512
        var entries = Data()
        if tableOffset >= 0, tableOffset < head.count {
            entries = head.subdata(in: tableOffset..<head.count)
        } else {
            // The table was not in the bytes we read; fetch exactly what we need.
            let tableBytes = entryCount * entrySize
            if (try? handle.seek(toOffset: UInt64(tableOffset))) != nil {
                entries = (try? handle.read(upToCount: tableBytes)) ?? Data()
            }
        }

        probe.analysis.append("GPT with \(entryCount) partition slots")

        for index in 0..<entryCount {
            let offset = index * entrySize
            guard offset + 128 <= entries.count else { break }
            let typeGUID = entries.subdata(in: offset..<(offset + 16))
            // An all-zero type means an unused slot.
            guard typeGUID.contains(where: { $0 != 0 }) else { continue }
            guard Array(typeGUID) == efiSystemPartitionType else { continue }

            let start = leU64(entries, offset + 32)
            let end = leU64(entries, offset + 40)
            let size = end >= start ? (end - start + 1) * 512 : 0
            var partition = EFISystemPartition(
                startOffset: start * 512,
                sizeBytes: size,
                hasFATBootSector: false
            )
            partition.hasFATBootSector = hasFATBootSector(handle: handle, at: start * 512)
            probe.efiSystemPartition = partition
            probe.analysis.append(
                String(
                    format: "EFI system partition %.0f MiB at offset %.0f MiB%@",
                    Double(size) / 1_048_576,
                    Double(start * 512) / 1_048_576,
                    partition.hasFATBootSector ? ", FAT boot sector present" : ", no FAT boot sector"
                )
            )
            break
        }

        if probe.efiSystemPartition == nil {
            probe.analysis.append("no EFI system partition: firmware would find no boot loader")
        }

        return probe
    }

    /// A FAT boot sector has the 0x55AA signature and a BPB the firmware
    /// understands. This is a sanity check, not a mount.
    static func hasFATBootSector(handle: FileHandle, at offset: UInt64) -> Bool {
        guard let _ = try? handle.seek(toOffset: offset),
              let sector = try? handle.read(upToCount: 512),
              sector.count >= 90
        else { return false }

        guard leU16(sector, 510) == 0xAA55 else { return false }
        let bytesPerSector = Int(leU16(sector, 11))
        guard [512, 1024, 2048, 4096].contains(bytesPerSector) else { return false }
        guard sector[13] != 0 else { return false }  // sectors per cluster

        let fsType = String(decoding: sector[82..<90], as: UTF8.self)
        let fat12Name = String(decoding: sector[54..<62], as: UTF8.self)
        return fsType.hasPrefix("FAT") || fat12Name.hasPrefix("FAT")
    }

    // MARK: - Little-endian reads

    static func leU16(_ data: Data, _ offset: Int) -> UInt16 {
        guard offset >= 0, offset + 2 <= data.count else { return 0 }
        return UInt16(data[offset]) | (UInt16(data[offset + 1]) << 8)
    }

    static func leU32(_ data: Data, _ offset: Int) -> UInt32 {
        guard offset >= 0, offset + 4 <= data.count else { return 0 }
        return UInt32(data[offset])
            | (UInt32(data[offset + 1]) << 8)
            | (UInt32(data[offset + 2]) << 16)
            | (UInt32(data[offset + 3]) << 24)
    }

    static func leU64(_ data: Data, _ offset: Int) -> UInt64 {
        guard offset >= 0, offset + 8 <= data.count else { return 0 }
        var value: UInt64 = 0
        // Assembled byte by byte: `withUnsafeBytes` on a slice would need the
        // slice's own indices, which is a trap worth avoiding.
        for index in (0..<8).reversed() {
            value = (value << 8) | UInt64(data[offset + index])
        }
        return value
    }

    // MARK: - Big-endian reads

    // qcow2 stores its header big-endian, the opposite of GPT. Mixing the two up
    // yields a version of 50331648 and a cluster size of 268435456, so the two
    // families are kept apart deliberately.

    public static func beU32(_ data: Data, _ offset: Int) -> UInt32 {
        guard offset >= 0, offset + 4 <= data.count else { return 0 }
        return (UInt32(data[offset]) << 24)
            | (UInt32(data[offset + 1]) << 16)
            | (UInt32(data[offset + 2]) << 8)
            | UInt32(data[offset + 3])
    }

    public static func beU64(_ data: Data, _ offset: Int) -> UInt64 {
        guard offset >= 0, offset + 8 <= data.count else { return 0 }
        var value: UInt64 = 0
        for index in 0..<8 {
            value = (value << 8) | UInt64(data[offset + index])
        }
        return value
    }
}

/// The parts of a qcow2 header worth knowing: enough to report the real disk
/// size, and to walk the cluster tables if the image has to be converted.
public struct QCOW2Header: Sendable, Equatable {
    public let version: UInt32
    public let clusterBits: Int
    public let virtualSizeBytes: UInt64
    public let l1TableOffset: UInt64
    public let l1TableEntries: UInt32
    public let backingFileOffset: UInt64
    /// Bits that mean "you must understand this to read the image".
    public let incompatibleFeatures: UInt64
    public let cryptMethod: UInt32

    public var clusterSize: UInt64 { 1 << clusterBits }
    /// Bytes a single L2 table covers.
    public var l2Coverage: UInt64 { clusterSize * 8 }

    /// Incompatible feature bits, from the specification.
    public enum IncompatibleFeature: UInt64, Sendable {
        case dirtyBit = 1
        case corruptBit = 2
        case externalDataFile = 4
        /// Compressed clusters use zstd rather than zlib.
        case zstdCompression = 8
        /// L2 entries are 16 bytes and describe sub-clusters.
        case extendedL2Entries = 16
    }

    /// Whether the file describes a disk with no parent image. A cloud image
    /// with a backing file cannot be flattened without that file.
    public var hasBackingFile: Bool { backingFileOffset != 0 }

    public var isEncrypted: Bool { cryptMethod != 0 }

    public func has(_ feature: IncompatibleFeature) -> Bool {
        incompatibleFeatures & feature.rawValue != 0
    }

    public init?(data: Data) {
        guard data.count >= 104, Array(data[0..<4]) == DiskImageInspector.qcow2Magic else {
            return nil
        }
        let version = DiskImageInspector.beU32(data, 4)
        let backingOffset = DiskImageInspector.beU64(data, 8)
        let clusterBits = Int(DiskImageInspector.beU32(data, 20))
        let virtualSize = DiskImageInspector.beU64(data, 24)
        let cryptMethod = DiskImageInspector.beU32(data, 32)
        let l1Size = DiskImageInspector.beU32(data, 36)
        let l1Offset = DiskImageInspector.beU64(data, 40)
        let incompatible = DiskImageInspector.beU64(data, 72)

        // Values outside these ranges would index nonsense later.
        guard (9...21).contains(clusterBits), version >= 1, virtualSize > 0 else { return nil }

        self.version = version
        self.clusterBits = clusterBits
        self.virtualSizeBytes = virtualSize
        self.l1TableOffset = l1Offset
        self.l1TableEntries = l1Size
        self.backingFileOffset = backingOffset
        self.incompatibleFeatures = incompatible
        self.cryptMethod = cryptMethod
    }
}
