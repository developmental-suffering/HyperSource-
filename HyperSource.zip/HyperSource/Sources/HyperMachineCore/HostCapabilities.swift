import Foundation

/// The host's virtualization budget.
///
/// Deliberately not derived from Virtualization.framework: this type keeps the
/// core module free of restricted-entitlement dependencies, and the framework
/// ranges are injected later by the engine that owns them
/// (`VZVirtualMachineConfiguration.maximumAllowedCPUCount` and friends).
public struct HostCapabilities: Codable, Equatable, Sendable {
    /// Physical performance ("P") cores.
    public var performanceCores: Int
    /// Physical efficiency ("E") cores.
    public var efficiencyCores: Int
    /// Total installed RAM on the host.
    public var physicalMemoryBytes: UInt64

    /// Legal vCPU range. The framework refines this at runtime.
    public var minimumCPUCount: Int
    public var maximumCPUCount: Int
    /// Legal guest RAM range. The framework refines this at runtime.
    public var minimumMemoryBytes: UInt64
    public var maximumMemoryBytes: UInt64

    /// True when the host can expose guest EL2 (nested virtualization).
    /// Reported to require M3 or newer.
    public var supportsNestedVirtualization: Bool

    public init(
        performanceCores: Int,
        efficiencyCores: Int,
        physicalMemoryBytes: UInt64,
        minimumCPUCount: Int = 1,
        maximumCPUCount: Int? = nil,
        minimumMemoryBytes: UInt64 = 1 * 1_073_741_824,
        maximumMemoryBytes: UInt64,
        supportsNestedVirtualization: Bool
    ) {
        self.performanceCores = performanceCores
        self.efficiencyCores = efficiencyCores
        self.physicalMemoryBytes = physicalMemoryBytes
        self.minimumCPUCount = minimumCPUCount
        // Default policy: never hand the efficiency cores to a guest by
        // default, so the host keeps them. The user can still raise this by
        // supplying an explicit maximum from the framework.
        self.maximumCPUCount = maximumCPUCount ?? performanceCores
        self.minimumMemoryBytes = minimumMemoryBytes
        self.maximumMemoryBytes = maximumMemoryBytes
        self.supportsNestedVirtualization = supportsNestedVirtualization
    }

    public var totalCoreCount: Int {
        performanceCores + efficiencyCores
    }
}

#if canImport(Darwin)
import Darwin

extension HostCapabilities {
    /// Bytes the host itself should keep. Guests are not allowed to consume the
    /// whole machine: violating this is how you get a beachballed Mac.
    public static let hostReserveBytes: UInt64 = 4 * 1_073_741_824

    /// Marketing name of the host SoC, e.g. "Apple M1 Pro". `nil` if the host
    /// does not report one.
    public static var machineBrand: String? {
        sysctlString("machdep.cpu.brand_string")
    }

    /// Read the current host's topology from `sysctl`.
    ///
    /// The legal range reported here is a *placeholder*: a conservative
    /// pre-flight estimate used before any VM exists. The chosen engine must
    /// replace `maximumCPUCount`/`maximumMemoryBytes` with the values the
    /// framework actually reports.
    public static func current() -> HostCapabilities {
        let performance = HostCapabilities.sysctlInt("hw.perflevel0.physicalcpu") ?? 0
        let efficiency = HostCapabilities.sysctlInt("hw.perflevel1.physicalcpu") ?? 0
        let total = HostCapabilities.sysctlInt("hw.ncpu") ?? 1
        let memory = HostCapabilities.sysctlUInt64("hw.memsize") ?? 0
        let brand = HostCapabilities.sysctlString("machdep.cpu.brand_string") ?? ""

        // Some Macs report no perflevel keys; fall back to the flat core count
        // rather than claiming zero CPUs.
        let resolvedPerformance = performance > 0 ? performance : total
        let resolvedEfficiency = efficiency > 0 ? efficiency : 0

        let reserve = min(HostCapabilities.hostReserveBytes, memory / 4)
        let maxMemory = memory > reserve ? memory - reserve : HostCapabilities.hostReserveBytes

        let generation = HostCapabilities.chipGeneration(brand: brand)

        return HostCapabilities(
            performanceCores: resolvedPerformance,
            efficiencyCores: resolvedEfficiency,
            physicalMemoryBytes: memory,
            maximumCPUCount: max(1, resolvedPerformance),
            minimumMemoryBytes: 1 * 1_073_741_824,
            maximumMemoryBytes: maxMemory,
            supportsNestedVirtualization: (generation ?? 0) >= 3
        )
    }

    /// Extract the M-series generation from a brand string such as
    /// "Apple M1 Pro" -> 1, "Apple M3 Max" -> 3. Returns nil for non-Apple
    /// Silicon or unrecognised strings.
    public static func chipGeneration(brand: String) -> Int? {
        // The brand is "Apple M1 Pro", so the generation is fused to the M:
        // the token to look for is "M1", not "M" followed by "1".
        for token in brand.split(separator: " ") where token.first == "M" {
            if let generation = Int(token.dropFirst()) {
                return generation
            }
        }
        return nil
    }

    private static func sysctlInt(_ name: String) -> Int? {
        var value: Int32 = 0
        var size = MemoryLayout<Int32>.size
        guard sysctlbyname(name, &value, &size, nil, 0) == 0 else { return nil }
        return Int(value)
    }

    private static func sysctlUInt64(_ name: String) -> UInt64? {
        var value: UInt64 = 0
        var size = MemoryLayout<UInt64>.size
        guard sysctlbyname(name, &value, &size, nil, 0) == 0 else { return nil }
        return value
    }

    private static func sysctlString(_ name: String) -> String? {
        var size = 0
        guard sysctlbyname(name, nil, &size, nil, 0) == 0, size > 0 else { return nil }
        var buffer = [UInt8](repeating: 0, count: size)
        guard sysctlbyname(name, &buffer, &size, nil, 0) == 0 else { return nil }
        // sysctl sizes include the trailing NUL, which is not a valid UTF-8 byte.
        if let nul = buffer.firstIndex(of: 0) {
            buffer.removeSubrange(nul...)
        }
        return String(decoding: buffer, as: UTF8.self)
    }
}
#endif
