import Foundation
import Virtualization
import HyperMachineCore

/// Anything that can go wrong while turning a `StoredVM` into a framework
/// configuration.
///
/// The two factories throw their own error types with better-targeted messages;
/// this is the single shape callers have to handle, so neither the CLI nor the
/// app needs to know which engine produced the failure.
public enum VMBuildError: Error, CustomStringConvertible {
    /// A macOS VM whose stored hardware model is missing: it cannot be rebuilt.
    case missingHardwareModel(String)
    case failed(String)

    public var description: String {
        switch self {
        case .missingHardwareModel(let name):
            return """
            \(name) has no stored hardware model. A macOS guest's hardware model is \
            fixed when the VM is created and cannot be recovered, so this VM has to \
            be created again.
            """
        case .failed(let message):
            return message
        }
    }
}

/// Device construction shared by both engines.
enum DeviceBuilders {
    /// The network device for a configuration, or `nil` for an air-gapped guest.
    ///
    /// Returning `nil` rather than an unattached device is the whole point of
    /// `NetworkMode.isolated`: a device with no attachment is a device that can
    /// be attached later, an empty virtio-net queue that still exists in the
    /// guest, and a driver still parsing host-supplied descriptors. No device
    /// means no interface in the guest, no MAC address, and one less piece of
    /// shared code parsing guest input.
    static func network(from config: NetworkConfig) throws -> VZVirtioNetworkDeviceConfiguration? {
        switch config.mode {
        case .isolated:
            return nil
        case .nat:
            let device = VZVirtioNetworkDeviceConfiguration()
            device.attachment = VZNATNetworkDeviceAttachment()
            return device
        case .bridged:
            guard let name = config.bridgedInterface,
                  let interface = VZBridgedNetworkInterface.networkInterfaces
                      .first(where: { $0.identifier == name }) else {
                throw VMBuildError.failed(
                    "no host interface named \(config.bridgedInterface ?? "<nil>")"
                )
            }
            let device = VZVirtioNetworkDeviceConfiguration()
            // Requires com.apple.vm.networking, a separately restricted
            // entitlement; validate() fails without it.
            device.attachment = VZBridgedNetworkDeviceAttachment(interface: interface)
            return device
        }
    }

    /// The network device list for a configuration, empty when isolated.
    static func networkDevices(from config: NetworkConfig) throws -> [VZVirtioNetworkDeviceConfiguration] {
        guard let device = try network(from: config) else { return [] }
        return [device]
    }

    /// Append the guest's serial output to a log file in the VM's directory.
    ///
    /// Returns `nil` when the file cannot be opened. That is deliberately not
    /// fatal: losing a diagnostic log should not stop a VM from starting.
    /// The log is capped at 10 MiB with rotation so a chatty guest cannot
    /// fill the host disk.
    static let maxConsoleLogBytes: UInt64 = 10 * 1_024 * 1_024
    static func serialConsoleLogAttachment(at url: URL) -> VZFileHandleSerialPortAttachment? {
        let manager = FileManager.default
        if (try? manager.destinationOfSymbolicLink(atPath: url.path)) != nil { return nil }
        if !manager.fileExists(atPath: url.path) {
            manager.createFile(atPath: url.path, contents: nil)
            try? manager.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
        } else if let size = (try? manager.attributesOfItem(atPath: url.path)[.size] as? NSNumber)?.uint64Value,
                  size > maxConsoleLogBytes {
            // Simplest safe rotation: truncate and start fresh.
            try? manager.removeItem(at: url)
            manager.createFile(atPath: url.path, contents: nil)
            try? manager.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
        }
        guard let handle = try? FileHandle(forWritingTo: url) else { return nil }
        _ = try? handle.seekToEnd()
        // The attachment retains the handle, which keeps the descriptor open for
        // the machine's lifetime. Reading is nil: the host has no console input
        // path, only a log.
        return VZFileHandleSerialPortAttachment(
            fileHandleForReading: nil,
            fileHandleForWriting: handle
        )
    }

    /// Canonicalize a host path and refuse symlinks/traversal.
    /// Returns nil when the path is unsafe to attach.
    static func safeHostDirectory(_ path: String) -> URL? {
        guard path.hasPrefix("/"), !path.contains(".."), !path.contains("~") else { return nil }
        let url = URL(fileURLWithPath: path)
        if (try? FileManager.default.destinationOfSymbolicLink(atPath: url.path)) != nil { return nil }
        var isDir: ObjCBool = false
        guard FileManager.default.fileExists(atPath: url.path, isDirectory: &isDir), isDir.boolValue else { return nil }
        return url
    }

    /// Refuse disk paths that are symlinks or contain traversal.
    static func safeDiskURL(_ path: String) -> URL? {
        guard path.hasPrefix("/"), !path.contains(".."), !path.contains("~"), !path.isEmpty else { return nil }
        let url = URL(fileURLWithPath: path)
        // Boot disks must exist; installer ISOs must exist. A missing path is
        // a caller error, not a silent attach.
        if (try? FileManager.default.destinationOfSymbolicLink(atPath: url.path)) != nil { return nil }
        return url
    }
}

/// Builds the framework configuration for any VM in the store.
///
/// This is the one place that decides which engine a VM uses, so a saved VM is
/// always reopened the same way it was created.
public enum VMFactory {
    public static func makeConfiguration(
        from stored: StoredVM,
        storage: VMLayout
    ) throws -> VZVirtualMachineConfiguration {
        switch stored.config.guest {
        case .macOS:
            guard let data = stored.hardwareModelData else {
                throw VMBuildError.missingHardwareModel(stored.config.name)
            }
            do {
                let identifier = try MacOSVMFactory.loadOrCreateMachineIdentifier(
                    at: storage.machineIdentifier
                )
                return try MacOSVMFactory.makeConfiguration(
                    from: stored.config,
                    hardwareModelData: data,
                    machineIdentifier: identifier,
                    storage: storage
                )
            } catch let error as MacOSVMBuildError {
                throw VMBuildError.failed(error.description)
            }

        case .linux, .windows:
            do {
                let identifier = try LinuxVMFactory.loadOrCreateMachineIdentifier(
                    at: storage.genericMachineIdentifier
                )
                return try LinuxVMFactory.makeConfiguration(
                    from: stored.config,
                    machineIdentifier: identifier,
                    storage: storage
                )
            } catch let error as LinuxVMBuildError {
                throw VMBuildError.failed(error.description)
            }
        }
    }
}
