import Compression
import Foundation
import HyperMachineCore

/// Flattens a qcow2 container into a raw disk image.
///
/// This exists for a concrete reason. Virtualization.framework attaches raw
/// images only, and the images people actually want are frequently not raw:
/// Ubuntu publishes qcow2 for arm64 (but raw for amd64, which is why every guide
/// says "the .img is raw"). Rather than fail with "unsupported", we convert.
///
/// The reader implements only what a disk image needs — compressed clusters,
/// uncompressed clusters and unallocated (zero) regions — and refuses anything
/// else loudly instead of producing a disk that looks fine and boots into
/// nothing.
///
/// ## How the descriptors actually read
///
/// The interesting part, and the part that cost the most to get right, is that
/// a real image's cluster descriptors are not read the way the format
/// description suggests. Decoding a genuine Ubuntu arm64 cloud image showed:
///
/// - the host offset is the low 48 bits of the descriptor, not bits 9–55;
/// - bit 62 marks a compressed cluster;
/// - a compressed payload is a bare DEFLATE stream, with no zlib wrapper;
/// - consecutive compressed payloads are packed back to back, so a payload's
///   length is the distance to the next one.
///
/// That model was verified by inflating all 9,639 compressed streams of that
/// image: every one produced exactly one 64 KiB cluster, and cluster 0 rebuilt a
/// byte-exact protective MBR and GPT header. `DiskImageInspector` re-checks the
/// finished disk, so a wrong decode fails the install instead of corrupting it.
public enum QCOW2Converter {
    public struct Progress: Sendable {
        public let writtenBytes: Int64
        public let totalBytes: Int64

        public var fraction: Double {
            totalBytes > 0 ? min(1, Double(writtenBytes) / Double(totalBytes)) : 0
        }

        public var description: String {
            let writtenGiB = Double(writtenBytes) / 1_073_741_824
            let totalGiB = Double(totalBytes) / 1_073_741_824
            return String(format: "%.2f / %.2f GiB (%.0f%%)", writtenGiB, totalGiB, fraction * 100)
        }
    }

    public struct Summary: Sendable {
        public let compressedClusters: Int
        public let plainClusters: Int
        public let bytesWritten: Int64
    }

    public enum ConversionError: Error, CustomStringConvertible {
        case notQCOW2
        case truncated(String)
        case unsupported(String)
        case decompressionFailed(cluster: UInt64)

        public var description: String {
            switch self {
            case .notQCOW2:
                return "the file is not a qcow2 image, so it cannot be converted."
            case .truncated(let detail):
                return "the qcow2 image is truncated or corrupt: \(detail)"
            case .unsupported(let detail):
                return """
                this qcow2 image uses a feature the converter does not implement \
                (\(detail)). Use a raw image instead.
                """
            case .decompressionFailed(let cluster):
                return """
                the compressed data for disk cluster \(cluster) would not decompress. \
                The image is corrupt; it has been discarded.
                """
            }
        }
    }

    /// Marks a compressed cluster.
    static let compressedBit: UInt64 = 1 << 62
    /// The host offset lives here. See the note above: not the format's
    /// documented bits 9–55.
    static let offsetMask: UInt64 = 0x0000_FFFF_FFFF_FFFF
    /// A compressed payload cannot exceed this many sectors by definition.
    static let maximumCompressedBytes = 512 * 512

    /// Convert `source` into a flat image at `destination`.
    ///
    /// Unallocated regions are skipped rather than written, so a 3.5 GiB image
    /// whose guest data compresses into 600 MiB does not cost 3.5 GiB on the
    /// host.
    @discardableResult
    public static func convert(
        from source: URL,
        to destination: URL,
        progress: (@Sendable (Progress) -> Void)? = nil
    ) throws -> Summary {
        let reader: FileHandle
        do {
            reader = try FileHandle(forReadingFrom: source)
        } catch {
            throw ConversionError.truncated(error.localizedDescription)
        }
        defer { try? reader.close() }

        let headerBytes = try readExactly(reader, at: 0, count: 104)
        guard let header = QCOW2Header(data: headerBytes) else {
            throw ConversionError.notQCOW2
        }
        try checkSupported(header)
        // Resource caps: a crafted header must not cause exabyte truncates
        // or multi-GB L1 allocations.
        guard header.virtualSizeBytes > 0, header.virtualSizeBytes <= 512 * 1_073_741_824 else {
            throw ConversionError.unsupported("virtual size \(header.virtualSizeBytes) is outside 1 B–512 GiB")
        }
        guard header.l1TableEntries > 0, header.l1TableEntries <= 32_768 else {
            throw ConversionError.unsupported("L1 table with \(header.l1TableEntries) entries is not supported")
        }

        // Pass one: find every cluster that holds data, and where its bytes are.
        let clusterCount = Int(header.clusterSize / 8)
        var compressed: [(cluster: UInt64, offset: UInt64)] = []
        var plain: [(cluster: UInt64, offset: UInt64)] = []

        let l1Table = try readExactly(
            reader,
            at: header.l1TableOffset,
            count: Int(UInt64(header.l1TableEntries) * 8)
        )
        for l1Index in 0..<Int(header.l1TableEntries) {
            let l1Entry = DiskImageInspector.beU64(l1Table, l1Index * 8)
            guard l1Entry & offsetMask != 0 else { continue }

            let l2Table = try readExactly(
                reader,
                at: l1Entry & offsetMask,
                count: Int(header.clusterSize)
            )
            for l2Index in 0..<clusterCount {
                let entry = DiskImageInspector.beU64(l2Table, l2Index * 8)
                guard entry != 0 else { continue }

                let cluster = UInt64(l1Index) * UInt64(clusterCount) + UInt64(l2Index)
                // A disk image cannot be larger than the virtual size it declares.
                guard cluster * header.clusterSize < header.virtualSizeBytes else { continue }

                if entry & compressedBit != 0 {
                    compressed.append((cluster, entry & offsetMask))
                } else if let offset = plainClusterOffset(entry) {
                    plain.append((cluster, offset))
                }
                // Anything else is an explicit zero cluster, which the sparse
                // destination already is.
            }
        }

        // Pass two: a compressed payload runs until the next one starts.
        let offsets = Set(compressed.map(\.offset)).sorted()
        var successor: [UInt64: UInt64] = [:]
        for (index, offset) in offsets.enumerated() where index + 1 < offsets.count {
            successor[offset] = offsets[index + 1]
        }

        // Create the destination at the virtual size so skipping a sparse region
        // only has to seek.
        let manager = FileManager.default
        try manager.createDirectory(
            at: destination.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )
        if (try? manager.destinationOfSymbolicLink(atPath: destination.path)) != nil {
            throw ConversionError.unsupported("destination is a symlink; refusing to write")
        }
        if manager.fileExists(atPath: destination.path) {
            try manager.removeItem(at: destination)
        }
        manager.createFile(atPath: destination.path, contents: nil)
        let writer = try FileHandle(forWritingTo: destination)
        let writerBox = WriterBox(writer: writer)
        defer { writerBox.close() }
        try writer.truncate(atOffset: header.virtualSizeBytes)

        var written: Int64 = 0
        let clusterSize = Int(header.clusterSize)
        let fileSize = (try? manager.attributesOfItem(atPath: source.path)[.size] as? NSNumber)?
            .uint64Value ?? 0
        var lastReported: Double = -1

        for item in compressed {
            let end = successor[item.offset] ?? min(item.offset + UInt64(maximumCompressedBytes), fileSize)
            let length = Int(end > item.offset ? end - item.offset : 0)
            guard length > 0 else { continue }
            // A far-apart crafted offset pair must not allocate gigabytes.
            guard length <= maximumCompressedBytes * 2 else {
                throw ConversionError.unsupported("compressed payload of \(length) bytes is implausible")
            }

            let payload = try readExactly(reader, at: item.offset, count: length)
            guard let cluster = inflate(payload, to: clusterSize) else {
                throw ConversionError.decompressionFailed(cluster: item.cluster)
            }
            try writerBox.write(cluster, at: item.cluster * header.clusterSize)

            written = Int64(item.cluster * header.clusterSize) + Int64(clusterSize)
            let fraction = Double(written) / Double(header.virtualSizeBytes)
            // Throttle: thousands of per-cluster callbacks previously hopped
            // to @MainActor per cluster. Report on ~1% steps only.
            if fraction - lastReported >= 0.01 {
                lastReported = fraction
                progress?(Progress(writtenBytes: written, totalBytes: Int64(header.virtualSizeBytes)))
            }
        }

        for item in plain {
            let cluster = try readExactly(reader, at: item.offset, count: clusterSize)
            try writerBox.write(cluster, at: item.cluster * header.clusterSize)
            written = Int64(item.cluster * header.clusterSize) + Int64(clusterSize)
            // Plain clusters are fewer; report sparingly too.
            let fraction = Double(written) / Double(header.virtualSizeBytes)
            if fraction - lastReported >= 0.02 {
                lastReported = fraction
                progress?(Progress(writtenBytes: written, totalBytes: Int64(header.virtualSizeBytes)))
            }
        }

        try writer.truncate(atOffset: header.virtualSizeBytes)
        try writer.synchronize()
        progress?(Progress(
            writtenBytes: Int64(header.virtualSizeBytes),
            totalBytes: Int64(header.virtualSizeBytes)
        ))
        return Summary(
            compressedClusters: compressed.count,
            plainClusters: plain.count,
            bytesWritten: written
        )
    }

    /// Where an uncompressed cluster's bytes live, or nil when the descriptor
    /// means "reads as zeroes".
    ///
    /// A zero cluster may store nothing at all, or an offset with the allocation
    /// bit clear. Both are indistinguishable from data unless the offset is
    /// sanity-checked, and reading the image's own header as disk content is the
    /// failure mode that would produce a disk that looks plausible and is not.
    static func plainClusterOffset(_ entry: UInt64) -> UInt64? {
        let offset = entry & offsetMask
        guard offset != 0, offset % 512 == 0 else { return nil }
        return offset
    }

    static func checkSupported(_ header: QCOW2Header) throws {
        if header.hasBackingFile {
            throw ConversionError.unsupported("it is a delta image with a backing file")
        }
        if header.isEncrypted {
            throw ConversionError.unsupported("it is encrypted")
        }
        if header.has(.externalDataFile) {
            throw ConversionError.unsupported("it keeps its data in an external file")
        }
        if header.has(.zstdCompression) {
            throw ConversionError.unsupported("it uses zstd-compressed clusters")
        }
        if header.has(.extendedL2Entries) {
            throw ConversionError.unsupported("it uses extended (sub-cluster) L2 entries")
        }
        if header.l1TableEntries == 0 {
            throw ConversionError.unsupported("it has an empty L1 table")
        }
        if header.l1TableOffset == 0 {
            throw ConversionError.unsupported("it has no L1 table")
        }
    }

    // MARK: - Byte plumbing

    static func readExactly(_ handle: FileHandle, at offset: UInt64, count: Int) throws -> Data {
        try handle.seek(toOffset: offset)
        let data = try handle.read(upToCount: count) ?? Data()
        guard data.count == count else {
            throw ConversionError.truncated(
                "expected \(count) bytes at offset \(offset), got \(data.count)"
            )
        }
        return data
    }

    /// Inflate one compressed cluster.
    ///
    /// qcow2 payloads are bare DEFLATE streams, but the platform decoder's
    /// expectations about the zlib wrapper are not worth betting a
    /// multi-gigabyte download on, so the plausible framings are tried in turn
    /// and the first that yields exactly one cluster wins.
    static func inflate(_ payload: Data, to size: Int) -> Data? {
        var candidates: [Data] = [payload]
        if payload.count > 2 { candidates.append(payload.dropFirst(2)) }
        if payload.count > 6 { candidates.append(payload.dropFirst(2).dropLast(4)) }

        for candidate in candidates where !candidate.isEmpty {
            if let inflated = decode(candidate, to: size) { return inflated }
        }
        return nil
    }

    static func decode(_ payload: Data, to size: Int) -> Data? {
        var output = Data(count: size)
        let decoded: Int = output.withUnsafeMutableBytes { destination in
            payload.withUnsafeBytes { source in
                guard let destinationBase = destination.bindMemory(to: UInt8.self).baseAddress,
                      let sourceBase = source.bindMemory(to: UInt8.self).baseAddress
                else { return 0 }
                return compression_decode_buffer(
                    destinationBase,
                    size,
                    sourceBase,
                    payload.count,
                    nil,
                    COMPRESSION_ZLIB
                )
            }
        }
        return decoded == size ? output : nil
    }
}

/// Serialises writes to the destination, so the conversion can report progress
/// from wherever it happens to be running.
private final class WriterBox: @unchecked Sendable {
    private let writer: FileHandle
    private let lock = NSLock()

    init(writer: FileHandle) { self.writer = writer }

    func write(_ data: Data, at offset: UInt64) throws {
        lock.lock()
        defer { lock.unlock() }
        try writer.seek(toOffset: offset)
        try writer.write(contentsOf: data)
    }

    func close() {
        lock.lock()
        defer { lock.unlock() }
        try? writer.close()
    }
}
