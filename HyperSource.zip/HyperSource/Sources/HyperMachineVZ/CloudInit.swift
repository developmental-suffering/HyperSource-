import Foundation
import HyperMachineCore

/// What the first boot of a cloud image should do.
///
/// Everything here ends up in the guest's `user-data`. It is a deliberately
/// small surface: a hostname, one account, optional packages, and a handshake
/// that tells the host the guest actually came up.
public struct CloudInitConfig: Sendable {
    public var hostname: String
    public var username: String
    /// Plain-text password for the account. `nil` leaves password login off.
    public var password: String?
    /// SSH public keys to authorise for the account.
    public var sshAuthorizedKeys: [String]
    /// Extra packages to install on first boot.
    public var packages: [String]
    /// Mount tag of the shared folder used for the boot handshake. The seed
    /// writes a marker file into it, which is how the host can tell that EFI
    /// boot, the kernel, virtio-fs and cloud-init all worked — without needing
    /// to see the guest's screen.
    public var handshakeMountTag: String
    /// Where the handshake marker is written, relative to that folder.
    public var handshakeFile: String
    /// Shell commands appended to the first boot's `runcmd`.
    ///
    /// Deliberately generic instead of a flag per diagnostic: the network
    /// isolation checks use it to install a small watchdog that keeps reporting
    /// connectivity from *inside* the guest, which is the only place the answer
    /// is trustworthy.
    public var extraRunCommands: [String]

    public init(
        hostname: String,
        username: String,
        password: String? = nil,
        sshAuthorizedKeys: [String] = [],
        packages: [String] = [],
        handshakeMountTag: String = LinuxInstallDriver.handshakeTag,
        handshakeFile: String = LinuxInstallDriver.handshakeFilename,
        extraRunCommands: [String] = []
    ) {
        self.hostname = hostname
        self.username = username
        self.password = password
        self.sshAuthorizedKeys = sshAuthorizedKeys
        self.packages = packages
        self.handshakeMountTag = handshakeMountTag
        self.handshakeFile = handshakeFile
        self.extraRunCommands = extraRunCommands
    }
}

/// Builds a NoCloud seed volume.
///
/// cloud-init's NoCloud datasource looks for a volume labelled `CIDATA`
/// containing `user-data` and `meta-data`, so this produces exactly that: a
/// small directory, then an ISO9660 image of it.
public enum CloudInitSeed {
    public enum SeedError: Error, CustomStringConvertible {
        case toolFailed(String)
        case missingTool(String)
        case invalidField(String)

        public var description: String {
            switch self {
            case .toolFailed(let detail): return "could not build the cloud-init seed: \(detail)"
            case .missingTool(let tool): return "\(tool) is required to build a seed volume and was not found"
            case .invalidField(let detail): return "invalid cloud-init field: \(detail)"
            }
        }
    }

    /// Strict allow-list for shell/YAML interpolation. Hostname/usernames
    /// flow into cloud-config and a root shell command, so anything outside
    /// hostname semantics is rejected rather than escaped.
    public static func sanitizedHostname(_ s: String) throws -> String {
        let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty, t.count <= 64,
              t.allSatisfy({ $0.isLetter || $0.isNumber || $0 == "-" || $0 == "." }),
              !t.hasPrefix("-"), !t.hasPrefix(".") else {
            throw SeedError.invalidField("hostname must be 1-64 letters/digits/dots/dashes")
        }
        return t.lowercased()
    }

    public static func sanitizedUsername(_ s: String) throws -> String {
        let t = s.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !t.isEmpty, t.count <= 32,
              t.first?.isLetter == true,
              t.allSatisfy({ $0.isLetter || $0.isNumber || $0 == "-" || $0 == "_" }) else {
            throw SeedError.invalidField("username must start with a letter, 1-32 [a-z0-9_-]")
        }
        return t.lowercased()
    }

    public static func sanitizedTag(_ s: String) throws -> String {
        guard !s.isEmpty, s.count <= 64, s != ".", s != "..",
              s.allSatisfy({ $0.isLetter || $0.isNumber || $0 == "-" || $0 == "_" || $0 == "." }) else {
            throw SeedError.invalidField("mount tag must be 1-64 [a-zA-Z0-9._-]")
        }
        return s
    }

    public static func sanitizedFilename(_ s: String) throws -> String {
        guard !s.isEmpty, s.count <= 128, !s.contains("/"), !s.contains(".."),
              !s.contains(where: \.isWhitespace),
              !s.contains("\""), !s.contains(";"), !s.contains("$"), !s.contains("`") else {
            throw SeedError.invalidField("handshake filename is unsafe")
        }
        return s
    }

    static func yamlSingleQuoted(_ s: String) -> String {
        "'" + s.replacingOccurrences(of: "'", with: "''") + "'"
    }

    /// The volume label cloud-init looks for. Case matters to some datasource
    /// versions, and `CIDATA` is the conventional form.
    public static let volumeLabel = "CIDATA"

    public static func makeSeedISO(
        at destination: URL,
        config: CloudInitConfig,
        instanceID: String = UUID().uuidString
    ) throws {
        // Fail closed on injection: validate before writing anything.
        _ = try sanitizedHostname(config.hostname)
        _ = try sanitizedUsername(config.username)
        _ = try sanitizedTag(config.handshakeMountTag)
        _ = try sanitizedFilename(config.handshakeFile)
        if let password = config.password {
            guard !password.isEmpty, password.count <= 256,
                  !password.contains("\n"), !password.contains("\r") else {
                throw SeedError.invalidField("password must be 1-256 chars with no newlines")
            }
        }
        for pkg in config.packages {
            guard !pkg.isEmpty, pkg.count <= 128, !pkg.contains("\n"),
                  pkg.allSatisfy({ $0.isLetter || $0.isNumber || $0 == "-" || $0 == "_" || $0 == "." || $0 == "+" }) else {
                throw SeedError.invalidField("package name '\(pkg)' is unsafe")
            }
        }
        for key in config.sshAuthorizedKeys {
            let t = key.trimmingCharacters(in: .whitespacesAndNewlines)
            guard !t.isEmpty, t.count <= 4096, !t.contains("\n"),
                  t.hasPrefix("ssh-") || t.hasPrefix("ecdsa-") || t.hasPrefix("sk-") else {
                throw SeedError.invalidField("SSH key is not a single-line OpenSSH public key")
            }
        }
        // Refuse to follow or overwrite a symlink at the destination.
        if (try? FileManager.default.destinationOfSymbolicLink(atPath: destination.path)) != nil {
            throw SeedError.invalidField("seed destination is a symlink; refusing to write")
        }
        let fileManager = FileManager.default
        let staging = fileManager.temporaryDirectory
            .appendingPathComponent("hyper-machine-seed-\(UUID().uuidString)", isDirectory: true)
        defer { try? fileManager.removeItem(at: staging) }
        try fileManager.createDirectory(at: staging, withIntermediateDirectories: true)

        try userData(config).write(
            to: staging.appendingPathComponent("user-data"),
            atomically: true,
            encoding: .utf8
        )
        try metaData(config, instanceID: instanceID).write(
            to: staging.appendingPathComponent("meta-data"),
            atomically: true,
            encoding: .utf8
        )

        try fileManager.createDirectory(
            at: destination.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )
        if fileManager.fileExists(atPath: destination.path) {
            try fileManager.removeItem(at: destination)
        }

        try run(
            "/usr/bin/hdiutil",
            [
                "makehybrid",
                "-o", destination.path,
                "-iso", "-joliet",
                "-default-volume-name", volumeLabel,
                staging.path
            ],
            label: "hdiutil"
        )
    }

    /// `meta-data` is what makes the instance unique; without an instance-id
    /// cloud-init may skip provisioning it has already seen.
    static func metaData(_ config: CloudInitConfig, instanceID: String) -> String {
        let hostname = (try? sanitizedHostname(config.hostname)) ?? "hyper"
        let safeInstance = instanceID.replacingOccurrences(of: "\n", with: "")
            .replacingOccurrences(of: "'", with: "")
        return """
        instance-id: \(safeInstance)
        local-hostname: \(hostname)
        """
    }

    static func userData(_ config: CloudInitConfig) -> String {
        // All interpolated fields are allow-list validated at makeSeedISO time;
        // YAML quoting here is defense in depth.
        let hostname = (try? sanitizedHostname(config.hostname)) ?? "hyper"
        let username = (try? sanitizedUsername(config.username)) ?? "hyper"
        let tag = (try? sanitizedTag(config.handshakeMountTag)) ?? "hypermachine"
        let file = (try? sanitizedFilename(config.handshakeFile)) ?? "boot-ok"
        var lines: [String] = [
            "#cloud-config",
            "hostname: \(yamlSingleQuoted(hostname))",
            "manage_etc_hosts: true",
            "preserve_hostname: false"
        ]

        // An account with sudo, so the guest is usable the moment it is up.
        lines.append("users:")
        lines.append("  - name: \(yamlSingleQuoted(username))")
        lines.append("    sudo: ALL=(ALL) NOPASSWD:ALL")
        lines.append("    groups: [sudo]")
        lines.append("    shell: /bin/bash")
        lines.append("    lock_passwd: \(config.password == nil ? "true" : "false")")
        if !config.sshAuthorizedKeys.isEmpty {
            lines.append("    ssh_authorized_keys:")
            for key in config.sshAuthorizedKeys {
                let singleLine = key.replacingOccurrences(of: "\n", with: "").replacingOccurrences(of: "\r", with: "")
                lines.append("      - \(yamlSingleQuoted(singleLine))")
            }
        }

        if let password = config.password {
            lines.append("ssh_pwauth: true")
            lines.append("chpasswd:")
            lines.append("  expire: false")
            lines.append("  users:")
            lines.append("    - name: \(yamlSingleQuoted(username))")
            lines.append("      password: \(yamlSingleQuoted(password))")
            lines.append("      type: text")
        }

        if !config.packages.isEmpty {
            lines.append("packages:")
            for package in config.packages {
                lines.append("  - \(yamlSingleQuoted(package))")
            }
        }

        // The handshake. The guest mounts the shared folder and drops a marker
        // in it, which is the host's only proof that the whole chain worked.
        //
        // The marker also carries what the guest can see of its own network, so
        // an isolation claim can be checked against the guest rather than
        // against the host's intentions.
        lines.append("runcmd:")
        lines.append("  - [ sh, -c, \"mkdir -p /mnt/hm-handshake && mount -t virtiofs \(tag) /mnt/hm-handshake && { date -Is; hostname; uname -r; echo '--- interfaces ---'; ip -br link 2>/dev/null || true; echo '--- addresses ---'; ip -br addr 2>/dev/null || true; echo '--- routes ---'; ip route 2>/dev/null || true; } > /mnt/hm-handshake/\(file)\" ]")
        // A serial console is best-effort: the guest only writes there if its
        // kernel was told to use this console, which a stock cloud image is not.
        lines.append("  - [ sh, -c, \"echo 'HyperMachine: cloud-init finished' > /dev/hvc0 || true\" ]")

        for command in config.extraRunCommands {
            lines.append("  - [ sh, -c, \"\(yamlFlowScalar(command))\" ]")
        }

        return lines.joined(separator: "\n") + "\n"
    }

    /// Escape a command so it survives being placed inside a double-quoted YAML
    /// flow scalar. A newline would end the mapping entry and quietly change the
    /// document's shape.
    static func yamlFlowScalar(_ text: String) -> String {
        text
            .replacingOccurrences(of: "\\", with: "\\\\")
            .replacingOccurrences(of: "\"", with: "\\\"")
            .replacingOccurrences(of: "\n", with: "; ")
            .replacingOccurrences(of: "\r", with: "")
    }

    private static func run(_ executable: String, _ arguments: [String], label: String) throws {
        guard FileManager.default.isExecutableFile(atPath: executable) else {
            throw SeedError.missingTool(label)
        }
        let process = Process()
        process.executableURL = URL(fileURLWithPath: executable)
        process.arguments = arguments
        let pipe = Pipe()
        process.standardOutput = pipe
        process.standardError = pipe

        do {
            try process.run()
        } catch {
            throw SeedError.toolFailed("\(label) could not run: \(error)")
        }
        let output = pipe.fileHandleForReading.readDataToEndOfFile()
        process.waitUntilExit()
        guard process.terminationStatus == 0 else {
            let text = String(decoding: output, as: UTF8.self)
            throw SeedError.toolFailed("\(label) exited \(process.terminationStatus): \(text)")
        }
    }
}
