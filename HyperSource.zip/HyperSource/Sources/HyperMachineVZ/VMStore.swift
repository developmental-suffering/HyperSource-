import Foundation
import HyperMachineCore

/// Where a guest's system came from, so the UI can say something more useful
/// than "installed".
public struct InstalledFrom: Codable, Sendable, Equatable {
    /// Catalog id, e.g. `ubuntu-24.04-cloud-arm64`.
    public var catalogID: String
    public var catalogName: String
    /// The image that was fetched, if it was not Apple's.
    public var imageURL: String?
    /// macOS restore-image build, or the vendor image's release identifier.
    public var build: String?
    public var date: Date

    public init(
        catalogID: String,
        catalogName: String,
        imageURL: String? = nil,
        build: String? = nil,
        date: Date = Date()
    ) {
        self.catalogID = catalogID
        self.catalogName = catalogName
        self.imageURL = imageURL
        self.build = build
        self.date = date
    }
}

/// A VM as persisted to disk, so an install survives a reboot and the app can
/// list, edit and boot it later.
///
/// One type covers every guest: the macOS-only fields are optional, which also
/// means every `vm.json` written by an earlier version of this project still
/// decodes.
public struct StoredVM: Codable, Sendable {
    public var config: VMConfig

    /// macOS guests only. The hardware model the VM was created against. Apple
    /// requires this to stay stable for the life of the VM: it must match the
    /// model used to create the auxiliary storage.
    public var hardwareModelData: Data?
    /// macOS guests only. Which restore image the guest was installed from.
    public var restoreImageBuild: String?
    /// How the guest's system was obtained.
    public var installedFrom: InstalledFrom?

    public var installed: Bool

    public init(
        config: VMConfig,
        hardwareModelData: Data? = nil,
        restoreImageBuild: String? = nil,
        installedFrom: InstalledFrom? = nil,
        installed: Bool
    ) {
        self.config = config
        self.hardwareModelData = hardwareModelData
        self.restoreImageBuild = restoreImageBuild
        self.installedFrom = installedFrom
        self.installed = installed
    }

    /// Installer media currently attached, if any.
    public var installMedia: [DiskConfig] { config.installMedia }
}

public enum VMStoreError: Error, CustomStringConvertible {
    case invalidName(String)
    case notFound(String)
    case notInstalled(String)

    public var description: String {
        switch self {
        case .invalidName(let name):
            return "'\(name)' is not a usable VM name: use letters, digits, dots, dashes and underscores."
        case .notFound(let name):
            return "No VM named '\(name)'. Run `hm list` to see what exists."
        case .notInstalled(let name):
            return "'\(name)' has not finished installing."
        }
    }
}

/// Where a VM's files live inside its directory. macOS and Linux guests need
/// different files, but they share one layout so the app has one thing to reason
/// about.
public struct VMLayout: Sendable {
    public let root: URL

    public var configFile: URL { root.appendingPathComponent("vm.json") }
    public var disk: URL { root.appendingPathComponent("disk.raw") }
    public var consoleLog: URL { root.appendingPathComponent("console.log") }

    /// macOS guests.
    public var machineIdentifier: URL { root.appendingPathComponent("machine-identifier.bin") }
    public var hardwareModel: URL { root.appendingPathComponent("hardware-model.bin") }
    public var auxiliaryStorage: URL { root.appendingPathComponent("auxiliary-storage.bin") }

    /// Generic-platform (Linux/Windows) guests.
    public var genericMachineIdentifier: URL { root.appendingPathComponent("generic-machine-identifier.bin") }
    public var efiVariableStore: URL { root.appendingPathComponent("efi-variable-store.bin") }
    /// NoCloud cloud-init seed, attached as a read-only volume labelled CIDATA.
    public var cloudInitSeed: URL { root.appendingPathComponent("cloud-init-seed.iso") }

    public init(root: URL) {
        self.root = root
    }

    public func prepare() throws {
        try FileManager.default.createDirectory(at: root, withIntermediateDirectories: true)
    }

    /// Every file this VM owns, for size reporting and deletion.
    public var contents: [URL] {
        [
            configFile, disk, consoleLog, machineIdentifier, hardwareModel,
            auxiliaryStorage, genericMachineIdentifier, efiVariableStore, cloudInitSeed
        ]
    }
}

/// Where HyperMachine keeps its VMs and downloaded images.
public enum VMStore {
    public static var root: URL {
        URL(fileURLWithPath: NSHomeDirectory())
            .appendingPathComponent("Documents/HyperMachine/VMs", isDirectory: true)
    }

    /// Guest images are large and reusable, so they live in the caches
    /// directory rather than inside each VM.
    public static var restoreImageCache: URL {
        URL(fileURLWithPath: NSHomeDirectory())
            .appendingPathComponent("Library/Caches/HyperMachine/RestoreImages", isDirectory: true)
    }

    public static var linuxImageCache: URL {
        URL(fileURLWithPath: NSHomeDirectory())
            .appendingPathComponent("Library/Caches/HyperMachine/LinuxImages", isDirectory: true)
    }

    public static func isValidName(_ name: String) -> Bool {
        !name.isEmpty
            && name != "."
            && name != ".."
            && !name.contains("/")
            && name.allSatisfy { $0.isLetter || $0.isNumber || $0 == "." || $0 == "-" || $0 == "_" }
    }

    public static func directory(for name: String) throws -> URL {
        guard isValidName(name) else { throw VMStoreError.invalidName(name) }
        return root.appendingPathComponent(name, isDirectory: true)
    }

    public static func configURL(for name: String) throws -> URL {
        try directory(for: name).appendingPathComponent("vm.json")
    }

    public static func layout(for name: String) throws -> VMLayout {
        VMLayout(root: try directory(for: name))
    }

    public static func load(name: String) throws -> StoredVM {
        let url = try configURL(for: name)
        guard let data = try? Data(contentsOf: url) else { throw VMStoreError.notFound(name) }
        return try JSONDecoder().decode(StoredVM.self, from: data)
    }

    public static func save(_ vm: StoredVM, name: String) throws {
        let directory = try directory(for: name)
        try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
        let url = try configURL(for: name)
        if (try? FileManager.default.destinationOfSymbolicLink(atPath: url.path)) != nil {
            throw VMStoreError.invalidName("config path is a symlink; refusing to write")
        }
        let encoder = JSONEncoder()
        encoder.outputFormatting = [.prettyPrinted, .sortedKeys]
        try encoder.encode(vm).write(to: url, options: .atomic)
        // Secrets-adjacent file: owner-only.
        try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
    }

    /// Every VM on disk, newest first, skipping directories that are not VMs.
    public static func all() -> [StoredVM] {
        names()
            .compactMap { try? load(name: $0) }
            .sorted { $0.config.name.localizedStandardCompare($1.config.name) == .orderedAscending }
    }

    public static func names() -> [String] {
        (try? FileManager.default.contentsOfDirectory(
            at: root,
            includingPropertiesForKeys: nil,
            options: [.skipsHiddenFiles]
        ))?.map(\.lastPathComponent).sorted() ?? []
    }

    /// A disk holding a boot volume cannot be deleted while the VM exists.
    public static func delete(name: String) throws {
        let directory = try directory(for: name)
        guard FileManager.default.fileExists(atPath: directory.path) else {
            throw VMStoreError.notFound(name)
        }
        try FileManager.default.removeItem(at: directory)
    }

    // MARK: - Cached images

    public static func existingRestoreImage(build: String) -> URL? {
        let url = restoreImageURL(build: build)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    public static func restoreImageURL(build: String) -> URL {
        restoreImageCache.appendingPathComponent("UniversalMac_\(build).ipsw")
    }

    public static func linuxImageURL(filename: String) -> URL {
        linuxImageCache.appendingPathComponent(filename)
    }

    public static func cachedLinuxImage(filename: String) -> URL? {
        let url = linuxImageURL(filename: filename)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    /// Virtualization.framework attaches a disk image but does not create or
    /// size it: that is the caller's job. A sparse file is correct here, since
    /// the guest writes only what it needs.
    public static func createSizedDisk(at url: URL, sizeBytes: UInt64) throws {
        let manager = FileManager.default
        guard !manager.fileExists(atPath: url.path) else { return }
        if (try? manager.destinationOfSymbolicLink(atPath: url.path)) != nil {
            throw VMStoreError.invalidName("disk path is a symlink; refusing to create")
        }
        // 512 GiB sanity cap: protects against crafted vm.json sizes.
        guard sizeBytes <= 512 * 1_073_741_824 else {
            throw VMStoreError.invalidName("disk size exceeds 512 GiB cap")
        }
        manager.createFile(atPath: url.path, contents: nil)
        try? manager.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
        let handle = try FileHandle(forWritingTo: url)
        try handle.truncate(atOffset: sizeBytes)
        try handle.close()
    }

    /// Grow a disk file in place. Shrinking is refused: truncating the file
    /// under a guest's file system destroys it, and the guest would have to
    /// repair or repartition its way out.
    public static func resizeDisk(at url: URL, to sizeBytes: UInt64) throws {
        if (try? FileManager.default.destinationOfSymbolicLink(atPath: url.path)) != nil {
            throw VMStoreError.invalidName("disk path is a symlink; refusing to resize")
        }
        guard sizeBytes <= 512 * 1_073_741_824 else {
            throw VMStoreError.invalidName("disk size exceeds 512 GiB cap")
        }
        let attributes = try FileManager.default.attributesOfItem(atPath: url.path)
        let existing = (attributes[.size] as? NSNumber)?.uint64Value ?? 0
        guard sizeBytes > existing else { return }
        let handle = try FileHandle(forWritingTo: url)
        try handle.truncate(atOffset: sizeBytes)
        try handle.close()
        try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: url.path)
    }

    /// What the VM actually costs on disk. A sparse 64 GiB raw file whose guest
    /// has written 12 GiB allocates 12 GiB, and that is the number worth showing.
    public static func allocatedBytes(of url: URL) -> UInt64 {
        var info = stat()
        guard lstat(url.path, &info) == 0 else { return 0 }
        return UInt64(info.st_blocks) * 512
    }
}
