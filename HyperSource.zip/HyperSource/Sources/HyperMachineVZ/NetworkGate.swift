import Foundation
import Virtualization
import HyperMachineCore

/// The runtime half of network isolation: the switch you can flip while a guest
/// is running.
///
/// `VZNetworkDevice` — the *live* device, not the configuration — declares:
///
/// ```objc
/// @property (nullable, strong) VZNetworkDeviceAttachment *attachment;
/// ```
///
/// and its documentation says the setter "will result in an attempt to change
/// the network device attachment which may fail, in which case
/// -[VZVirtualMachineDelegate virtualMachine:networkDevice:attachmentWasDisconnectedWithError:]
/// will be invoked and this property will be set to nil." That is a supported
/// runtime change, which is what makes an instant cut-off possible without
/// stopping the machine.
///
/// Passing `nil` leaves the guest with no attachment: no NAT, no bridge, no
/// backend of any kind. Whatever the guest sends has nowhere to go.
///
/// Main-actor isolated on purpose: `VZVirtualMachine` is not `Sendable`, and the
/// framework's machine APIs are main-thread affine in practice. Both callers —
/// the app's running-VM window and the CLI's network test — are already on the
/// main actor, so this costs nothing and removes a real data race.
@MainActor
public enum NetworkGate {
    public enum GateError: Error, CustomStringConvertible {
        /// The machine was built air-gapped, so it has no device to switch.
        case noNetworkDevice(String)
        case refused(String)

        public var description: String {
            switch self {
            case .noNetworkDevice(let name):
                return """
                \(name) was created with no network device, so there is nothing to \
                switch. An air-gapped machine stays air-gapped until it is recreated \
                without that setting.
                """
            case .refused(let detail):
                return "the network device refused the change: \(detail)"
            }
        }
    }

    /// What happened when the switch was flipped.
    public struct SwitchResult: Sendable {
        public let requestedInternet: Bool
        /// The device's state after the change had a chance to settle.
        public let isConnected: Bool
        /// How many times the change had to be applied. More than one means the
        /// framework discarded the first attempt.
        public let attempts: Int
        public let detail: String

        /// False when the framework accepted the call but did not keep the
        /// device — the case its own documentation warns about.
        public var tookEffect: Bool { requestedInternet == isConnected }
    }

    /// How long to wait before believing a change stuck.
    ///
    /// Apple's own documentation for the setter says the change "may fail, in
    /// which case … attachmentWasDisconnectedWithError: will be invoked and this
    /// property will be set to nil" — a failure that arrives *after* the setter
    /// returns. Measured against a running Ubuntu guest, a re-attach can report
    /// success and be discarded moments later, leaving the interface up with no
    /// working path behind it. So a change is only reported as done once it has
    /// survived a settle, and a discarded attempt is retried.
    public static let defaultSettleSeconds: Double = 1.5
    public static let defaultAttempts = 3

    /// Whether this machine has a device that can be switched at all.
    public static func hasSwitchableDevice(_ machine: VZVirtualMachine) -> Bool {
        !machine.networkDevices.isEmpty
    }

    /// Whether the guest currently has a network backend attached.
    ///
    /// A machine with no network device reports `false`, which is correct: it
    /// has no connectivity, not a disabled one.
    public static func isConnected(_ machine: VZVirtualMachine) -> Bool {
        guard let device = machine.networkDevices.first else { return false }
        return device.attachment != nil
    }

    /// Apply the switch once, without waiting to see whether it sticks.
    ///
    /// Only useful for cutting connectivity, which is immediate and cannot be
    /// undone by a later failure. For turning the internet back on, use
    /// `setInternet(_:on:name:)`, which verifies.
    @discardableResult
    public static func applyInternet(
        _ enabled: Bool,
        on machine: VZVirtualMachine,
        name: String = "this machine"
    ) throws -> SwitchResult {
        guard let device = machine.networkDevices.first else {
            throw GateError.noNetworkDevice(name)
        }
        device.attachment = enabled ? VZNATNetworkDeviceAttachment() : nil
        return result(
            for: enabled,
            connected: device.attachment != nil,
            attempts: 1,
            name: name
        )
    }

    /// Turn the internet on or off for a running machine, and confirm it held.
    ///
    /// On means NAT through the host. Off means *no attachment* — not a blocked
    /// route, not a firewall rule, but no backend for the guest's frames.
    @discardableResult
    public static func setInternet(
        _ enabled: Bool,
        on machine: VZVirtualMachine,
        name: String = "this machine",
        settlingFor seconds: Double = defaultSettleSeconds,
        attempts: Int = defaultAttempts
    ) async throws -> SwitchResult {
        guard let device = machine.networkDevices.first else {
            throw GateError.noNetworkDevice(name)
        }

        var lastConnected = false
        for attempt in 1...max(1, attempts) {
            device.attachment = enabled ? VZNATNetworkDeviceAttachment() : nil

            // Detaching takes effect the moment it is set; attaching is the
            // direction the framework can silently drop.
            if !enabled {
                lastConnected = device.attachment != nil
                if !lastConnected {
                    return result(for: false, connected: false, attempts: attempt, name: name)
                }
                continue
            }

            try? await Task.sleep(nanoseconds: UInt64(seconds * 1_000_000_000))
            lastConnected = device.attachment != nil
            if lastConnected {
                return result(for: true, connected: true, attempts: attempt, name: name)
            }
        }

        throw GateError.refused(
            """
            the framework discarded the attachment \(attempts) time(s). The guest's link \
            may be up with nothing behind it; restarting the machine restores networking.
            """
        )
    }

    /// The reverse of `setInternet`, for a caller that wants the state toggled
    /// without knowing what it currently is. Always verifies, because it cannot
    /// know in advance which direction it is going.
    @discardableResult
    public static func toggleInternet(
        on machine: VZVirtualMachine,
        name: String = "this machine"
    ) async throws -> SwitchResult {
        try await setInternet(!isConnected(machine), on: machine, name: name)
    }

    private static func result(
        for enabled: Bool,
        connected: Bool,
        attempts: Int,
        name: String
    ) -> SwitchResult {
        let detail: String
        if connected && attempts > 1 {
            detail = "NAT attached after \(attempts) attempts: the guest can reach the internet through this Mac."
        } else if connected {
            detail = "NAT attached: the guest can reach the internet through this Mac."
        } else {
            detail = "No attachment: the guest has nowhere to send a packet."
        }
        return SwitchResult(
            requestedInternet: enabled,
            isConnected: connected,
            attempts: attempts,
            detail: detail
        )
    }
}
