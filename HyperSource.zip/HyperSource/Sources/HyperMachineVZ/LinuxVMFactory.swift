import Foundation
import Virtualization
import HyperMachineCore

public enum LinuxVMBuildError: Error, CustomStringConvertible {
    case noBootVolume
    case secureBootUnsupported(String)
    case rosettaUnavailable(String)
    case invalidConfiguration(underlying: String)
    case missingInstallerMedia(String)

    public var description: String {
        switch self {
        case .noBootVolume:
            return "The configuration has no disk marked as the boot volume."
        case .secureBootUnsupported(let detail):
            return "EFI Secure Boot could not be enabled: \(detail)"
        case .rosettaUnavailable(let detail):
            return "Rosetta for Linux is unavailable: \(detail)."
        case .invalidConfiguration(let underlying):
            return "Virtualization.framework rejected the configuration: \(underlying)"
        case .missingInstallerMedia(let path):
            return "The installer image at \(path) is not there."
        }
    }
}

/// Builds configurations for guests that expect generic EFI firmware — Linux
/// and, in principle, Windows.
///
/// The device set is deliberately different from the macOS one. These guests
/// have no Mac platform, no Mac boot loader, no Metal-backed graphics device,
/// and no Mac keyboard/trackpad: they get `VZGenericPlatformConfiguration`,
/// `VZEFIBootLoader`, a virtio GPU, and USB input devices. Feeding them the Mac
/// devices produces a machine that validates and then never boots.
public enum LinuxVMFactory {
    /// Mount tag the guest finds Rosetta under. Apple's own samples use this
    /// name and the framework exposes no constant for it, so it is fixed here
    /// and surfaced to the UI so the two cannot drift.
    public static let rosettaMountTag = "rosetta"

    /// The generic machine identifier, or a new one on first run. Apple
    /// requires it to be unique per VM and stable across launches.
    public static func loadOrCreateMachineIdentifier(at url: URL) throws -> VZGenericMachineIdentifier {
        if let data = try? Data(contentsOf: url),
           let identifier = VZGenericMachineIdentifier(dataRepresentation: data) {
            return identifier
        }
        let identifier = VZGenericMachineIdentifier()
        try identifier.dataRepresentation.write(to: url, options: .atomic)
        return identifier
    }

    /// The EFI variable store (NVRAM). Firmware boot entries live here, which is
    /// how the guest remembers what to boot after an installer writes its loader.
    public static func loadOrCreateVariableStore(at url: URL) throws -> VZEFIVariableStore {
        if FileManager.default.fileExists(atPath: url.path) {
            return VZEFIVariableStore(url: url)
        }
        do {
            return try VZEFIVariableStore(
                creatingVariableStoreAt: url,
                options: [.allowOverwrite]
            )
        } catch {
            throw LinuxVMBuildError.invalidConfiguration(underlying: "\(error)")
        }
    }

    public static func makeConfiguration(
        from stored: VMConfig,
        machineIdentifier: VZGenericMachineIdentifier,
        storage: VMLayout
    ) throws -> VZVirtualMachineConfiguration {
        // The single choke point: every device this machine gets is built from
        // the hardened configuration, so lockdown cannot be contradicted by a
        // stray JSON field, a stale saved VM or a CLI flag.
        let config = SecurityPolicy.effective(stored)
        let platform = VZGenericPlatformConfiguration()
        platform.machineIdentifier = machineIdentifier

        let bootLoader = VZEFIBootLoader()
        let variableStore = try loadOrCreateVariableStore(at: storage.efiVariableStore)
        bootLoader.variableStore = variableStore

        if config.security.efiSecureBoot {
            guard #available(macOS 27.0, *) else {
                throw LinuxVMBuildError.secureBootUnsupported(
                    "the framework only offers EFI Secure Boot from macOS 27; this Mac is older"
                )
            }
            do {
                // Signs the guest's boot chain with an Apple-managed platform
                // key, which is what makes Secure Boot meaningful without the
                // user enrolling their own keys.
                try variableStore.enableSecureBootUsingDefaultPlatformKey()
            } catch {
                throw LinuxVMBuildError.secureBootUnsupported("\(error)")
            }
        }

        let configuration = VZVirtualMachineConfiguration()
        configuration.platform = platform
        configuration.bootLoader = bootLoader
        configuration.cpuCount = config.cpu.count
        configuration.memorySize = config.memory.bytes

        // --- Graphics ------------------------------------------------------
        // Virtio GPU: 2D only. Apple exposes no accelerated graphics device for
        // non-macOS guests, which is why `display.gpuAcceleration` is a macOS
        // concept and validation warns about it elsewhere.
        let graphics = VZVirtioGraphicsDeviceConfiguration()
        graphics.scanouts = [
            VZVirtioGraphicsScanoutConfiguration(
                widthInPixels: config.display.widthPixels,
                heightInPixels: config.display.heightPixels
            )
        ]
        configuration.graphicsDevices = [graphics]

        // --- Storage -------------------------------------------------------
        configuration.storageDevices = try config.disks.map { disk in
            guard let url = DeviceBuilders.safeDiskURL(disk.path) else {
                throw LinuxVMBuildError.missingInstallerMedia("unsafe disk path: \(disk.path)")
            }
            // Installer media has to exist; a missing ISO would otherwise be a
            // boot to nothing with no explanation.
            if disk.isInstallMedia && !FileManager.default.fileExists(atPath: url.path) {
                throw LinuxVMBuildError.missingInstallerMedia(url.path)
            }
            // Non-installer disks must exist too (created at install time).
            if !disk.isInstallMedia && !FileManager.default.fileExists(atPath: url.path) {
                throw LinuxVMBuildError.missingInstallerMedia(url.path)
            }
            let attachment = try VZDiskImageStorageDeviceAttachment(
                url: url,
                // An installer ISO is read-only no matter what the config says,
                // and a data disk honours its own flag.
                readOnly: disk.isInstallMedia ? true : disk.readOnly
            )
            return VZVirtioBlockDeviceConfiguration(attachment: attachment)
        }
        guard !configuration.storageDevices.isEmpty else { throw LinuxVMBuildError.noBootVolume }

        // --- Networking ----------------------------------------------------
        // Empty for an isolated guest: no virtio-net device is created at all.
        configuration.networkDevices = try DeviceBuilders.networkDevices(from: config.network)

        // --- Entropy -------------------------------------------------------
        configuration.entropyDevices = [VZVirtioEntropyDeviceConfiguration()]

        // --- Shared folders -------------------------------------------------
        // One virtio-fs device per share, each with its own mount tag, so a
        // read-only share is genuinely read-only and the guest mounts exactly
        // the names the UI showed. Paths are canonicalized and symlinks refused.
        configuration.directorySharingDevices = try config.shares.map { share in
            guard let dir = DeviceBuilders.safeHostDirectory(share.hostPath) else {
                throw LinuxVMBuildError.invalidConfiguration(underlying: "unsafe share path: \(share.hostPath)")
            }
            let device = VZVirtioFileSystemDeviceConfiguration(tag: share.name)
            device.share = VZSingleDirectoryShare(
                directory: VZSharedDirectory(
                    url: dir,
                    readOnly: share.readOnly
                )
            )
            return device
        }

        // --- Rosetta for Linux ---------------------------------------------
        // Lets an arm64 Linux guest run x86-64 binaries. The guest still has to
        // mount the share and register it with binfmt_misc.
        if config.rosettaEnabled {
            switch VZLinuxRosettaDirectoryShare.availability {
            case .notSupported:
                throw LinuxVMBuildError.rosettaUnavailable(
                    "this Mac cannot run Rosetta for Linux"
                )
            case .notInstalled:
                throw LinuxVMBuildError.rosettaUnavailable(
                    "Rosetta for Linux is not installed; install it, then try again"
                )
            case .installed:
                // The initialiser fails rather than returning nil when Rosetta
                // is missing, so it is wrapped rather than force-tried.
                let rosetta = try VZLinuxRosettaDirectoryShare()
                let device = VZVirtioFileSystemDeviceConfiguration(tag: rosettaMountTag)
                device.share = rosetta
                configuration.directorySharingDevices.append(device)
            @unknown default:
                throw LinuxVMBuildError.rosettaUnavailable("unrecognised Rosetta availability")
            }
        }

        // --- Input ---------------------------------------------------------
        // USB input devices, not the Mac ones: the Mac keyboard/trackpad are
        // only recognised by macOS 13+ guests, so a Linux guest would boot to a
        // desktop it cannot be controlled from.
        configuration.keyboards = [VZUSBKeyboardConfiguration()]
        configuration.pointingDevices = [VZUSBScreenCoordinatePointingDeviceConfiguration()]

        // --- Serial console ------------------------------------------------
        if config.serialConsoleLogging,
           let attachment = DeviceBuilders.serialConsoleLogAttachment(at: storage.consoleLog) {
            let port = VZVirtioConsoleDeviceSerialPortConfiguration()
            port.attachment = attachment
            configuration.serialPorts = [port]
        }

        do {
            try configuration.validate()
        } catch {
            throw LinuxVMBuildError.invalidConfiguration(underlying: "\(error)")
        }
        return configuration
    }
}
