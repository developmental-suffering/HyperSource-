import Foundation
import HyperMachineCore

/// Everything needed to create and install a macOS VM, independent of who is
/// asking. The CLI turns these into flags; the app builds them from a form.
public struct MacOSInstallRequest: Sendable {
    public var name: String
    public var cpuCount: Int
    public var cpuPlacement: CorePlacementPolicy
    public var memoryGiB: Double
    public var diskGiB: UInt64
    public var network: NetworkConfig
    public var shares: [ShareConfig]
    public var display: DisplayConfig
    public var security: SecurityConfig

    public init(
        name: String,
        cpuCount: Int = 4,
        cpuPlacement: CorePlacementPolicy = .performancePreferred,
        memoryGiB: Double = 8,
        diskGiB: UInt64 = 64,
        network: NetworkConfig = NetworkConfig(),
        shares: [ShareConfig] = [],
        display: DisplayConfig = DisplayConfig(),
        security: SecurityConfig = .default
    ) {
        self.name = name
        self.cpuCount = cpuCount
        self.cpuPlacement = cpuPlacement
        self.memoryGiB = memoryGiB
        self.diskGiB = diskGiB
        self.network = network
        self.shares = shares
        self.display = display
        self.security = security
    }
}

/// Progress a caller can render however it likes: a log line, or a progress bar.
public enum MacOSInstallEvent: Sendable {
    case resolvingImage
    /// The plan carries Apple's own floor for vCPUs and memory, which can be
    /// higher than whatever the user asked for.
    case resolved(MacOSInstallPlan)
    case usingCachedImage(URL)
    case downloading(fraction: Double, received: Int64, total: Int64)
    case downloaded(URL, bytes: Int64)
    case preparingStorage(URL)
    case installing(fraction: Double)
    case finished(StoredVM)
}

/// The one place a macOS VM is downloaded, created and installed.
///
/// Both `hm macos-install` and the app call this. Keeping it here means the
/// sequencing that matters — hardware model must be written before the
/// auxiliary storage is created, the machine identifier must be stable, the
/// boot disk must exist and be sized before the framework attaches it — exists
/// in exactly one implementation.
public enum MacOSInstallDriver {
    /// - Note: Runs on the main actor because `VZMacOSInstaller` and its runner
    ///   are main-actor types. The download callback hops back to the main
    ///   actor so callers can touch UI state directly.
    @MainActor
    public static func install(
        _ request: MacOSInstallRequest,
        onEvent: @escaping @MainActor @Sendable (MacOSInstallEvent) -> Void
    ) async throws -> StoredVM {
        guard VMStore.isValidName(request.name) else {
            throw VMStoreError.invalidName(request.name)
        }

        onEvent(.resolvingImage)
        let plan = try await MacOSInstallPlanner.latestSupported()
        onEvent(.resolved(plan))

        // The restore image imposes its own floor on top of the framework's, so
        // a request below it has to be raised rather than rejected.
        let capabilities = VZCapabilities.current()
        let effectiveCPUs = max(request.cpuCount, plan.minimumSupportedCPUCount)
        let effectiveMemory = max(
            UInt64(request.memoryGiB * 1_073_741_824),
            plan.minimumSupportedMemorySize
        )

        // --- Restore image -------------------------------------------------
        let imageURL = VMStore.restoreImageURL(build: plan.buildVersion)
        if VMStore.existingRestoreImage(build: plan.buildVersion) != nil {
            onEvent(.usingCachedImage(imageURL))
        } else {
            try await ResumableDownloader.download(from: plan.restoreImageURL, to: imageURL) { progress in
                let event = MacOSInstallEvent.downloading(
                    fraction: progress.fraction,
                    received: progress.received,
                    total: progress.total
                )
                Task { @MainActor in onEvent(event) }
            }
            let attributes = try? FileManager.default.attributesOfItem(atPath: imageURL.path)
            let bytes = (attributes?[.size] as? NSNumber)?.int64Value ?? 0
            onEvent(.downloaded(imageURL, bytes: bytes))
        }

        // --- VM storage ----------------------------------------------------
        let layout = try VMStore.layout(for: request.name)
        try layout.prepare()
        onEvent(.preparingStorage(layout.root))

        try plan.hardwareModelData.write(to: layout.hardwareModel, options: .atomic)
        _ = try MacOSVMFactory.createAuxiliaryStorage(
            at: layout.auxiliaryStorage,
            hardwareModelData: plan.hardwareModelData,
            overwrite: true
        )
        let identifier = try MacOSVMFactory.loadOrCreateMachineIdentifier(at: layout.machineIdentifier)

        let diskBytes = request.diskGiB * 1_073_741_824
        let diskURL = layout.root.appendingPathComponent("disk.raw")
        try VMStore.createSizedDisk(at: diskURL, sizeBytes: diskBytes)

        var config = VMConfig.recommended(named: request.name, guest: .macOS, capabilities: capabilities)
        config.cpu = CPUConfig(count: effectiveCPUs, placement: request.cpuPlacement)
        config.memory = MemoryConfig(bytes: effectiveMemory)
        config.disks = [
            DiskConfig(path: diskURL.path, sizeBytes: diskBytes, format: .raw, isBootVolume: true)
        ]
        config.network = request.network
        config.shares = request.shares
        config.display = request.display
        config.security = request.security

        var stored = StoredVM(
            config: config,
            hardwareModelData: plan.hardwareModelData,
            restoreImageBuild: plan.buildVersion,
            installedFrom: InstalledFrom(
                catalogID: "macos-latest",
                catalogName: "macOS \(plan.operatingSystemVersion)",
                imageURL: plan.restoreImageURL.absoluteString,
                build: plan.buildVersion
            ),
            installed: false
        )
        // Persist as "not installed" *before* installing: if the process dies
        // mid-install, the app can tell a half-built VM from a finished one.
        try VMStore.save(stored, name: request.name)

        let configuration = try MacOSVMFactory.makeConfiguration(
            from: config,
            hardwareModelData: plan.hardwareModelData,
            machineIdentifier: identifier,
            storage: layout
        )

        // --- Install -------------------------------------------------------
        let runner = MacOSInstallerRunner(
            configuration: configuration,
            restoreImageFileURL: imageURL
        )
        try await runner.run { fraction in
            onEvent(.installing(fraction: fraction))
        }

        stored.installed = true
        try VMStore.save(stored, name: request.name)
        onEvent(.finished(stored))
        return stored
    }
}
