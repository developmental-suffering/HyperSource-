import Foundation

/// Downloads a large file to disk with progress, resuming an interrupted
/// transfer instead of starting over.
///
/// Apple's macOS restore images are ~15 GB, so two things matter:
/// bytes must be written to disk *as they arrive* (so progress is observable
/// and an interrupted run leaves something to resume from), and a truncated
/// transfer must never be promoted to the final file.
public enum ResumableDownloader {
    public struct Progress: Sendable {
        public let received: Int64
        public let total: Int64

        public var fraction: Double {
            total > 0 ? min(1, Double(received) / Double(total)) : 0
        }

        public var description: String {
            let receivedGiB = Double(received) / 1_073_741_824
            guard total > 0 else { return String(format: "%.2f GiB", receivedGiB) }
            let totalGiB = Double(total) / 1_073_741_824
            return String(format: "%.2f / %.2f GiB (%.1f%%)", receivedGiB, totalGiB, fraction * 100)
        }
    }

    public enum DownloadError: Error, CustomStringConvertible {
        case badStatus(Int)
        case incomplete(received: Int64, expected: Int64)
        case insecureScheme(String)
        case tooLarge(Int64)

        public var description: String {
            switch self {
            case .badStatus(let status):
                return "the server replied with HTTP \(status)"
            case .incomplete(let received, let expected):
                let got = Double(received) / 1_073_741_824
                let want = Double(expected) / 1_073_741_824
                return String(
                    format: "the transfer stopped early at %.2f of %.2f GiB; re-run to resume",
                    got, want
                )
            case .insecureScheme(let scheme):
                return "refusing to download over insecure scheme '\(scheme)'; only https is allowed"
            case .tooLarge(let cap):
                return "the server's image exceeds the \(cap / 1_073_741_824) GiB safety cap; refusing"
            }
        }
    }

    /// Safety cap: no guest image should exceed 64 GiB.
    public static let maximumDownloadBytes: Int64 = 64 * 1_073_741_824

    public static func download(
        from source: URL,
        to destination: URL,
        progress: (@Sendable (Progress) -> Void)? = nil
    ) async throws {
        guard source.scheme?.lowercased() == "https" else {
            throw DownloadError.insecureScheme(source.scheme ?? "(none)")
        }
        // Refuse symlinked destinations up front (TOCTOU hardening).
        if (try? FileManager.default.destinationOfSymbolicLink(atPath: destination.path)) != nil
            || (try? FileManager.default.destinationOfSymbolicLink(atPath: destination.appendingPathExtension("partial").path)) != nil {
            throw DownloadError.insecureScheme("symlink destination")
        }
        try FileManager.default.createDirectory(
            at: destination.deletingLastPathComponent(),
            withIntermediateDirectories: true
        )

        let partial = destination.appendingPathExtension("partial")
        var offset: Int64 = 0
        if let attributes = try? FileManager.default.attributesOfItem(atPath: partial.path),
           let size = attributes[.size] as? NSNumber {
            offset = size.int64Value
        }

        let delegate = DownloadDelegate(
            destination: destination,
            partial: partial,
            resumeOffset: offset,
            progress: progress
        )
        try await delegate.run(from: source)
    }
}

private final class DownloadDelegate: NSObject, URLSessionDataDelegate, @unchecked Sendable {
    private let destination: URL
    private let partial: URL
    private let resumeOffset: Int64
    private let progressHandler: (@Sendable (ResumableDownloader.Progress) -> Void)?

    private let lock = NSLock()
    private var continuation: CheckedContinuation<Void, Error>?
    private var session: URLSession?
    private var writer: FileHandle?
    private var received: Int64 = 0
    private var expectedTotal: Int64 = 0
    private var lastReportedFraction: Double = -1
    private var buffer = Data()
    private static let writeCoalesceBytes = 256 * 1024

    init(
        destination: URL,
        partial: URL,
        resumeOffset: Int64,
        progress: (@Sendable (ResumableDownloader.Progress) -> Void)?
    ) {
        self.destination = destination
        self.partial = partial
        self.resumeOffset = resumeOffset
        self.progressHandler = progress
        super.init()
    }

    func run(from url: URL) async throws {
        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            lock.lock()
            self.continuation = continuation
            lock.unlock()

            let configuration = URLSessionConfiguration.default
            configuration.timeoutIntervalForRequest = 60
            configuration.timeoutIntervalForResource = 60 * 60 * 6
            configuration.waitsForConnectivity = true

            let queue = OperationQueue()
            queue.maxConcurrentOperationCount = 1
            let session = URLSession(configuration: configuration, delegate: self, delegateQueue: queue)
            lock.lock()
            self.session = session
            lock.unlock()

            var request = URLRequest(url: url)
            if resumeOffset > 0 {
                request.setValue("bytes=\(resumeOffset)-", forHTTPHeaderField: "Range")
            }
            session.dataTask(with: request).resume()
        }
    }

    func urlSession(
        _ session: URLSession,
        dataTask: URLSessionDataTask,
        didReceive response: URLResponse,
        completionHandler: @escaping (URLSession.ResponseDisposition) -> Void
    ) {
        let status = (response as? HTTPURLResponse)?.statusCode ?? 0
        // Only a 206 means the server honoured our Range request. Anything else
        // (including a 200 that ignored it) must start from zero, or we would
        // splice the full file onto the partial one.
        let canAppend = status == 206 && resumeOffset > 0

        do {
            let handle: FileHandle
            if canAppend {
                handle = try FileHandle(forWritingTo: partial)
                try handle.seekToEnd()
            } else {
                if FileManager.default.fileExists(atPath: partial.path) {
                    try FileManager.default.removeItem(at: partial)
                }
                FileManager.default.createFile(atPath: partial.path, contents: nil)
                handle = try FileHandle(forWritingTo: partial)
            }

            let length = response.expectedContentLength
            let base = canAppend ? resumeOffset : 0

            lock.lock()
            writer = handle
            received = base
            expectedTotal = length > 0 ? base + length : 0
            lastReportedFraction = -1
            buffer.removeAll(keepingCapacity: true)
            lock.unlock()

            // Fail closed on absurd sizes before writing gigabytes.
            if expectedTotal > ResumableDownloader.maximumDownloadBytes {
                completionHandler(.cancel)
                finish(.failure(ResumableDownloader.DownloadError.tooLarge(ResumableDownloader.maximumDownloadBytes)))
                return
            }

            completionHandler(.allow)
        } catch {
            completionHandler(.cancel)
            finish(.failure(error))
        }
    }

    func urlSession(_ session: URLSession, dataTask: URLSessionDataTask, didReceive data: Data) {
        lock.lock()
        let handle = writer
        received += Int64(data.count)
        let overCap = received > ResumableDownloader.maximumDownloadBytes
        buffer.append(data)
        let shouldFlush = buffer.count >= Self.writeCoalesceBytes
        let chunk = shouldFlush ? buffer : Data()
        if shouldFlush { buffer.removeAll(keepingCapacity: true) }
        let snapshot = ResumableDownloader.Progress(received: received, total: expectedTotal)
        let shouldReport = snapshot.fraction - lastReportedFraction >= 0.005 || snapshot.fraction >= 1
        if shouldReport { lastReportedFraction = snapshot.fraction }
        lock.unlock()

        if overCap {
            // Cancel the task; didCompleteWithError will surface the error.
            dataTask.cancel()
            return
        }
        // Buffered to disk so an interrupted transfer can resume, without
        // paying a syscall per TCP segment.
        if !chunk.isEmpty {
            do { try handle?.write(contentsOf: chunk) }
            catch {
                dataTask.cancel()
                finish(.failure(error))
                return
            }
        }
        if shouldReport { progressHandler?(snapshot) }
    }

    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        lock.lock()
        let handle = writer
        writer = nil
        let got = received
        let want = expectedTotal
        let tail = buffer
        buffer.removeAll()
        lock.unlock()

        if !tail.isEmpty { try? handle?.write(contentsOf: tail) }
        try? handle?.close()

        if let error {
            finish(.failure(error))
            return
        }

        if got > ResumableDownloader.maximumDownloadBytes {
            finish(.failure(ResumableDownloader.DownloadError.tooLarge(ResumableDownloader.maximumDownloadBytes)))
            return
        }

        let status = (task.response as? HTTPURLResponse)?.statusCode ?? 0
        guard status == 200 || status == 206 else {
            finish(.failure(ResumableDownloader.DownloadError.badStatus(status)))
            return
        }
        // Never let a short transfer masquerade as a complete image.
        if want > 0 && got < want {
            finish(.failure(ResumableDownloader.DownloadError.incomplete(received: got, expected: want)))
            return
        }

        do {
            if FileManager.default.fileExists(atPath: destination.path) {
                try FileManager.default.removeItem(at: destination)
            }
            try FileManager.default.moveItem(at: partial, to: destination)
            finish(.success(()))
        } catch {
            finish(.failure(error))
        }
    }

    private func finish(_ result: Result<Void, Error>) {
        lock.lock()
        let continuation = self.continuation
        self.continuation = nil
        let session = self.session
        self.session = nil
        lock.unlock()

        session?.finishTasksAndInvalidate()
        continuation?.resume(with: result)
    }
}
