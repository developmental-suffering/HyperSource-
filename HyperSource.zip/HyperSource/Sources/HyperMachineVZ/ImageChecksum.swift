import CryptoKit
import Foundation

/// Verifies a downloaded guest image against the vendor's own checksum
/// manifest.
///
/// Downloading a 1 GB disk image and booting it is the largest trust decision
/// this project makes, so the manifest is fetched and checked rather than
/// trusted by convention. The manifest is deliberately not baked into the
/// source: upstream rebuilds images, and a pinned digest would either break the
/// install or have to be updated blindly.
public enum ImageChecksum {
    /// Digest algorithms vendors actually publish.
    ///
    /// Ubuntu ships `SHA256SUMS`, Debian ships `SHA512SUMS`, and the manifest
    /// filename is not a reliable way to tell them apart (some mirrors rename
    /// the file). The digest's own length is, so that is what selects the
    /// algorithm.
    public enum Algorithm: String, Sendable, CaseIterable {
        case sha256
        case sha512

        public var hexLength: Int {
            switch self {
            case .sha256: return 64
            case .sha512: return 128
            }
        }

        public var displayName: String {
            switch self {
            case .sha256: return "SHA-256"
            case .sha512: return "SHA-512"
            }
        }

        init?(hexLength: Int) {
            guard let match = Algorithm.allCases.first(where: { $0.hexLength == hexLength }) else {
                return nil
            }
            self = match
        }
    }

    public struct Verification: Sendable {
        public let filename: String
        public let expected: String
        public let actual: String
        public let algorithm: Algorithm

        public var matches: Bool {
            expected.compare(actual, options: .caseInsensitive) == .orderedSame
        }

        public var shortActual: String { String(actual.prefix(12)) }
    }

    public enum ChecksumError: Error, CustomStringConvertible {
        case manifestUnavailable(String)
        case entryMissing(String)
        case unsupportedDigest(filename: String, length: Int)
        case mismatch(filename: String, expected: String, actual: String)

        public var description: String {
            switch self {
            case .manifestUnavailable(let detail):
                return "could not fetch the checksum manifest: \(detail)"
            case .entryMissing(let filename):
                return "the vendor's checksum manifest has no entry for \(filename)"
            case .unsupportedDigest(let filename, let length):
                return """
                the manifest's digest for \(filename) is \(length) hex characters, which is \
                neither SHA-256 nor SHA-512, so it cannot be verified.
                """
            case .mismatch(let filename, let expected, let actual):
                return """
                \(filename) does not match the vendor's checksum. Expected \
                \(expected.prefix(16))…, got \(actual.prefix(16))…. The download is \
                corrupt or has been tampered with; it has been discarded.
                """
            }
        }
    }

    /// Fetch the manifest and check `file` against it.
    public static func verify(file: URL, against manifestURL: URL) async throws -> Verification {
        guard manifestURL.scheme?.lowercased() == "https" else {
            throw ChecksumError.manifestUnavailable("manifest URL must use https")
        }
        let manifest: String
        do {
            let (data, response) = try await URLSession.shared.data(from: manifestURL)
            let status = (response as? HTTPURLResponse)?.statusCode ?? 200
            guard status == 200 else {
                throw ChecksumError.manifestUnavailable("HTTP \(status)")
            }
            // 2 MiB cap: manifests are kilobytes; anything larger is abuse.
            guard data.count <= 2 * 1024 * 1024 else {
                throw ChecksumError.manifestUnavailable("manifest exceeds 2 MiB; refusing")
            }
            manifest = String(decoding: data, as: UTF8.self)
        } catch let error as ChecksumError {
            throw error
        } catch {
            throw ChecksumError.manifestUnavailable("\(error)")
        }

        let filename = file.lastPathComponent
        guard let expected = parse(manifest, filename: filename) else {
            throw ChecksumError.entryMissing(filename)
        }
        guard let algorithm = Algorithm(hexLength: expected.count) else {
            throw ChecksumError.unsupportedDigest(filename: filename, length: expected.count)
        }
        let actual = try digest(of: file, algorithm: algorithm)
        let verification = Verification(
            filename: filename,
            expected: expected,
            actual: actual,
            algorithm: algorithm
        )
        guard verification.matches else {
            throw ChecksumError.mismatch(
                filename: filename,
                expected: expected,
                actual: actual
            )
        }
        return verification
    }

    /// Find a filename in a checksum manifest.
    ///
    /// The two shapes in the wild are `<hash>  <name>` (shasum) and
    /// `<hash> *<name>` (binary mode). Anything else in the line is ignored.
    /// Names are normalized (./ stripped, subdir prefix kept) and hex digests
    /// must be pure hex, so a crafted manifest cannot smuggle entries.
    static func parse(_ manifest: String, filename: String) -> String? {
        for line in manifest.split(whereSeparator: \.isNewline) {
            let parts = line.split(whereSeparator: \.isWhitespace)
            guard parts.count >= 2 else { continue }
            var name = parts[parts.count - 1].drop { $0 == "*" }
            if name.hasPrefix("./") { name = name.dropFirst(2) }
            // Match basename too: some manifests list subdir/file.
            let candidate = String(name).split(separator: "/").last.map(String.init) ?? String(name)
            guard candidate == filename else { continue }
            let digest = String(parts[0]).lowercased()
            guard digest.allSatisfy({ $0.isHexDigit }) else { continue }
            return digest
        }
        return nil
    }

    /// SHA-256 of a file, read in chunks so a multi-gigabyte image does not have
    /// to fit in memory.
    public static func digest(of file: URL, chunkSize: Int = 4 * 1024 * 1024) throws -> String {
        try digest(of: file, algorithm: .sha256, chunkSize: chunkSize)
    }

    /// Digest of a file with the given algorithm, streamed so a multi-gigabyte
    /// image never has to fit in memory.
    public static func digest(
        of file: URL,
        algorithm: Algorithm,
        chunkSize: Int = 4 * 1024 * 1024
    ) throws -> String {
        let handle = try FileHandle(forReadingFrom: file)
        defer { try? handle.close() }

        var sha256 = SHA256()
        var sha512 = SHA512()
        while true {
            let chunk = try handle.read(upToCount: chunkSize) ?? Data()
            if chunk.isEmpty { break }
            switch algorithm {
            case .sha256: sha256.update(data: chunk)
            case .sha512: sha512.update(data: chunk)
            }
        }
        let digest: [UInt8] = switch algorithm {
        case .sha256: Array(sha256.finalize())
        case .sha512: Array(sha512.finalize())
        }
        return digest.map { String(format: "%02x", $0) }.joined()
    }
}
