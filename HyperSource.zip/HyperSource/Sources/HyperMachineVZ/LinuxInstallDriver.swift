import Foundation
import HyperMachineCore

/// Everything needed to create a Linux VM, independent of who is asking.
public struct LinuxInstallRequest: Sendable {
    public var name: String
    public var entry: GuestCatalogEntry
    public var cpuCount: Int
    public var cpuPlacement: CorePlacementPolicy
    public var memoryGiB: Double
    public var diskGiB: UInt64
    public var network: NetworkConfig
    public var shares: [ShareConfig]
    public var display: DisplayConfig
    public var security: SecurityConfig
    public var rosettaEnabled: Bool
    public var serialConsoleLogging: Bool
    /// Required for the `installerISO` path: the image the user picked.
    public var localImageURL: URL?
    /// Account the unattended first boot should create. `nil` uses defaults.
    public var cloudInit: CloudInitConfig?

    public init(
        name: String,
        entry: GuestCatalogEntry,
        cpuCount: Int = 2,
        cpuPlacement: CorePlacementPolicy = .balanced,
        memoryGiB: Double = 4,
        diskGiB: UInt64 = 32,
        network: NetworkConfig = NetworkConfig(),
        shares: [ShareConfig] = [],
        display: DisplayConfig = DisplayConfig(),
        security: SecurityConfig = SecurityConfig(),
        rosettaEnabled: Bool = false,
        serialConsoleLogging: Bool = true,
        localImageURL: URL? = nil,
        cloudInit: CloudInitConfig? = nil
    ) {
        self.name = name
        self.entry = entry
        self.cpuCount = cpuCount
        self.cpuPlacement = cpuPlacement
        self.memoryGiB = memoryGiB
        self.diskGiB = diskGiB
        self.network = network
        self.shares = shares
        self.display = display
        self.security = security
        self.rosettaEnabled = rosettaEnabled
        self.serialConsoleLogging = serialConsoleLogging
        self.localImageURL = localImageURL
        self.cloudInit = cloudInit
    }
}

public enum LinuxInstallEvent: Sendable {
    case resolvingImage(String)
    case usingCachedImage(URL)
    case downloading(fraction: Double, received: Int64, total: Int64)
    case downloaded(bytes: Int64)
    case verifyingChecksum(String)
    case checksumVerified(String)
    case checksumUnavailable(String)
    /// Looking at the image's own bytes to find out what it really is.
    case inspectingImage(String)
    case imageInspected(String)
    /// Flattening a qcow2 container into an attachable raw disk.
    case convertingImage(fraction: Double, written: Int64, total: Int64)
    case copyingImage(URL)
    case imageReady(String)
    case writingSeed(URL)
    case preparingStorage(URL)
    case finished(StoredVM)
}

/// Creates a Linux VM from a catalog entry.
///
/// Two shapes, because they are genuinely different:
///
/// - **Cloud image** — download a prebuilt disk image, verify it against the
///   vendor's checksum manifest, make sure it is actually attachable (flattening
///   a qcow2 container if that is what it turns out to be), clone it into place,
///   and attach a cloud-init seed. There is no installer to sit through.
/// - **Installer ISO** — create an empty disk and attach the ISO as read-only
///   media. The firmware boots it and a human completes the installation.
public enum LinuxInstallDriver {
    /// Mount tag of the folder used for the boot handshake. Keeping the tag in
    /// one place means the seed and the device cannot disagree.
    public static let handshakeTag = "hypermachine"
    public static let handshakeFilename = "boot-ok"
    public static let handshakeFolderName = "Shared"

    public enum InstallError: Error, CustomStringConvertible {
        case localImageRequired(String)
        case localImageMissing(String)
        /// The file downloaded, verified and then turned out not to be a disk
        /// image we can attach.
        case unusableImage(filename: String, detail: String)
        /// The disk was created but firmware would find no boot loader on it.
        case imageNotBootable(filename: String, analysis: [String])

        public var description: String {
            switch self {
            case .localImageRequired(let name):
                return "\(name) needs an image file on disk. Choose the ISO in the app, or pass --iso <path>."
            case .localImageMissing(let path):
                return "no file at \(path)."
            case .unusableImage(let filename, let detail):
                return "\(filename) is not a usable disk image: \(detail)"
            case .imageNotBootable(let filename, let analysis):
                return """
                \(filename) downloaded and verified, but the disk it produced has no bootable \
                EFI system partition, so the guest would start and stop immediately. \
                Detail: \(analysis.joined(separator: "; ")).
                """
            }
        }
    }

    /// - Note: Main actor, because the event callback renders into UI. The
    ///   download itself is awaited, not blocking the actor.
    @MainActor
    public static func create(
        _ request: LinuxInstallRequest,
        onEvent: @escaping @MainActor (LinuxInstallEvent) -> Void = { _ in }
    ) async throws -> StoredVM {
        guard VMStore.isValidName(request.name) else {
            throw VMStoreError.invalidName(request.name)
        }

        let layout = try VMStore.layout(for: request.name)
        try layout.prepare()

        var config = request.entry.makeConfig(
            named: request.name,
            capabilities: HostCapabilities.current()
        )
        config.cpu = CPUConfig(count: request.cpuCount, placement: request.cpuPlacement)
        config.memory = MemoryConfig(gibibytes: request.memoryGiB)
        config.network = request.network
        config.display = request.display
        config.security = request.security
        config.rosettaEnabled = request.rosettaEnabled
        config.serialConsoleLogging = request.serialConsoleLogging
        config.shares = request.shares

        let diskBytes = request.diskGiB * 1_073_741_824
        var disks: [DiskConfig] = []
        var installedFrom: InstalledFrom

        switch request.entry.installKind {
        case .appleRestoreImage:
            throw VMStoreError.invalidName(
                "\(request.name) is a macOS entry; the macOS installer handles it."
            )

        case .cloudImage:
            guard let remote = request.entry.imageURL else {
                throw InstallError.localImageRequired(request.entry.name)
            }

            let filename = remote.lastPathComponent
            let cached = VMStore.linuxImageURL(filename: filename)
            onEvent(.resolvingImage(remote.absoluteString))

            if VMStore.cachedLinuxImage(filename: filename) != nil {
                onEvent(.usingCachedImage(cached))
            } else {
                try await ResumableDownloader.download(from: remote, to: cached) { progress in
                    let event = LinuxInstallEvent.downloading(
                        fraction: progress.fraction,
                        received: progress.received,
                        total: progress.total
                    )
                    Task { @MainActor in onEvent(event) }
                }
                let attributes = try? FileManager.default.attributesOfItem(atPath: cached.path)
                let bytes = (attributes?[.size] as? NSNumber)?.int64Value ?? 0
                onEvent(.downloaded(bytes: bytes))
            }

            // Trust, then verify.
            if let manifest = request.entry.checksumManifestURL {
                onEvent(.verifyingChecksum(manifest.absoluteString))
                do {
                    let verification = try await ImageChecksum.verify(file: cached, against: manifest)
                    onEvent(.checksumVerified(verification.shortActual))
                } catch let error as ImageChecksum.ChecksumError {
                    // A corrupt image must not be left in the cache to be
                    // reused on the next attempt.
                    if case .mismatch = error {
                        try? FileManager.default.removeItem(at: cached)
                    }
                    throw error
                }
            } else {
                onEvent(.checksumUnavailable("\(filename) has no vendor checksum manifest"))
            }

            // The file extension is not evidence. Ask the bytes.
            onEvent(.inspectingImage(filename))
            let probe = try DiskImageInspector.probe(cached)
            onEvent(.imageInspected(probe.analysis.joined(separator: "; ")))

            switch probe.format {
            case .raw:
                onEvent(.copyingImage(layout.disk))
                if FileManager.default.fileExists(atPath: layout.disk.path) {
                    try FileManager.default.removeItem(at: layout.disk)
                }
                // On APFS this is a copy-on-write clone, so it costs nothing
                // until the guest writes; elsewhere it is a plain copy.
                try FileManager.default.copyItem(at: cached, to: layout.disk)

            case .qcow2:
                // Common enough to be the normal case: Ubuntu publishes qcow2
                // for arm64. Flatten it rather than refusing.
                onEvent(.convertingImage(
                    fraction: 0,
                    written: 0,
                    total: Int64(probe.effectiveSizeBytes)
                ))
                do {
                    try QCOW2Converter.convert(from: cached, to: layout.disk) { update in
                        let event = LinuxInstallEvent.convertingImage(
                            fraction: update.fraction,
                            written: update.writtenBytes,
                            total: update.totalBytes
                        )
                        Task { @MainActor in onEvent(event) }
                    }
                } catch {
                    // A half-written disk must never be left looking installed.
                    try? FileManager.default.removeItem(at: layout.disk)
                    throw InstallError.unusableImage(
                        filename: filename,
                        detail: "\(error)"
                    )
                }

            case .unknown:
                try? FileManager.default.removeItem(at: layout.disk)
                throw InstallError.unusableImage(
                    filename: filename,
                    detail: probe.analysis.joined(separator: "; ")
                )
            }

            // Saving a VM whose disk cannot boot wastes the user's time twice:
            // once to install it and again to find out why nothing happened.
            let installed = try DiskImageInspector.probe(layout.disk)
            guard installed.isBootable else {
                let analysis = installed.analysis
                try? FileManager.default.removeItem(at: layout.disk)
                throw InstallError.imageNotBootable(filename: filename, analysis: analysis)
            }
            onEvent(.imageReady(
                String(
                    format: "bootable: EFI system partition %.0f MiB, disk %.0f GiB",
                    // Both arguments must be Double: a UInt64 in a %f slot reads
                    // from the wrong register on arm64 and prints zero.
                    Double(installed.efiSystemPartition?.sizeBytes ?? 0) / 1_048_576,
                    Double(installed.effectiveSizeBytes) / 1_073_741_824
                )
            ))

            try VMStore.resizeDisk(at: layout.disk, to: diskBytes)

            var seed = request.cloudInit
                ?? CloudInitConfig(hostname: request.name, username: "hyper")
            seed.hostname = request.name
            // A writable folder the guest writes its handshake marker into.
            // Giving the guest somewhere to report back is the only way to tell
            // an unattended boot that worked from one that hung.
            let handshakeFolder = layout.root.appendingPathComponent(
                handshakeFolderName,
                isDirectory: true
            )
            try FileManager.default.createDirectory(
                at: handshakeFolder,
                withIntermediateDirectories: true
            )
            seed.handshakeMountTag = handshakeTag
            seed.handshakeFile = handshakeFilename

            onEvent(.writingSeed(layout.cloudInitSeed))
            try CloudInitSeed.makeSeedISO(at: layout.cloudInitSeed, config: seed)
            // Harden the seed file itself (contains plaintext password).
            try? FileManager.default.setAttributes([.posixPermissions: 0o600], ofItemAtPath: layout.cloudInitSeed.path)

            // Refuse tag collision: a user share already named "hypermachine"
            // would silently hijack the handshake.
            if config.shares.contains(where: { $0.name == handshakeTag }) {
                throw InstallError.unusableImage(
                    filename: filename,
                    detail: "a shared folder already uses the reserved mount tag '\(handshakeTag)'; rename it"
                )
            }
            // Lockdown installs cannot use a writable handshake share: report
            // instead of silently breaking isolation.
            if config.security.lockdown {
                throw InstallError.unusableImage(
                    filename: filename,
                    detail: "lockdown is on, so the unattended boot handshake (writable share) is unavailable; turn lockdown off for install"
                )
            }
            config.shares.append(
                ShareConfig(name: handshakeTag, hostPath: handshakeFolder.path, readOnly: false)
            )

            disks = [
                DiskConfig(
                    path: layout.disk.path,
                    sizeBytes: diskBytes,
                    format: .raw,
                    isBootVolume: true
                ),
                DiskConfig(
                    path: layout.cloudInitSeed.path,
                    sizeBytes: (try? FileManager.default
                        .attributesOfItem(atPath: layout.cloudInitSeed.path)[.size] as? NSNumber)?
                        .uint64Value ?? 0,
                    format: .raw,
                    isBootVolume: false,
                    readOnly: true,
                    isInstallMedia: true
                )
            ]
            installedFrom = InstalledFrom(
                catalogID: request.entry.id,
                catalogName: request.entry.name,
                imageURL: remote.absoluteString,
                build: filename
            )

        case .installerISO:
            guard let iso = request.localImageURL ?? request.entry.imageURL else {
                throw InstallError.localImageRequired(request.entry.name)
            }
            guard FileManager.default.fileExists(atPath: iso.path) else {
                throw InstallError.localImageMissing(iso.path)
            }

            onEvent(.preparingStorage(layout.root))
            try VMStore.createSizedDisk(at: layout.disk, sizeBytes: diskBytes)
            let mediaBytes = (try? FileManager.default
                .attributesOfItem(atPath: iso.path)[.size] as? NSNumber)?.uint64Value ?? 0

            disks = [
                DiskConfig(
                    path: layout.disk.path,
                    sizeBytes: diskBytes,
                    format: .raw,
                    isBootVolume: true
                ),
                DiskConfig(
                    path: iso.path,
                    sizeBytes: mediaBytes,
                    format: .raw,
                    isBootVolume: false,
                    readOnly: true,
                    isInstallMedia: true
                )
            ]
            installedFrom = InstalledFrom(
                catalogID: request.entry.id,
                catalogName: request.entry.name,
                imageURL: iso.path,
                build: iso.lastPathComponent
            )
        }

        config.disks = disks
        onEvent(.preparingStorage(layout.root))

        // A config the engine cannot build must not be written to disk as if it
        // were fine, so the framework gets the last word before anything is saved.
        let stored = StoredVM(
            config: config,
            installedFrom: installedFrom,
            installed: true
        )
        do {
            _ = try VMFactory.makeConfiguration(from: stored, storage: layout)
        } catch let error as VMBuildError {
            throw error
        }

        try VMStore.save(stored, name: request.name)
        onEvent(.finished(stored))
        return stored
    }
}
