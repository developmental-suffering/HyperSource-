import Foundation
import Virtualization
import HyperMachineCore

public enum MacOSVMBuildError: Error, CustomStringConvertible {
    case noBootVolume
    case unsupportedHardwareModel
    case invalidConfiguration(underlying: String)

    public var description: String {
        switch self {
        case .noBootVolume:
            return "The configuration has no disk marked as the boot volume."
        case .unsupportedHardwareModel:
            return """
            The stored hardware model is not supported by this Mac. It must be the model \
            that was used to create this VM's auxiliary storage.
            """
        case .invalidConfiguration(let underlying):
            return "Virtualization.framework rejected the configuration: \(underlying)"
        }
    }
}

/// Bridges the engine-agnostic `VMConfig` onto Virtualization.framework.
///
/// Everything here is macOS-specific: a Linux guest needs a different platform,
/// boot loader and graphics device, which is why this lives in its own module.
public enum MacOSVMFactory {
    /// Where a VM keeps its mutable state on the host. An alias rather than a
    /// second type: macOS and Linux VMs share one directory layout, and a fork
    /// here would only mean two things to keep in sync.
    public typealias StorageLayout = VMLayout

    /// Load the persisted machine identifier, or mint one on first run.
    ///
    /// Apple requires a unique identifier per VM; reusing one across
    /// concurrently running VMs is not supported.
    public static func loadOrCreateMachineIdentifier(at url: URL) throws -> VZMacMachineIdentifier {
        if let data = try? Data(contentsOf: url),
           let identifier = VZMacMachineIdentifier(dataRepresentation: data) {
            return identifier
        }
        let identifier = VZMacMachineIdentifier()
        try identifier.dataRepresentation.write(to: url, options: .atomic)
        return identifier
    }

    /// Create the auxiliary storage a macOS VM needs alongside its boot disk.
    public static func createAuxiliaryStorage(
        at url: URL,
        hardwareModelData: Data,
        overwrite: Bool = false
    ) throws -> VZMacAuxiliaryStorage {
        guard let hardwareModel = VZMacHardwareModel(dataRepresentation: hardwareModelData),
              hardwareModel.isSupported else {
            throw MacOSVMBuildError.unsupportedHardwareModel
        }
        if overwrite {
            try? FileManager.default.removeItem(at: url)
        }
        return try VZMacAuxiliaryStorage(
            creatingStorageAt: url,
            hardwareModel: hardwareModel,
            options: []
        )
    }

    private static func hardwareModel(from data: Data) throws -> VZMacHardwareModel {
        guard let model = VZMacHardwareModel(dataRepresentation: data), model.isSupported else {
            throw MacOSVMBuildError.unsupportedHardwareModel
        }
        return model
    }

    public static func makeConfiguration(
        from stored: VMConfig,
        hardwareModelData: Data,
        machineIdentifier: VZMacMachineIdentifier,
        storage: StorageLayout
    ) throws -> VZVirtualMachineConfiguration {
        // Hardened here too, so lockdown means the same thing on both engines.
        let config = SecurityPolicy.effective(stored)
        let hardwareModel = try hardwareModel(from: hardwareModelData)

        let platform = VZMacPlatformConfiguration()
        platform.hardwareModel = hardwareModel
        platform.machineIdentifier = machineIdentifier
        platform.auxiliaryStorage = VZMacAuxiliaryStorage(url: storage.auxiliaryStorage)

        let configuration = VZVirtualMachineConfiguration()
        configuration.platform = platform
        configuration.bootLoader = VZMacOSBootLoader()
        configuration.cpuCount = config.cpu.count
        configuration.memorySize = config.memory.bytes

        // --- Display -------------------------------------------------------
        // The Mac graphics device is the Metal-backed one, so there is no
        // unaccelerated fallback to substitute: turning acceleration off means
        // running headless. Linux guests would use
        // VZVirtioGraphicsDeviceConfiguration here instead.
        if config.display.gpuAcceleration {
            let graphics = VZMacGraphicsDeviceConfiguration()
            graphics.displays = [
                VZMacGraphicsDisplayConfiguration(
                    widthInPixels: config.display.widthPixels,
                    heightInPixels: config.display.heightPixels,
                    pixelsPerInch: config.display.pixelsPerInch
                )
            ]
            configuration.graphicsDevices = [graphics]
        }

        // --- Storage -------------------------------------------------------
        // Each disk honours its own read-only flag. Deriving it from
        // "is it the boot volume" made every extra disk silently read-only,
        // which is not what a data disk is for.
        let attachments = try config.disks.map { disk -> VZVirtioBlockDeviceConfiguration in
            guard let url = DeviceBuilders.safeDiskURL(disk.path) else {
                throw MacOSVMBuildError.invalidConfiguration(underlying: "unsafe disk path: \(disk.path)")
            }
            let attachment = try VZDiskImageStorageDeviceAttachment(
                url: url,
                readOnly: disk.isInstallMedia ? true : disk.readOnly
            )
            return VZVirtioBlockDeviceConfiguration(attachment: attachment)
        }
        guard !attachments.isEmpty else { throw MacOSVMBuildError.noBootVolume }
        configuration.storageDevices = attachments

        // --- Networking ----------------------------------------------------
        // Empty for an isolated guest: no virtio-net device is created at all.
        configuration.networkDevices = try DeviceBuilders.networkDevices(from: config.network)

        // --- Entropy -------------------------------------------------------
        // A macOS guest that cannot seed its CSPRNG stalls during boot.
        configuration.entropyDevices = [VZVirtioEntropyDeviceConfiguration()]

        // --- Shared folders (requirement #5) -------------------------------
        if !config.shares.isEmpty {
            var directories: [String: VZSharedDirectory] = [:]
            for share in config.shares {
                guard let dir = DeviceBuilders.safeHostDirectory(share.hostPath) else {
                    throw MacOSVMBuildError.invalidConfiguration(underlying: "unsafe share path: \(share.hostPath)")
                }
                directories[share.name] = VZSharedDirectory(url: dir, readOnly: share.readOnly)
            }
            // macOS guests mount automatically, but only under Apple's reserved
            // tag: a custom tag would never be auto-mounted by the guest.
            let fileSystem = VZVirtioFileSystemDeviceConfiguration(
                tag: VZVirtioFileSystemDeviceConfiguration.macOSGuestAutomountTag
            )
            fileSystem.share = VZMultipleDirectoryShare(directories: directories)
            configuration.directorySharingDevices = [fileSystem]
        }

        // --- Input ---------------------------------------------------------
        // VZVirtualMachineView forwards input *only* through devices that are
        // actually configured. `pointingDevices` defaults to empty, and with it
        // empty the view has nothing to deliver pointer events to: the guest
        // cursor never moves, no matter how the host handles the mouse. A Mac
        // trackpad is the Mac-guest pointing device (macOS 13+, which the
        // restore image already requires).
        configuration.pointingDevices = [VZMacTrackpadConfiguration()]
        // Likewise, a Mac keyboard is what the view sends keys through.
        configuration.keyboards = [VZMacKeyboardConfiguration()]

        do {
            try configuration.validate()
        } catch {
            throw MacOSVMBuildError.invalidConfiguration(underlying: "\(error)")
        }
        return configuration
    }
}

/// Runs Apple's installer and reports progress, so the UI can show a real bar
/// instead of an indefinite spinner.
@MainActor
public final class MacOSInstallerRunner {
    private let installer: VZMacOSInstaller

    public init(configuration: VZVirtualMachineConfiguration, restoreImageFileURL: URL) {
        let machine = VZVirtualMachine(configuration: configuration)
        self.installer = VZMacOSInstaller(
            virtualMachine: machine,
            restoringFromImageAt: restoreImageFileURL
        )
    }

    /// - Parameter progress: receives 0...1. Delivered on the main actor, since
    ///   both callers render it into UI.
    public func run(progress: @escaping @MainActor @Sendable (Double) -> Void) async throws {
        // NSProgress's KVO change handler does not survive Swift 6 sendability
        // checking, and the installer only ever reports one fraction, so poll
        // it on a side task instead of observing it.
        let poller = Task { @MainActor in
            while !Task.isCancelled {
                progress(self.installer.progress.fractionCompleted)
                do {
                    try await Task.sleep(nanoseconds: 200_000_000)
                } catch {
                    return
                }
            }
        }
        defer { poller.cancel() }

        try await installer.install()
        progress(1.0)
    }
}
