import Foundation
import Virtualization
import HyperMachineCore

/// The host's real virtualization budget, as reported by
/// Virtualization.framework rather than estimated from sysctl.
///
/// `HostCapabilities.current()` is a conservative pre-flight guess used before
/// anything else exists. Once the engine is loaded, these are the values the
/// framework will actually enforce on `validate()`.
public enum VZCapabilities {
    public static func current() -> HostCapabilities {
        var capabilities = HostCapabilities.current()
        capabilities.minimumCPUCount = VZVirtualMachineConfiguration.minimumAllowedCPUCount
        capabilities.maximumCPUCount = VZVirtualMachineConfiguration.maximumAllowedCPUCount
        capabilities.minimumMemoryBytes = VZVirtualMachineConfiguration.minimumAllowedMemorySize
        capabilities.maximumMemoryBytes = VZVirtualMachineConfiguration.maximumAllowedMemorySize
        return capabilities
    }

    public static var minimumAllowedCPUCount: Int {
        VZVirtualMachineConfiguration.minimumAllowedCPUCount
    }

    public static var maximumAllowedCPUCount: Int {
        VZVirtualMachineConfiguration.maximumAllowedCPUCount
    }

    public static var minimumAllowedMemorySize: UInt64 {
        VZVirtualMachineConfiguration.minimumAllowedMemorySize
    }

    public static var maximumAllowedMemorySize: UInt64 {
        VZVirtualMachineConfiguration.maximumAllowedMemorySize
    }
}
