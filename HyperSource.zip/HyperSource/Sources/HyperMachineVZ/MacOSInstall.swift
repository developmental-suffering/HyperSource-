import Foundation
import Virtualization

/// Everything Apple's restore image tells us about installing macOS.
///
/// Only value types cross the boundary here: the `VZMacOSRestoreImage` and its
/// hardware model are `NSObject`s owned by the framework and must not escape.
public struct MacOSInstallPlan: Sendable {
    /// Network URL of the restore image. It must be downloaded to a local file
    /// before `VZMacOSInstaller` will accept it.
    public let restoreImageURL: URL
    public let buildVersion: String
    public let operatingSystemVersion: String
    /// Serialised `VZMacHardwareModel`. Persist this: it must be identical to
    /// the model used to create the VM's auxiliary storage, on every launch.
    public let hardwareModelData: Data
    /// Floor imposed by the restore image, on top of the framework's own range.
    public let minimumSupportedCPUCount: Int
    public let minimumSupportedMemorySize: UInt64
    /// How many hardware models the image offers; more than one means we had to
    /// choose, and the choice must be stored with the VM.
    public let supportedConfigurationCount: Int

    public var minimumMemoryGiB: Double {
        Double(minimumSupportedMemorySize) / 1_073_741_824
    }
}

public enum MacOSInstallError: Error, CustomStringConvertible {
    /// The image exists but this Mac cannot boot it.
    case notSupportedOnHost(buildVersion: String)
    /// The image advertised no usable configuration.
    case noSupportedConfiguration
    /// Nothing has been signed with com.apple.security.virtualization.
    case entitlementMissing(underlying: String)
    case framework(status: Int, message: String)

    public var description: String {
        switch self {
        case .notSupportedOnHost(let build):
            return "Restore image \(build) is not supported on this Mac's hardware model."
        case .noSupportedConfiguration:
            return "The restore image lists no configuration this host can run."
        case .entitlementMissing(let underlying):
            return """
            Virtualization.framework refused the request, which almost always means the \
            binary is not signed with the com.apple.security.virtualization entitlement: \
            \(underlying)
            """
        case .framework(let status, let message):
            return "Virtualization.framework error \(status): \(message)"
        }
    }
}

/// Fetches the newest macOS Apple will let this Mac virtualise.
public enum MacOSInstallPlanner {
    /// - Note: Requires the `com.apple.security.virtualization` entitlement.
    ///   Apple documents this on `VZMacOSRestoreImage` itself: even *loading* a
    ///   restore image is gated, so this call fails on an unsigned binary.
    public static func latestSupported() async throws -> MacOSInstallPlan {
        let image: VZMacOSRestoreImage
        do {
            image = try await VZMacOSRestoreImage.latestSupported
        } catch {
            throw translate(error)
        }

        guard image.isSupported else {
            throw MacOSInstallError.notSupportedOnHost(buildVersion: image.buildVersion)
        }
        guard let requirements = image.mostFeaturefulSupportedConfiguration else {
            throw MacOSInstallError.noSupportedConfiguration
        }

        let version = image.operatingSystemVersion
        return MacOSInstallPlan(
            restoreImageURL: image.url,
            buildVersion: image.buildVersion,
            operatingSystemVersion: "\(version.majorVersion).\(version.minorVersion).\(version.patchVersion)",
            hardwareModelData: requirements.hardwareModel.dataRepresentation,
            minimumSupportedCPUCount: requirements.minimumSupportedCPUCount,
            minimumSupportedMemorySize: requirements.minimumSupportedMemorySize,
            supportedConfigurationCount: 1
        )
    }

    /// Turn a framework failure into something a human can act on.
    static func translate(_ error: Error) -> MacOSInstallError {
        let nsError = error as NSError
        // VZErrorDomain code for a missing entitlement is reported as a generic
        // internal error, so the message is the only reliable signal.
        if nsError.domain == VZErrorDomain || nsError.domain.contains("VZError") {
            let message = nsError.localizedDescription
            // Loading the restore-image catalog fails as a generic "internal"
            // error when the entitlement check rejects the process, so the
            // message is the only reliable signal that it is a signing problem.
            let signingProblem = message.localizedCaseInsensitiveContains("entitlement")
                || message.localizedCaseInsensitiveContains("not permitted")
                || nsError.code == VZError.internalError.rawValue
                || nsError.code == VZError.restoreImageCatalogLoadFailed.rawValue
            if signingProblem {
                return .entitlementMissing(underlying: message)
            }
            return .framework(status: nsError.code, message: message)
        }
        return .entitlementMissing(underlying: "\(nsError.domain) \(nsError.code): \(nsError.localizedDescription)")
    }
}
