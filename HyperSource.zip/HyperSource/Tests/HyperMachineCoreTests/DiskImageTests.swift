import Foundation
import Testing
@testable import HyperMachineCore

// MARK: - Fixtures

/// Builds a small but structurally real disk image in a temporary file.
///
/// Every field the inspector looks at is written the way a real disk writes it,
/// including the two different byte orders involved: GPT is little-endian, a
/// qcow2 header is big-endian.
struct DiskImageFixture {
    var efiPartitionMiB: Int = 8
    var includeGPT = true
    var includeEFISystemPartition = true
    var fatBootSector = true

    static let sectorSize = 512
    static let espStartLBA: UInt64 = 2048

    func data() -> Data {
        let sector = DiskImageFixture.sectorSize
        let espSectors = efiPartitionMiB * 1024 * 1024 / sector
        var bytes = Data(count: Int((DiskImageFixture.espStartLBA + UInt64(espSectors) + 8) * UInt64(sector)))

        // Protective MBR: one 0xEE partition, and the boot signature.
        bytes[450] = 0xEE
        writeLE32(&bytes, 454, 1)
        writeLE32(&bytes, 460, UInt32(bytes.count / sector - 1))
        writeLE16(&bytes, 510, 0xAA55)

        guard includeGPT else { return bytes }

        // GPT header at LBA 1.
        let header = sector
        bytes.replaceSubrange(header..<(header + 8), with: Data("EFI PART".utf8))
        writeLE32(&bytes, header + 8, 0x0001_0000)      // revision 1.0
        writeLE32(&bytes, header + 12, 92)              // header size
        writeLE64(&bytes, header + 24, 1)               // my LBA
        writeLE64(&bytes, header + 32, UInt64(bytes.count / sector - 1))  // alternate LBA
        writeLE64(&bytes, header + 40, 34)              // first usable LBA
        writeLE64(&bytes, header + 72, 2)               // partition entry array LBA
        writeLE32(&bytes, header + 80, 128)             // entry count
        writeLE32(&bytes, header + 84, 128)             // entry size

        guard includeEFISystemPartition else { return bytes }

        // Partition entry array at LBA 2, entry 0.
        let entry = 2 * sector
        bytes.replaceSubrange(entry..<(entry + 16), with: Data(DiskImageInspector.efiSystemPartitionType))
        writeLE64(&bytes, entry + 32, DiskImageFixture.espStartLBA)
        writeLE64(&bytes, entry + 40, DiskImageFixture.espStartLBA + UInt64(espSectors) - 1)

        if fatBootSector {
            let esp = Int(DiskImageFixture.espStartLBA) * sector
            // A FAT32 boot sector: sensible geometry, an FS type, and 0x55AA.
            writeLE16(&bytes, esp + 11, 512)   // bytes per sector
            bytes[esp + 13] = 8                // sectors per cluster
            writeLE16(&bytes, esp + 14, 32)    // reserved sectors
            bytes[esp + 16] = 2                // FAT count
            bytes.replaceSubrange((esp + 82)..<(esp + 90), with: Data("FAT32   ".utf8))
            writeLE16(&bytes, esp + 510, 0xAA55)
        }

        return bytes
    }

    func write(to url: URL) throws {
        try data().write(to: url)
    }
}

private func writeLE16(_ data: inout Data, _ offset: Int, _ value: UInt16) {
    data[offset] = UInt8(value & 0xFF)
    data[offset + 1] = UInt8((value >> 8) & 0xFF)
}

private func writeLE32(_ data: inout Data, _ offset: Int, _ value: UInt32) {
    for index in 0..<4 {
        data[offset + index] = UInt8((value >> (8 * UInt32(index))) & 0xFF)
    }
}

private func writeLE64(_ data: inout Data, _ offset: Int, _ value: UInt64) {
    for index in 0..<8 {
        data[offset + index] = UInt8((value >> (8 * UInt64(index))) & 0xFF)
    }
}

/// The 104-byte header of a real image: Ubuntu 24.04 minimal arm64, read from
/// the file the project actually downloads. Kept as a fixture because the
/// interesting fields (size, cluster size, features) are easy to get subtly
/// wrong and impossible to notice.
private func qcow2HeaderFixture() -> Data {
    func be32(_ value: UInt32) -> [UInt8] {
        (0..<4).map { UInt8((value >> (8 * UInt32(3 - $0))) & 0xFF) }
    }
    func be64(_ value: UInt64) -> [UInt8] {
        (0..<8).map { UInt8((value >> (8 * UInt64(7 - $0))) & 0xFF) }
    }

    var bytes: [UInt8] = []
    bytes += [0x51, 0x46, 0x49, 0xFB]           // magic
    bytes += be32(3)                            // version
    bytes += be64(0)                            // backing file offset
    bytes += be32(0)                            // backing file size
    bytes += be32(16)                           // cluster bits
    bytes += be64(3_758_096_384)                // virtual size
    bytes += be32(0)                            // crypt method
    bytes += be32(7)                            // L1 entries
    bytes += be64(0x0003_0000)                  // L1 table offset
    bytes += be64(0x0002_0000)                  // refcount table offset
    bytes += be32(1)                            // refcount table clusters
    bytes += be32(0)                            // snapshots
    bytes += be64(0)                            // snapshots offset
    bytes += be64(0)                            // incompatible features
    bytes += be64(0)                            // compatible features
    bytes += be64(0)                            // autoclear features
    bytes += be32(4)                            // refcount order
    bytes += be32(112)                          // header length
    return Data(bytes)
}

private func temporaryImage(_ data: Data) throws -> URL {
    let url = URL(fileURLWithPath: NSTemporaryDirectory())
        .appendingPathComponent("hyper-machine-image-\(UUID().uuidString).img")
    try data.write(to: url)
    return url
}

// MARK: - Tests

@Suite("Disk image inspection")
struct DiskImageInspectorTests {
    @Test("a real GPT disk with an EFI system partition is reported as bootable")
    func bootableImageIsRecognised() throws {
        let url = try temporaryImage(DiskImageFixture().data())
        defer { try? FileManager.default.removeItem(at: url) }

        let probe = try DiskImageInspector.probe(url)

        #expect(probe.format == .raw)
        #expect(probe.format.isDirectlyAttachable)
        #expect(probe.hasProtectiveMBR)
        #expect(probe.hasGPT)
        #expect(probe.isBootable)
        #expect(probe.efiSystemPartition?.startOffset == DiskImageFixture.espStartLBA * 512)
        #expect(probe.efiSystemPartition?.hasFATBootSector == true)
        #expect(probe.efiSystemPartition?.sizeBytes == 8 * 1024 * 1024)
        #expect(probe.effectiveSizeBytes == probe.fileSizeBytes)
    }

    @Test("an ESP without a FAT boot sector is not bootable")
    func espWithoutFATBootSectorIsNotBootable() throws {
        let url = try temporaryImage(DiskImageFixture(fatBootSector: false).data())
        defer { try? FileManager.default.removeItem(at: url) }

        let probe = try DiskImageInspector.probe(url)

        #expect(probe.hasGPT)
        #expect(probe.efiSystemPartition != nil)
        #expect(probe.efiSystemPartition?.hasFATBootSector == false)
        #expect(!probe.isBootable)
    }

    @Test("a GPT disk with no EFI system partition is not bootable")
    func gptWithoutESPIsNotBootable() throws {
        let url = try temporaryImage(DiskImageFixture(includeEFISystemPartition: false).data())
        defer { try? FileManager.default.removeItem(at: url) }

        let probe = try DiskImageInspector.probe(url)

        #expect(probe.hasGPT)
        #expect(probe.efiSystemPartition == nil)
        #expect(!probe.isBootable)
        #expect(probe.analysis.contains { $0.contains("no EFI system partition") })
    }

    @Test("an unpartitioned file is not a bootable disk")
    func unpartitionedFileIsNotBootable() throws {
        let url = try temporaryImage(Data(count: 1024 * 1024))
        defer { try? FileManager.default.removeItem(at: url) }

        let probe = try DiskImageInspector.probe(url)

        #expect(probe.format == .raw)
        #expect(!probe.hasGPT)
        #expect(!probe.isBootable)
    }

    @Test("a file smaller than a sector cannot be a disk")
    func tinyFileIsNotADisk() throws {
        let url = try temporaryImage(Data(count: 16))
        defer { try? FileManager.default.removeItem(at: url) }

        let probe = try DiskImageInspector.probe(url)

        #expect(!probe.hasGPT)
        #expect(!probe.isBootable)
    }
}

@Suite("qcow2 header")
struct QCOW2HeaderTests {
    @Test("a real header decodes with big-endian fields")
    func realHeaderDecodes() throws {
        let header = try #require(QCOW2Header(data: qcow2HeaderFixture()))

        #expect(header.version == 3)
        #expect(header.clusterBits == 16)
        #expect(header.clusterSize == 65_536)
        #expect(header.virtualSizeBytes == 3_758_096_384)
        #expect(header.l1TableEntries == 7)
        #expect(header.l1TableOffset == 0x0003_0000)
        #expect(!header.hasBackingFile)
        #expect(!header.isEncrypted)
        // Byte order matters: read as little-endian, these become 50331648 and
        // 268435456.
        #expect(header.version != 50_331_648)
    }

    @Test("a qcow2 file is detected by its magic, not its extension")
    func qcow2IsDetectedByMagic() throws {
        var image = qcow2HeaderFixture()
        image.append(Data(count: 4096))
        let url = try temporaryImage(image)
        defer { try? FileManager.default.removeItem(at: url) }

        let probe = try DiskImageInspector.probe(url)

        #expect(probe.format == .qcow2)
        #expect(!probe.format.isDirectlyAttachable)
        #expect(probe.virtualSizeBytes == 3_758_096_384)
        #expect(!probe.isBootable)
        #expect(probe.analysis.contains { $0.contains("not a flat disk image") })
    }

    @Test("unimplemented features are recognised")
    func incompatibleFeaturesAreRecognised() {
        var bytes = qcow2HeaderFixture()
        // external data file, plus zstd-compressed clusters
        bytes[72 + 7] = 0b0000_1100
        let header = QCOW2Header(data: bytes)

        #expect(header?.has(.externalDataFile) == true)
        #expect(header?.has(.zstdCompression) == true)
        #expect(header?.has(.extendedL2Entries) == false)
    }

    @Test("a truncated or non-qcow2 file has no header")
    func junkHasNoHeader() {
        #expect(QCOW2Header(data: Data(count: 8)) == nil)
        #expect(QCOW2Header(data: Data(count: 200)) == nil)
    }
}

@Suite("GPT byte order")
struct GPTEndiannessTests {
    @Test("GPT is little-endian while qcow2 is big-endian")
    func theTwoByteOrdersAreKeptApart() {
        let bytes = Data([0x00, 0x00, 0x00, 0x10, 0x00, 0x00, 0x00, 0x03])

        #expect(DiskImageInspector.leU32(bytes, 0) == 0x1000_0000)
        #expect(DiskImageInspector.beU32(bytes, 0) == 16)
        #expect(DiskImageInspector.leU64(bytes, 0) == 0x0300_0000_1000_0000)
        #expect(DiskImageInspector.beU64(bytes, 0) == 0x0000_0010_0000_0003)
    }

    @Test("reads past the end of the buffer return zero rather than trapping")
    func shortReadsAreSafe() {
        let bytes = Data([0x01, 0x02])
        #expect(DiskImageInspector.leU16(bytes, 0) == 0x0201)
        #expect(DiskImageInspector.leU16(bytes, 1) == 0)
        #expect(DiskImageInspector.leU32(bytes, 0) == 0)
        #expect(DiskImageInspector.beU64(bytes, 0) == 0)
    }
}
