import Foundation
import Testing
@testable import HyperMachineCore

private func secured(
    network: NetworkConfig = NetworkConfig(),
    shares: [ShareConfig] = [],
    rosetta: Bool = false,
    security: SecurityConfig = .default
) -> VMConfig {
    VMConfig(
        name: "isolated",
        guest: .linux,
        bootMethod: .efi,
        cpu: CPUConfig(count: 2),
        memory: MemoryConfig(gibibytes: 4),
        disks: [DiskConfig(path: "/tmp/disk.raw", sizeBytes: 16 * 1_073_741_824, isBootVolume: true)],
        network: network,
        shares: shares,
        security: security,
        rosettaEnabled: rosetta
    ).normalized(for: testHostCapabilities)
}

/// Mirrors the reference machine: M1 Pro, 8 P + 2 E, 32 GB.
private let testHostCapabilities = HostCapabilities(
    performanceCores: 8,
    efficiencyCores: 2,
    physicalMemoryBytes: 32 * 1_073_741_824,
    maximumCPUCount: 8,
    minimumMemoryBytes: 1 * 1_073_741_824,
    maximumMemoryBytes: 28 * 1_073_741_824,
    supportsNestedVirtualization: false
)

@Suite("Network modes")
struct NetworkModeTests {
    @Test("only NAT and bridged reach beyond the machine")
    func onlyNATAndBridgedReach() {
        #expect(NetworkMode.nat.allowsInternet)
        #expect(NetworkMode.bridged.allowsInternet)
        #expect(!NetworkMode.isolated.allowsInternet)
    }

    @Test("isolated is the only air-gapped mode")
    func onlyIsolatedIsAirGapped() {
        #expect(NetworkMode.isolated.isAirGapped)
        #expect(!NetworkMode.nat.isAirGapped)
        #expect(!NetworkMode.bridged.isAirGapped)
    }

    @Test("an isolated guest is a valid configuration with no networking warnings")
    func isolatedIsValid() {
        let config = secured(network: NetworkConfig(mode: .isolated))
        #expect(config.errors(against: testHostCapabilities).isEmpty)
        #expect(!config.validate(against: testHostCapabilities).contains { $0.field == "network.mode" })
    }

    @Test("an older config with no network mode still decodes")
    func networkModeStillDecodes() throws {
        let json = #"{"mode":"nat"}"#
        let config = try JSONDecoder().decode(NetworkConfig.self, from: Data(json.utf8))
        #expect(config.mode == .nat)
        #expect(config.bridgedInterface == nil)
    }
}

@Suite("Lockdown")
struct LockdownTests {
    @Test("lockdown forces isolation, read-only shares and every host interface off")
    func lockdownForcesTheSealedPosture() {
        let loose = secured(
            network: NetworkConfig(mode: .bridged, bridgedInterface: "en0"),
            shares: [
                ShareConfig(name: "work", hostPath: "/tmp/work", readOnly: false),
                ShareConfig(name: "docs", hostPath: "/tmp/docs", readOnly: true)
            ],
            rosetta: true,
            security: SecurityConfig(
                clipboardSharing: true,
                usbPassthrough: true,
                allowBridgedNetworking: true,
                lockdown: true
            )
        )

        // As written it is wide open; as built it is sealed by the policy.
        #expect(!SecurityPolicy.isSealedAsWritten(loose))
        #expect(SecurityPolicy.isFullySealed(loose))

        let hardened = SecurityPolicy.effective(loose)

        #expect(hardened.network.mode == .isolated)
        #expect(hardened.network.bridgedInterface == nil)
        // An explicit closure rather than a key path: `#expect` rethrows through
        // the call, and a key path argument trips that analysis.
        #expect(hardened.shares.allSatisfy { $0.readOnly })
        #expect(!hardened.security.clipboardSharing)
        #expect(!hardened.security.usbPassthrough)
        #expect(!hardened.security.allowBridgedNetworking)
        #expect(!hardened.rosettaEnabled)
        #expect(hardened.security.lockdown)
        #expect(SecurityPolicy.isSealedAsWritten(hardened))
    }

    @Test("each override is reported with the field it applies to")
    func everyOverrideIsReported() {
        let loose = secured(
            network: NetworkConfig(mode: .nat),
            shares: [ShareConfig(name: "work", hostPath: "/tmp/work", readOnly: false)],
            rosetta: true,
            security: SecurityConfig(clipboardSharing: true, lockdown: true)
        )

        let fields = Set(SecurityPolicy.enforcements(for: loose).map(\.field))
        #expect(fields.contains("network.mode"))
        #expect(fields.contains("shares.readOnly"))
        #expect(fields.contains("security.clipboardSharing"))
        #expect(fields.contains("rosettaEnabled"))
        // Nothing to say about settings that are already off.
        #expect(!fields.contains("security.usbPassthrough"))
    }

    @Test("a compliant configuration produces no overrides")
    func compliantConfigurationHasNothingToOverride() {
        let sealed = secured(
            network: NetworkConfig(mode: .isolated),
            shares: [ShareConfig(name: "work", hostPath: "/tmp/work", readOnly: true)],
            security: SecurityConfig(lockdown: true)
        )
        #expect(SecurityPolicy.enforcements(for: sealed).isEmpty)
        #expect(SecurityPolicy.isFullySealed(sealed))
        #expect(SecurityPolicy.isSealedAsWritten(sealed))
    }

    @Test("lockdown leaves Secure Boot to the user")
    func lockdownDoesNotForceSecureBoot() {
        // Forcing it on would let the posture break a guest that boots unsigned
        // code, which is a surprising way for a security switch to behave.
        let on = secured(security: SecurityConfig(efiSecureBoot: true, lockdown: true))
        let off = secured(security: SecurityConfig(efiSecureBoot: false, lockdown: true))
        #expect(SecurityPolicy.effective(on).security.efiSecureBoot)
        #expect(!SecurityPolicy.effective(off).security.efiSecureBoot)
    }

    @Test("lockdown is reported as a warning, not an error, so the VM still builds")
    func lockdownContradictionsWarn() {
        let loose = secured(
            network: NetworkConfig(mode: .nat),
            security: SecurityConfig(allowBridgedNetworking: true, lockdown: true)
        )
        let issues = loose.validate(against: testHostCapabilities)
        #expect(issues.contains { $0.field == "security.lockdown" && $0.severity == .warning })
        #expect(loose.errors(against: testHostCapabilities).isEmpty)
    }

    @Test("lockdown is off by default")
    func lockdownIsOffByDefault() {
        #expect(!SecurityConfig.default.lockdown)
        #expect(!secured().security.lockdown)
    }

    @Test("configs written before lockdown existed still decode")
    func olderConfigsDecode() throws {
        let json = #"{"clipboardSharing":false,"usbPassthrough":false,"allowBridgedNetworking":false}"#
        let config = try JSONDecoder().decode(SecurityConfig.self, from: Data(json.utf8))
        #expect(!config.lockdown)
        #expect(!config.efiSecureBoot)
    }
}

@Suite("Exposure audit")
struct ExposureAuditTests {
    @Test("an isolated guest with read-only shares exposes nothing open")
    func sealedGuestHasNoOpenExposure() {
        let config = secured(
            network: NetworkConfig(mode: .isolated),
            shares: [ShareConfig(name: "work", hostPath: "/tmp/work", readOnly: true)]
        )
        #expect(!SecurityPolicy.exposures(of: config).contains { $0.level == .open })
        #expect(SecurityPolicy.exposures(of: config).allSatisfy { $0.level != .open })
    }

    @Test("a writable share is reported as open, and as a two-way door")
    func writableShareIsOpen() {
        let config = secured(
            network: NetworkConfig(mode: .isolated),
            shares: [ShareConfig(name: "work", hostPath: "/tmp/work", readOnly: false)]
        )
        let shares = SecurityPolicy.exposures(of: config).first { $0.area == "Shared folders" }
        #expect(shares?.level == .open)

        // Isolation is about the network and must not be described as though it
        // also protected the host's files.
        let issues = config.validate(against: testHostCapabilities)
        #expect(issues.contains { $0.message.contains("air-gapped") })
    }

    @Test("NAT is limited, bridged is open, isolated is sealed")
    func networkLevelsMatchTheModes() {
        func level(_ mode: NetworkMode) -> SecurityPolicy.HostExposure.Level? {
            SecurityPolicy.exposures(of: secured(network: NetworkConfig(mode: mode)))
                .first { $0.area == "Network" }?.level
        }
        #expect(level(.isolated) == SecurityPolicy.HostExposure.Level.sealed)
        #expect(level(.nat) == SecurityPolicy.HostExposure.Level.limited)
        #expect(level(.bridged) == SecurityPolicy.HostExposure.Level.open)
    }

    @Test("the audit names every area, so nothing is silently absent")
    func everyAreaIsReported() {
        let areas = Set(SecurityPolicy.exposures(of: secured()).map(\.area))
        #expect(areas == [
            "Network", "Shared folders", "Clipboard", "USB devices",
            "Rosetta for Linux", "Serial console", "EFI Secure Boot"
        ])
    }
}
