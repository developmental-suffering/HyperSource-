import Foundation
import Testing
@testable import HyperMachineCore

/// Mirrors the reference machine: M1 Pro, 8 P-cores + 2 E-cores, 32 GB.
private let testHost = HostCapabilities(
    performanceCores: 8,
    efficiencyCores: 2,
    physicalMemoryBytes: 32 * 1_073_741_824,
    maximumCPUCount: 8,
    minimumMemoryBytes: 1 * 1_073_741_824,
    maximumMemoryBytes: 28 * 1_073_741_824,
    supportsNestedVirtualization: false
)

private func makeConfig(
    guest: GuestKind = .linux,
    cpu: CPUConfig = CPUConfig(count: 4),
    memoryGiB: Double = 4,
    bootMethod: BootMethod = .efi,
    disks: [DiskConfig] = [DiskConfig(path: "Disks/vm.raw", sizeBytes: 32 * 1_073_741_824, isBootVolume: true)],
    network: NetworkConfig = NetworkConfig(),
    shares: [ShareConfig] = [],
    display: DisplayConfig = DisplayConfig(),
    security: SecurityConfig = .default
) -> VMConfig {
    VMConfig(
        name: "test-vm",
        guest: guest,
        bootMethod: bootMethod,
        cpu: cpu,
        memory: MemoryConfig(gibibytes: memoryGiB),
        disks: disks,
        network: network,
        shares: shares,
        display: display,
        security: security
    )
}

@Suite("CPU configuration")
struct CPUValidationTests {
    @Test("zero vCPUs is rejected")
    func zeroCPUsIsRejected() {
        let issues = makeConfig(cpu: CPUConfig(count: 0)).errors(against: testHost)
        #expect(issues.count == 1)
        #expect(issues.first?.field == "cpu.count")
    }

    @Test("more vCPUs than the host allows is rejected")
    func tooManyCPUsIsRejected() {
        let issues = makeConfig(cpu: CPUConfig(count: 10)).errors(against: testHost)
        #expect(issues.first?.field == "cpu.count")
    }

    @Test("exactly the host maximum is allowed")
    func exactlyTheMaximumIsAllowed() {
        // 8 = every performance core, the host's default ceiling.
        #expect(makeConfig(cpu: CPUConfig(count: 8)).isRunnable(against: testHost))
    }

    @Test("a placement policy is surfaced as a hint, not a guarantee")
    func placementIsReportedAsAHint() {
        let issues = makeConfig(cpu: CPUConfig(count: 4, placement: .performancePreferred))
            .validate(against: testHost)
        #expect(issues.contains { $0.field == "cpu.placement" && $0.severity == .warning })
        let placementWarning = issues.first { $0.field == "cpu.placement" }
        #expect(placementWarning?.message.contains("no CPU pinning") == true)
    }

    @Test("efficiency placement wider than the E-cores warns")
    func efficiencyPlacementLargerThanECoreCountWarns() {
        // 4 vCPUs cannot live on this host's 2 efficiency cores.
        let issues = makeConfig(cpu: CPUConfig(count: 4, placement: .efficiencyPreferred))
            .validate(against: testHost)
        #expect(issues.contains { $0.severity == .warning && $0.message.contains("efficiency cores") })
    }

    @Test("balanced placement produces no placement warning")
    func balancedPlacementProducesNoWarning() {
        let issues = makeConfig(cpu: CPUConfig(count: 4, placement: .balanced))
            .validate(against: testHost)
        #expect(!issues.contains { $0.field == "cpu.placement" })
    }
}

@Suite("Memory configuration")
struct MemoryValidationTests {
    @Test("below the minimum is rejected")
    func belowMinimumIsRejected() {
        let issues = makeConfig(memoryGiB: 0.5).errors(against: testHost)
        #expect(issues.first?.field == "memory.bytes")
    }

    @Test("above the host limit is rejected")
    func aboveHostLimitIsRejected() {
        let issues = makeConfig(memoryGiB: 31).errors(against: testHost)
        #expect(issues.first?.field == "memory.bytes")
    }

    @Test("the host memory reserve is enforced")
    func hostReserveIsEnforced() {
        // 28 of 32 GiB is the ceiling; 29 must fail.
        #expect(makeConfig(memoryGiB: 28).isRunnable(against: testHost))
        #expect(!makeConfig(memoryGiB: 29).isRunnable(against: testHost))
    }
}

@Suite("Boot method")
struct BootMethodTests {
    @Test("macOS with a restore image is valid")
    func macOSWithRestoreImageIsValid() {
        #expect(makeConfig(guest: .macOS, memoryGiB: 8, bootMethod: .macRestore).isRunnable(against: testHost))
    }

    @Test("macOS with EFI boot is rejected")
    func macOSWithEFIBootIsRejected() {
        let issues = makeConfig(guest: .macOS, memoryGiB: 8, bootMethod: .efi).errors(against: testHost)
        #expect(issues.first?.field == "bootMethod")
    }

    @Test("Linux with a restore image is rejected")
    func linuxWithRestoreImageIsRejected() {
        let issues = makeConfig(guest: .linux, bootMethod: .macRestore).errors(against: testHost)
        #expect(issues.first?.field == "bootMethod")
    }
}

@Suite("Storage")
struct DiskValidationTests {
    @Test("no disks is rejected")
    func noDisksIsRejected() {
        #expect(makeConfig(disks: []).errors(against: testHost).contains { $0.field == "disks" })
    }

    @Test("no boot volume is rejected")
    func noBootVolumeIsRejected() {
        let disks = [DiskConfig(path: "Disks/data.raw", sizeBytes: 32 * 1_073_741_824)]
        let issues = makeConfig(disks: disks).errors(against: testHost)
        #expect(issues.contains { $0.message.contains("boot volume") })
    }

    @Test("two boot volumes is rejected")
    func twoBootVolumesIsRejected() {
        let disks = [
            DiskConfig(path: "a.raw", sizeBytes: 32 * 1_073_741_824, isBootVolume: true),
            DiskConfig(path: "b.raw", sizeBytes: 32 * 1_073_741_824, isBootVolume: true)
        ]
        let issues = makeConfig(disks: disks).errors(against: testHost)
        #expect(issues.contains { $0.message.contains("More than one") })
    }

    @Test("a very small boot volume warns")
    func smallBootVolumeWarns() {
        let disks = [DiskConfig(path: "a.raw", sizeBytes: 4 * 1_073_741_824, isBootVolume: true)]
        let issues = makeConfig(disks: disks).validate(against: testHost)
        #expect(issues.contains { $0.severity == .warning && $0.field == "disks" })
    }
}

@Suite("Networking")
struct NetworkValidationTests {
    @Test("bridged without the opt-in is rejected")
    func bridgedWithoutOptInIsRejected() {
        let config = makeConfig(network: NetworkConfig(mode: .bridged, bridgedInterface: "en0"))
        #expect(config.errors(against: testHost).contains { $0.field == "network.mode" })
    }

    @Test("bridged with the opt-in and an interface is valid")
    func bridgedWithOptInIsValid() {
        let config = makeConfig(
            network: NetworkConfig(mode: .bridged, bridgedInterface: "en0"),
            security: SecurityConfig(allowBridgedNetworking: true)
        )
        #expect(config.isRunnable(against: testHost))
    }

    @Test("bridged without an interface is rejected")
    func bridgedWithoutInterfaceIsRejected() {
        let config = makeConfig(
            network: NetworkConfig(mode: .bridged, bridgedInterface: nil),
            security: SecurityConfig(allowBridgedNetworking: true)
        )
        #expect(config.errors(against: testHost).contains { $0.field == "network.bridgedInterface" })
    }

    @Test("NAT is the default and is valid")
    func natIsTheDefault() {
        #expect(NetworkConfig().mode == .nat)
        #expect(makeConfig().isRunnable(against: testHost))
    }
}

@Suite("Shared folders")
struct ShareValidationTests {
    @Test("duplicate mount tags are rejected")
    func duplicateTagsAreRejected() {
        let shares = [
            ShareConfig(name: "work", hostPath: "/tmp/one"),
            ShareConfig(name: "work", hostPath: "/tmp/two")
        ]
        #expect(makeConfig(shares: shares).errors(against: testHost).contains { $0.field == "shares.name" })
    }

    @Test("duplicate host paths are rejected")
    func duplicatePathsAreRejected() {
        let shares = [
            ShareConfig(name: "one", hostPath: "/tmp/same"),
            ShareConfig(name: "two", hostPath: "/tmp/same")
        ]
        #expect(makeConfig(shares: shares).errors(against: testHost).contains { $0.field == "shares.hostPath" })
    }

    @Test("an invalid mount tag is rejected")
    func invalidMountTagIsRejected() {
        let issues = makeConfig(shares: [ShareConfig(name: "my folder", hostPath: "/tmp/x")])
            .errors(against: testHost)
        #expect(issues.contains { $0.field == "shares.name" })
    }

    @Test("mount tag validity rules")
    func mountTagRules() {
        #expect(ShareConfig(name: "work-files", hostPath: "/tmp/x").isValidMountTag)
        #expect(!ShareConfig(name: "a/b", hostPath: "/tmp/x").isValidMountTag)
        #expect(!ShareConfig(name: "", hostPath: "/tmp/x").isValidMountTag)
    }

    @Test("a writable share warns")
    func writableShareWarns() {
        let issues = makeConfig(shares: [ShareConfig(name: "work", hostPath: "/tmp/x", readOnly: false)])
            .validate(against: testHost)
        #expect(issues.contains { $0.severity == .warning && $0.field == "shares.readOnly" })
    }

    @Test("a read-only share does not warn")
    func readOnlyShareDoesNotWarn() {
        let issues = makeConfig(shares: [ShareConfig(name: "work", hostPath: "/tmp/x", readOnly: true)])
            .validate(against: testHost)
        #expect(!issues.contains { $0.field == "shares.readOnly" })
    }

    @Test("shares are read-only by default")
    func sharesDefaultToReadOnly() {
        #expect(ShareConfig(name: "x", hostPath: "/tmp/x").readOnly)
    }
}

@Suite("Display and GPU")
struct DisplayValidationTests {
    @Test("a tiny display is rejected")
    func tinyDisplayIsRejected() {
        let display = DisplayConfig(widthPixels: 320, heightPixels: 240)
        #expect(makeConfig(display: display).errors(against: testHost).contains { $0.field == "display" })
    }

    @Test("GPU acceleration warns for Linux guests")
    func gpuAccelerationWarnsForLinux() {
        let issues = makeConfig(guest: .linux, display: DisplayConfig(gpuAcceleration: true))
            .validate(against: testHost)
        #expect(issues.contains { $0.field == "display.gpuAcceleration" && $0.severity == .warning })
    }

    @Test("GPU acceleration does not warn for macOS guests")
    func gpuAccelerationDoesNotWarnForMacOS() {
        let issues = makeConfig(
            guest: .macOS,
            memoryGiB: 8,
            bootMethod: .macRestore,
            display: DisplayConfig(gpuAcceleration: true)
        ).validate(against: testHost)
        #expect(!issues.contains { $0.field == "display.gpuAcceleration" })
    }
}

@Suite("Normalization")
struct NormalizationTests {
    @Test("an oversized config is clamped into range")
    func oversizedConfigIsClamped() {
        let huge = VMConfig(
            name: "imported",
            guest: .linux,
            bootMethod: .efi,
            cpu: CPUConfig(count: 64),
            memory: MemoryConfig(gibibytes: 512),
            disks: [DiskConfig(path: "a.raw", sizeBytes: 32 * 1_073_741_824, isBootVolume: true)]
        ).normalized(for: testHost)

        #expect(huge.cpu.count == 8)
        #expect(huge.memory.bytes == 28 * 1_073_741_824)
        #expect(huge.isRunnable(against: testHost))
    }

    @Test("an undersized config is clamped up")
    func undersizedConfigIsClamped() {
        let tiny = VMConfig(
            name: "tiny",
            guest: .linux,
            bootMethod: .efi,
            cpu: CPUConfig(count: 0),
            memory: MemoryConfig(bytes: 1024),
            disks: [DiskConfig(path: "a.raw", sizeBytes: 32 * 1_073_741_824, isBootVolume: true)],
            display: DisplayConfig(widthPixels: 1, heightPixels: 1)
        ).normalized(for: testHost)

        #expect(tiny.cpu.count == 1)
        #expect(tiny.memory.bytes == 1 * 1_073_741_824)
        #expect(tiny.display.widthPixels == 640)
        #expect(tiny.isRunnable(against: testHost))
    }

    @Test("normalization promotes a disk to boot volume")
    func normalizationPromotesABootVolume() {
        let config = VMConfig(
            name: "no-boot",
            guest: .linux,
            bootMethod: .efi,
            cpu: CPUConfig(count: 2),
            memory: MemoryConfig(gibibytes: 4),
            disks: [DiskConfig(path: "a.raw", sizeBytes: 32 * 1_073_741_824, isBootVolume: false)]
        ).normalized(for: testHost)

        #expect(config.disks[0].isBootVolume)
        #expect(config.isRunnable(against: testHost))
    }

    @Test("a recommended config is always runnable", arguments: GuestKind.allCases)
    func recommendedConfigIsRunnable(guest: GuestKind) {
        let config = VMConfig.recommended(named: "new", guest: guest, capabilities: testHost)
        #expect(config.isRunnable(against: testHost))
    }
}

@Suite("Persistence")
struct PersistenceTests {
    @Test("a config round-trips through JSON")
    func configRoundTripsThroughJSON() throws {
        let original = makeConfig(
            guest: .macOS,
            memoryGiB: 8,
            bootMethod: .macRestore,
            shares: [ShareConfig(name: "work", hostPath: "/Users/stas/Work", readOnly: false)]
        )
        let data = try JSONEncoder().encode(original)
        let decoded = try JSONDecoder().decode(VMConfig.self, from: data)
        #expect(decoded == original)
    }
}

@Suite("Guest catalog")
struct GuestCatalogTests {
    @Test("identifiers are unique and image URLs are well-formed")
    func identifiersAndURLsAreSane() {
        let ids = GuestCatalog.all.map(\.id)
        #expect(ids.count == Set(ids).count)
        for entry in GuestCatalog.all where entry.imageURL != nil {
            #expect(entry.imageURL?.scheme != nil)
        }
    }

    @Test("boot method matches the guest family")
    func bootMethodMatchesGuestFamily() {
        for entry in GuestCatalog.all {
            switch entry.guest {
            case .macOS:
                #expect(entry.bootMethod == .macRestore, "\(entry.id)")
            case .linux, .windows:
                #expect(entry.bootMethod != .macRestore, "\(entry.id)")
            }
        }
    }

    @Test("only the macOS entry can use an accelerated display")
    func onlyMacOSOffersGPUAcceleration() {
        for entry in GuestCatalog.all {
            let config = entry.makeConfig(named: "catalog", capabilities: testHost)
            #expect(!(config.display.gpuAcceleration && entry.guest != .macOS), "\(entry.id)")
        }
    }

    @Test("every catalog entry produces a runnable config on this host")
    func catalogConfigsAreRunnable() {
        for entry in GuestCatalog.all {
            let config = entry.makeConfig(named: "catalog", capabilities: testHost)
            let problems = config.errors(against: testHost).map(\.message)
            #expect(config.isRunnable(against: testHost), "\(entry.id): \(problems)")
        }
    }

    @Test("lookup helpers")
    func lookupHelpers() {
        let ubuntu = GuestCatalog.entry(id: "ubuntu-24.04-cloud-arm64")
        #expect(ubuntu?.guest == .linux)
        #expect(ubuntu?.installKind == .cloudImage)
        #expect(ubuntu?.imageURL != nil)
        // A cloud image is only worth downloading if it can be verified.
        #expect(ubuntu?.checksumManifestURL != nil)
        #expect(GuestCatalog.entry(id: "nope") == nil)
        #expect(GuestCatalog.entries(for: .macOS).count == 1)
    }

    @Test("ISO entries name a download page instead of a pinned filename")
    func isoEntriesAreResolvable() {
        for entry in GuestCatalog.all where entry.installKind == .installerISO {
            #expect(entry.requiresLocalImage, "\(entry.id)")
            #expect(entry.downloadPageURL != nil, "\(entry.id) has nowhere to send the user")
        }
    }

    @Test("an installer ISO is attached read-only and is never the boot volume")
    func installerMediaIsReadOnly() {
        var config = VMConfig.recommended(named: "iso", guest: .linux, capabilities: testHost)
        config.disks = [
            DiskConfig(path: "/tmp/disk.raw", sizeBytes: 32 * 1_073_741_824, isBootVolume: true),
            DiskConfig(
                path: "/tmp/installer.iso",
                sizeBytes: 1_073_741_824,
                isBootVolume: true,
                readOnly: false,
                isInstallMedia: true
            )
        ]
        let normalized = config.normalized(for: testHost)

        #expect(normalized.disks.count == 2)
        #expect(normalized.disks[0].isBootVolume)
        // The ISO claimed both roles; normalization has to take the boot flag
        // away rather than leave two boot volumes behind.
        #expect(!normalized.disks[1].isBootVolume)
        #expect(normalized.disks[1].readOnly)
        #expect(normalized.errors(against: testHost).isEmpty)
    }

    @Test("a data disk honours its own read-only flag")
    func dataDiskReadOnlyIsIndependent() {
        let writable = DiskConfig(path: "/tmp/data.raw", sizeBytes: 1_073_741_824, readOnly: false)
        let locked = DiskConfig(path: "/tmp/other.raw", sizeBytes: 1_073_741_824, readOnly: true)
        #expect(!writable.readOnly)
        #expect(locked.readOnly)
        #expect(writable.kind == "data disk")
        #expect(locked.kind == "read-only disk")
    }

    @Test("Linux-only switches are rejected on a macOS guest")
    func linuxSwitchesAreGuestSpecific() {
        var mac = VMConfig.recommended(named: "m", guest: .macOS, capabilities: testHost)
        mac.bootMethod = .macRestore
        mac.rosettaEnabled = true
        #expect(mac.errors(against: testHost).contains { $0.field == "rosettaEnabled" })

        var macSecureBoot = mac
        macSecureBoot.rosettaEnabled = false
        macSecureBoot.security.efiSecureBoot = true
        #expect(macSecureBoot.errors(against: testHost).contains { $0.field == "security.efiSecureBoot" })
    }

    @Test("direct kernel boot is refused until it is implemented")
    func kernelBootIsRefused() {
        var config = VMConfig.recommended(named: "k", guest: .linux, capabilities: testHost)
        config.bootMethod = .kernel
        #expect(config.errors(against: testHost).contains { $0.field == "bootMethod" })
    }

    @Test("an unimplemented disk format says so instead of pretending")
    func encryptedDiskWarns() {
        var config = VMConfig.recommended(named: "e", guest: .linux, capabilities: testHost)
        if let index = config.disks.indices.first {
            config.disks[index].format = .encryptedSparseImage
        }
        let warnings = config.validate(against: testHost)
        #expect(warnings.contains { $0.field == "disks.format" && $0.severity == .warning })
        // A warning, not an error: the VM still runs, just not encrypted.
        #expect(config.isRunnable(against: testHost))
    }

    @Test("configs written before the newer fields still decode")
    func olderConfigsStillDecode() throws {
        // Exactly the shape an earlier version of this project wrote: no
        // rosettaEnabled, no serialConsoleLogging, no readOnly on disks, and a
        // security block without efiSecureBoot.
        let json = """
        {
          "id": "FB236F6A-784D-44AA-962A-FDAC3BE7D507",
          "name": "macOS",
          "guest": "macOS",
          "bootMethod": "macRestore",
          "cpu": { "count": 4, "placement": "performancePreferred" },
          "memory": { "bytes": 8589934592 },
          "disks": [
            { "id": "E550C708-DE84-46CB-AB19-D8CC1A85823E", "path": "/tmp/disk.raw",
              "sizeBytes": 68719476736, "format": "raw", "isBootVolume": true }
          ],
          "network": { "mode": "nat" },
          "shares": [],
          "display": { "gpuAcceleration": true, "heightPixels": 1080,
                       "pixelsPerInch": 80, "widthPixels": 1920 },
          "security": { "allowBridgedNetworking": false, "clipboardSharing": false,
                        "usbPassthrough": false }
        }
        """
        let config = try JSONDecoder().decode(VMConfig.self, from: Data(json.utf8))

        #expect(config.cpu.count == 4)
        #expect(!config.rosettaEnabled)
        #expect(!config.serialConsoleLogging)
        #expect(!config.security.efiSecureBoot)
        #expect(!config.disks[0].readOnly)
        #expect(!config.disks[0].isInstallMedia)
        #expect(config.disks[0].kind == "boot volume")
    }
}

@Suite("Host capabilities")
struct HostCapabilitiesTests {
    @Test("chip generation parsing")
    func chipGenerationParsing() {
        #expect(HostCapabilities.chipGeneration(brand: "Apple M1 Pro") == 1)
        #expect(HostCapabilities.chipGeneration(brand: "Apple M3 Max") == 3)
        #expect(HostCapabilities.chipGeneration(brand: "Apple M4") == 4)
        #expect(HostCapabilities.chipGeneration(brand: "Intel(R) Core(TM) i9") == nil)
        #expect(HostCapabilities.chipGeneration(brand: "Apple") == nil)
    }

    @Test("nested virtualization requires M3 or newer")
    func nestedVirtualizationRequiresM3() {
        func supports(_ brand: String) -> Bool {
            HostCapabilities(
                performanceCores: 8, efficiencyCores: 2,
                physicalMemoryBytes: 16 * 1_073_741_824,
                maximumMemoryBytes: 12 * 1_073_741_824,
                supportsNestedVirtualization: (HostCapabilities.chipGeneration(brand: brand) ?? 0) >= 3
            ).supportsNestedVirtualization
        }
        #expect(!supports("Apple M1 Pro"))
        #expect(!supports("Apple M2 Max"))
        #expect(supports("Apple M3 Max"))
    }

    @Test("the default CPU ceiling leaves efficiency cores to the host")
    func defaultCeilingExcludesEfficiencyCores() {
        let caps = HostCapabilities(
            performanceCores: 8, efficiencyCores: 2,
            physicalMemoryBytes: 32 * 1_073_741_824,
            maximumMemoryBytes: 28 * 1_073_741_824,
            supportsNestedVirtualization: false
        )
        #expect(caps.maximumCPUCount == 8)
        #expect(caps.totalCoreCount == 10)
    }

    @Test("the current host can actually be read")
    func currentHostIsReadable() {
        let caps = HostCapabilities.current()
        #expect(caps.performanceCores >= 1)
        #expect(caps.physicalMemoryBytes > 0)
        #expect(caps.maximumCPUCount > 0)
        // Guests must never be allowed to consume the whole machine.
        #expect(caps.maximumMemoryBytes < caps.physicalMemoryBytes)
    }
}
