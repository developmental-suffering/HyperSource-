import Compression
import CryptoKit
import Foundation
import Testing
@testable import HyperMachineCore
@testable import HyperMachineVZ

// MARK: - A synthetic qcow2 image

/// Builds a small but structurally real qcow2 v3 image: one compressed cluster,
/// one sparse cluster, one uncompressed cluster and another sparse cluster.
///
/// A unit test is the only way to exercise the converter without a
/// multi-gigabyte download, and the layout has to be written the way the
/// converter reads it — offset in the low 48 bits, bit 62 marking compression —
/// because that is what real images contain.
struct QCow2Fixture {
    static let clusterBits = 16
    static let clusterSize = 65_536
    static let clusterCount = 4

    /// Cluster contents, by disk cluster index. `nil` means "reads as zeroes".
    var pattern: Data
    var plain: Data

    init() {
        pattern = Data((0..<QCow2Fixture.clusterSize).map { UInt8($0 % 251) })
        plain = Data(repeating: 0xAB, count: QCow2Fixture.clusterSize)
    }

    static let l1Offset: UInt64 = 1 * 65_536
    static let l2Offset: UInt64 = 2 * 65_536
    static let plainOffset: UInt64 = 3 * 65_536
    static let payloadOffset: UInt64 = 4 * 65_536

    func fileData() -> Data {
        var bytes = Data(count: Int(QCow2Fixture.payloadOffset) + payload.count)

        // --- header (cluster 0) ---
        bytes.replaceSubrange(0..<4, with: Data([0x51, 0x46, 0x49, 0xFB]))
        putBE32(&bytes, 4, 3)                                     // version
        putBE32(&bytes, 20, UInt32(QCow2Fixture.clusterBits))      // cluster bits
        putBE64(&bytes, 24, UInt64(QCow2Fixture.clusterSize) * UInt64(QCow2Fixture.clusterCount))
        putBE32(&bytes, 36, 1)                                     // L1 entries
        putBE64(&bytes, 40, QCow2Fixture.l1Offset)
        putBE64(&bytes, 48, 0)                                     // refcount table offset
        putBE32(&bytes, 96, 4)                                     // refcount order
        putBE32(&bytes, 100, 104)                                  // header length

        // --- L1 table ---
        putBE64(&bytes, Int(QCow2Fixture.l1Offset), QCow2Fixture.l2Offset)

        // --- L2 table ---
        putBE64(
            &bytes,
            Int(QCow2Fixture.l2Offset),
            QCow2Fixture.payloadOffset | QCOW2Converter.compressedBit
        )
        // cluster 1 stays zero: a sparse region
        putBE64(&bytes, Int(QCow2Fixture.l2Offset) + 16, QCow2Fixture.plainOffset)
        // cluster 3 stays zero as well

        // --- data ---
        bytes.replaceSubrange(
            Int(QCow2Fixture.plainOffset)..<(Int(QCow2Fixture.plainOffset) + plain.count),
            with: plain
        )
        bytes.replaceSubrange(
            Int(QCow2Fixture.payloadOffset)..<(Int(QCow2Fixture.payloadOffset) + payload.count),
            with: payload
        )
        return bytes
    }

    /// The expected flattened disk image.
    func expectedRawImage() -> Data {
        var expected = Data(count: QCow2Fixture.clusterSize * QCow2Fixture.clusterCount)
        expected.replaceSubrange(0..<pattern.count, with: pattern)
        let plainStart = 2 * QCow2Fixture.clusterSize
        expected.replaceSubrange(plainStart..<(plainStart + plain.count), with: plain)
        return expected
    }

    private var payload: Data {
        let compressed = QCow2Fixture.deflate(pattern)
        return compressed.isEmpty ? pattern : compressed
    }
}

private func putBE32(_ data: inout Data, _ offset: Int, _ value: UInt32) {
    for index in 0..<4 {
        data[offset + index] = UInt8((value >> (8 * UInt32(3 - index))) & 0xFF)
    }
}

private func putBE64(_ data: inout Data, _ offset: Int, _ value: UInt64) {
    for index in 0..<8 {
        data[offset + index] = UInt8((value >> (8 * UInt64(7 - index))) & 0xFF)
    }
}

// MARK: - Tests

@Suite("qcow2 conversion")
struct QCow2ConverterTests {
    @Test("a compressed cluster, a sparse cluster and a plain cluster all land correctly")
    func convertRoundTripsAContainer() throws {
        let fixture = QCow2Fixture()
        let source = try temporaryFile(fixture.fileData())
        let destination = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("hyper-machine-converted-\(UUID().uuidString).raw")
        defer {
            try? FileManager.default.removeItem(at: source)
            try? FileManager.default.removeItem(at: destination)
        }

        let summary = try QCOW2Converter.convert(from: source, to: destination)

        #expect(summary.compressedClusters == 1)
        #expect(summary.plainClusters == 1)

        let output = try Data(contentsOf: destination)
        #expect(output.count == QCow2Fixture.clusterSize * QCow2Fixture.clusterCount)
        #expect(Array(output[0..<64]) == Array(fixture.pattern[0..<64]))

        // The sparse cluster reads as zeroes...
        let sparseStart = QCow2Fixture.clusterSize
        #expect(output[sparseStart..<(sparseStart + 512)].allSatisfy { $0 == 0 })
        // ... the plain cluster keeps its bytes ...
        let plainStart = 2 * QCow2Fixture.clusterSize
        #expect(Array(output[plainStart..<(plainStart + 64)]) == Array(fixture.plain[0..<64]))
        // ... and the last cluster is sparse too.
        let lastStart = 3 * QCow2Fixture.clusterSize
        #expect(output[lastStart..<(lastStart + 512)].allSatisfy { $0 == 0 })
    }

    @Test("the whole flattened image matches byte for byte")
    func convertIsByteExact() throws {
        let fixture = QCow2Fixture()
        let source = try temporaryFile(fixture.fileData())
        let destination = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("hyper-machine-converted-\(UUID().uuidString).raw")
        defer {
            try? FileManager.default.removeItem(at: source)
            try? FileManager.default.removeItem(at: destination)
        }

        let expected = fixture.expectedRawImage()
        try QCOW2Converter.convert(from: source, to: destination)

        let actual = try Data(contentsOf: destination)
        #expect(actual == expected)
    }

    @Test("a file that is not qcow2 is refused")
    func nonQCow2IsRefused() throws {
        let source = try temporaryFile(Data(count: 4096))
        let destination = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent("hyper-machine-nope-\(UUID().uuidString).raw")
        defer {
            try? FileManager.default.removeItem(at: source)
            try? FileManager.default.removeItem(at: destination)
        }

        #expect(throws: QCOW2Converter.ConversionError.self) {
            try QCOW2Converter.convert(from: source, to: destination)
        }
    }

    @Test("features the converter cannot honour are refused, not guessed at")
    func unsupportedFeaturesAreRefused() throws {
        var header = try #require(QCOW2Header(data: qcow2HeaderBytes()))
        #expect(throws: Never.self) { try QCOW2Converter.checkSupported(header) }

        // zstd-compressed clusters: bit 3 of the incompatible features.
        var bytes = qcow2HeaderBytes()
        bytes[72 + 7] = 0b0000_1000
        header = try #require(QCOW2Header(data: bytes))
        #expect(throws: QCOW2Converter.ConversionError.self) {
            try QCOW2Converter.checkSupported(header)
        }
    }

    @Test("an unaligned or empty descriptor is not mistaken for data")
    func zeroClustersAreNotMistakenForData() {
        // A zero descriptor, and one whose offset is not sector-aligned, must not
        // send the reader to the container's own header.
        #expect(QCOW2Converter.plainClusterOffset(0) == nil)
        #expect(QCOW2Converter.plainClusterOffset(1) == nil)
        #expect(QCOW2Converter.plainClusterOffset(0x40001) == nil)
        #expect(QCOW2Converter.plainClusterOffset(0x40000) == 0x40000)
    }
}

@Suite("Image checksums")
struct ImageChecksumTests {
    @Test("the algorithm is chosen by digest length, not by the manifest's name")
    func algorithmComesFromTheDigestLength() {
        #expect(ImageChecksum.Algorithm(hexLength: 64) == .sha256)
        #expect(ImageChecksum.Algorithm(hexLength: 128) == .sha512)
        #expect(ImageChecksum.Algorithm(hexLength: 40) == nil)
        #expect(ImageChecksum.Algorithm(hexLength: 0) == nil)
    }

    @Test("both manifest shapes are parsed")
    func manifestShapesAreParsed() {
        let manifest = """
        abc123  ubuntu-24.04-minimal-cloudimg-arm64.img
        def456 *debian-13-genericcloud-arm64.raw
        # a comment line
        """
        #expect(ImageChecksum.parse(manifest, filename: "ubuntu-24.04-minimal-cloudimg-arm64.img") == "abc123")
        #expect(ImageChecksum.parse(manifest, filename: "debian-13-genericcloud-arm64.raw") == "def456")
        #expect(ImageChecksum.parse(manifest, filename: "absent.img") == nil)
    }

    @Test("SHA-256 and SHA-512 both match their published digests")
    func digestsMatchKnownValues() throws {
        let url = try temporaryFile(Data("abc".utf8))
        defer { try? FileManager.default.removeItem(at: url) }

        #expect(
            try ImageChecksum.digest(of: url, algorithm: .sha256)
                == "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad"
        )
        #expect(
            try ImageChecksum.digest(of: url, algorithm: .sha512)
                == """
                ddaf35a193617abacc417349ae20413112e6fa4e89a97ea20a9eeee64b55d39a\
                2192992a274fc1a836ba3c23a3feebbd454d4423643ce80e2a9ac94fa54ca49f
                """
        )
    }

    @Test("a verified digest compares case-insensitively")
    func verificationComparesCaseInsensitively() {
        let verification = ImageChecksum.Verification(
            filename: "image.img",
            expected: "ABCDEF",
            actual: "abcdef",
            algorithm: .sha256
        )
        #expect(verification.matches)
        #expect(verification.shortActual == "abcdef")
    }
}

// MARK: - Cloud-init seed

@Suite("Cloud-init seed")
struct CloudInitSeedTests {
    @Test("the handshake reports what the guest can see of its own network")
    func handshakeIncludesNetworkDiscovery() {
        let userData = CloudInitSeed.userData(
            CloudInitConfig(hostname: "guest", username: "hyper")
        )
        // Without this, an isolation claim can only be checked against the
        // host's intentions rather than against the guest.
        #expect(userData.contains("ip -br addr"))
        #expect(userData.contains("ip route"))
        #expect(userData.contains("ip -br link"))
        #expect(userData.hasPrefix("#cloud-config"))
    }

    @Test("extra run commands reach the guest, one YAML entry each")
    func extraRunCommandsAreEmitted() {
        let userData = CloudInitSeed.userData(
            CloudInitConfig(
                hostname: "guest",
                username: "hyper",
                extraRunCommands: ["echo hello", "echo second"]
            )
        )
        #expect(userData.contains("echo hello"))
        #expect(userData.contains("echo second"))
        // One runcmd entry each: two supplied, plus the handshake and the
        // console banner this generator always emits.
        let entries = userData
            .split(whereSeparator: \.isNewline)
            .filter { $0.hasPrefix("  - [ sh, -c, ") }
        #expect(entries.count == 4)
    }

    @Test("a command cannot break out of its YAML scalar")
    func commandsAreEscaped() {
        // A newline would end the mapping entry and silently change the shape of
        // the document, so it is replaced rather than trusted.
        let escaped = CloudInitSeed.yamlFlowScalar("echo \"quoted\"\nrm -rf /\necho done")
        #expect(!escaped.contains("\n"))
        #expect(escaped.contains("\\\"quoted\\\""))
    }
}

// MARK: - Helpers

private func temporaryFile(_ data: Data) throws -> URL {
    let url = URL(fileURLWithPath: NSTemporaryDirectory())
        .appendingPathComponent("hyper-machine-input-\(UUID().uuidString).img")
    try data.write(to: url)
    return url
}

private func qcow2HeaderBytes() -> Data {
    var bytes = Data(count: 104)
    bytes.replaceSubrange(0..<4, with: Data([0x51, 0x46, 0x49, 0xFB]))
    putBE32(&bytes, 4, 3)
    putBE32(&bytes, 20, 16)
    putBE64(&bytes, 24, 3_758_096_384)
    putBE32(&bytes, 36, 7)
    putBE64(&bytes, 40, 0x0003_0000)
    return bytes
}

/// Deflate, so the fixture's "compressed" cluster really is compressed.
private extension QCow2Fixture {
    static func deflate(_ input: Data) -> Data {
        var output = Data(count: input.count + 1024)
        // Captured before the closure: reading `output.count` inside it while it
        // is exclusively borrowed is a compile-time error.
        let capacity = output.count
        let written: Int = output.withUnsafeMutableBytes { destination in
            input.withUnsafeBytes { source in
                guard let destinationBase = destination.bindMemory(to: UInt8.self).baseAddress,
                      let sourceBase = source.bindMemory(to: UInt8.self).baseAddress
                else { return 0 }
                return compression_encode_buffer(
                    destinationBase,
                    capacity,
                    sourceBase,
                    input.count,
                    nil,
                    COMPRESSION_ZLIB
                )
            }
        }
        return written > 0 ? output.prefix(written) : Data()
    }
}
