#!/bin/bash
#
# Build the HyperMachine app, assemble it into a .app bundle, and ad-hoc sign it
# with the Virtualization entitlement.
#
# SwiftPM alone produces a bare Mach-O executable. That is not enough:
# Virtualization.framework refuses to create a VM, or even load Apple's
# restore-image catalog, unless the *process* carries
# com.apple.security.virtualization — and a bundled app also needs an
# Info.plist to get a Dock icon and an activatable window.
#
# Ad-hoc signing ("-") is sufficient: no Apple Developer account or provisioning
# profile is involved.
#
# Usage: Scripts/build-app.sh [--no-open]

set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root"

# A full Xcode toolchain is required; Command Line Tools alone cannot link a
# signed bundle reliably.
if [ -z "${DEVELOPER_DIR:-}" ] && [ ! -d /Applications/Xcode.app ]; then
    beta="$(ls -d "$HOME"/Downloads/Xcode*.app 2>/dev/null | head -1 || true)"
    if [ -n "$beta" ]; then
        export DEVELOPER_DIR="$beta/Contents/Developer"
        echo "using $DEVELOPER_DIR"
    fi
fi

product="HyperMachineApp"
bundle=".build/HyperMachine.app"

echo "building $product…"
swift build --product "$product"

echo "assembling $bundle…"
rm -rf "$bundle"
mkdir -p "$bundle/Contents/MacOS" "$bundle/Contents/Resources"
cp ".build/debug/$product" "$bundle/Contents/MacOS/$product"
cp Resources/Info.plist "$bundle/Contents/Info.plist"

echo "signing…"
codesign --force --sign - \
    --entitlements Resources/HyperMachine.entitlements \
    "$bundle"

# Fail loudly if the entitlement did not survive: the app would launch and then
# fail every VM operation with an opaque framework error.
codesign --verify --strict --verbose=1 "$bundle"
if ! codesign -d --entitlements - "$bundle" 2>&1 | grep -q "com.apple.security.virtualization"; then
    echo "error: $bundle is not signed with com.apple.security.virtualization" >&2
    exit 1
fi

echo "ok: $root/$bundle"

if [ "${1:-}" = "--no-open" ]; then
    exit 0
fi

echo "launching…"
open "$bundle"
