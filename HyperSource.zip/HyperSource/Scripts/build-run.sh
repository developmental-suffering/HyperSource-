#!/bin/bash
#
# Build the hm CLI, sign it with the Virtualization entitlement, and run it.
#
# Signing is not optional: Virtualization.framework refuses to load a restore
# image, or create a VM, unless the process carries
# com.apple.security.virtualization. Ad-hoc signing ("-") is sufficient — no
# Apple Developer account or provisioning profile is required.
#
# Usage: Scripts/build-run.sh [hm arguments...]

set -euo pipefail

root="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$root"

# Prefer a full Xcode toolchain; Command Line Tools alone cannot build the
# swift-testing suite or a signed app bundle.
if [ -z "${DEVELOPER_DIR:-}" ] && [ ! -d /Applications/Xcode.app ]; then
    beta="$(ls -d "$HOME"/Downloads/Xcode*.app 2>/dev/null | head -1 || true)"
    if [ -n "$beta" ]; then
        export DEVELOPER_DIR="$beta/Contents/Developer"
        echo "using $DEVELOPER_DIR"
    fi
fi

swift build --product hm
codesign --force --sign - \
    --entitlements Resources/HyperMachine.entitlements \
    .build/debug/hm

exec ./.build/debug/hm "$@"
