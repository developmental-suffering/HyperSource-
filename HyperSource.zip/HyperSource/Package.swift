// swift-tools-version: 6.0
import PackageDescription

let package = Package(
    name: "HyperMachine",
    platforms: [
        .macOS(.v14)
    ],
    products: [
        .library(name: "HyperMachineCore", targets: ["HyperMachineCore"]),
        .library(name: "HyperMachineVZ", targets: ["HyperMachineVZ"]),
        .executable(name: "hm", targets: ["hm"]),
        // The SwiftUI app. Bundled into HyperMachine.app and ad-hoc signed by
        // Scripts/build-app.sh; SwiftPM alone produces a bare executable, which
        // Virtualization.framework will not accept without the entitlement.
        .executable(name: "HyperMachineApp", targets: ["HyperMachineApp"])
    ],
    targets: [
        .target(
            name: "HyperMachineCore"
        ),
        // Everything that touches Virtualization.framework. Isolated from
        // HyperMachineCore so the configuration model stays testable without
        // the restricted com.apple.security.virtualization entitlement.
        .target(
            name: "HyperMachineVZ",
            dependencies: ["HyperMachineCore"]
        ),
        .executableTarget(
            name: "hm",
            dependencies: ["HyperMachineCore", "HyperMachineVZ"]
        ),
        .executableTarget(
            name: "HyperMachineApp",
            dependencies: ["HyperMachineCore", "HyperMachineVZ"],
            path: "Sources/HyperMachineApp"
        ),
        .testTarget(
            name: "HyperMachineCoreTests",
            dependencies: ["HyperMachineCore"]
        ),
        // Covers the parts that live next to Virtualization.framework but do not
        // need it: image checksums, and the qcow2 reader that has to be right or
        // the guest gets a silently corrupt disk.
        .testTarget(
            name: "HyperMachineVZTests",
            dependencies: ["HyperMachineVZ"]
        )
    ]
)
